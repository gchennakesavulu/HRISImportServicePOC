﻿using DataManager;
using DataManager.Models;
using FileProcessingServices.Models;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Task = System.Threading.Tasks.Task;

namespace FileProcessingServices
{
    public class FileProcesser : IFileProcesser
    {
        private readonly IMetaValueRepository _metaValue;
        private readonly IConfiguration _configuration;
        private readonly IBusinessEntityRepository _businessEntity;


        public FileProcesser(IMetaValueRepository metaValue, IBusinessEntityRepository businessEntity, IConfiguration configuration)
        {
            _metaValue = metaValue;
            _configuration = configuration;
            _businessEntity = businessEntity;
        }
        public async Task UploadFile()
        {
            string filePath = @"C:\Code\HRIS\Files\Test09086Pos.txt";
            var mappings = _configuration.GetSection("ImportMappings").Get<Dictionary<string, Dictionary<string, string>>>()?.ToDictionary(x => x.Key, x => new Dictionary<string, string>(x.Value, StringComparer.OrdinalIgnoreCase)) ?? [];
            List<int> templateMetaTypeIds = (_configuration["JobTemplateMetaTypes:MetaTypeIds"] ?? string.Empty).Split('|', StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToList();
            var connection = _configuration.GetConnectionString("PMDatabase");
            var data = File.ReadLines(filePath).ToList();
            string[] headers = data.First().Split('|');
            var dataRows = data.Skip(1).ToList();
            Dictionary<string, DataTable> destinationTables = new();
            var metaValues = await _metaValue.GetMetvalueNamesWithIds(templateMetaTypeIds);
            var businessEntities = await _businessEntity.GetBusinessEntityNamesWithIds();

            var logDirectory = Path.Combine(@"C:\Code\HRIS\Files", "Logs");
            Directory.CreateDirectory(logDirectory);
            var errorFileName = $"Error_{Guid.NewGuid()}_{DateTime.Now:yyyyMMddHHmmss}.Pos.txt";
            var errorFilePath = Path.Combine(logDirectory, errorFileName);
            var failedRows = new List<string>();
            failedRows.Add(string.Join("|", headers));

            foreach (var tableMapping in mappings ?? Enumerable.Empty<KeyValuePair<string, Dictionary<string, string>>>())
            {
                DataTable dataTable = new();

                foreach (var columnMapping in tableMapping.Value)
                {
                    dataTable.Columns.Add(columnMapping.Key);
                }

                destinationTables.Add(tableMapping.Key, dataTable);
            }
            foreach (var line in dataRows)
            {
                var values = line.Split('|');
                bool rowProcessed = false;
                if (mappings != null)
                {
                    foreach (var tableMapping in mappings)
                    {
                        var row = destinationTables[tableMapping.Key].NewRow();
                        bool hasData = false;
                        if (row.Table.Columns.Contains("Deleted"))
                            row["Deleted"] = 0;
                        if (row.Table.Columns.Contains("CreateDate"))
                            row["CreateDate"] = DateTime.UtcNow;
                        if (row.Table.Columns.Contains("ModifiedDate"))
                            row["ModifiedDate"] = DateTime.UtcNow;
                        if (row.Table.Columns.Contains("CreatedBy"))
                            row["CreatedBy"] = 5;
                        if (row.Table.Columns.Contains("ModifiedBy"))
                            row["ModifiedBy"] = 5;
                        if (row.Table.Columns.Contains("Active"))
                            row["Active"] = true;
                        if (row.Table.Columns.Contains("IsAvailableInJobAgent"))
                            row["IsAvailableInJobAgent"] = true;

                        for (int i = 0; i < headers.Length && i < values.Length; i++)
                        {
                            if (i < values.Length && tableMapping.Value.TryGetValue(headers[i].Trim(), out string? dbColumn) && !string.IsNullOrWhiteSpace(dbColumn))
                            {

                                if (!string.IsNullOrWhiteSpace(dbColumn) && !string.IsNullOrWhiteSpace(values[i]) && metaValues.TryGetValue(values[i].Trim(), out int metaValueId))
                                {
                                    row[dbColumn] = metaValueId;
                                    hasData = true;
                                }
                                else if (!string.IsNullOrWhiteSpace(dbColumn) && !string.IsNullOrWhiteSpace(values[i]) && businessEntities.TryGetValue(values[i].Trim(), out int businessEntityId))
                                {
                                    row[dbColumn] = businessEntityId;
                                    hasData = true;
                                }
                                else
                                {
                                    row[dbColumn] = string.IsNullOrWhiteSpace(values[i]) ? DBNull.Value : values[i].Trim();
                                    hasData = true;

                                }
                            }

                        }
                        if (hasData)
                        {
                            destinationTables[tableMapping.Key].Rows.Add(row);
                            rowProcessed = true;
                        }
                    }                   
                }
                if (!rowProcessed)
                    failedRows.Add(line);
                if(failedRows.Count > 1){
                    await File.WriteAllLinesAsync(errorFilePath, failedRows);
                }
            }
            using var con = new SqlConnection(connection);
            await con.OpenAsync();
            using var transaction = con.BeginTransaction();
            try
            {
                foreach (var table in destinationTables)
                {
                   // BulkInsert(con, table.Key, table.Value, transaction);
                }
                
                //using (var cmd = new SqlCommand("dbo.MergeJobTemplateData", con, transaction))
                //{
                //    cmd.CommandType = CommandType.StoredProcedure;
                //    await cmd.ExecuteNonQueryAsync();
                //}

                
                //using (var cmd = new SqlCommand("dbo.ClearJobTemplateStageTables", con, transaction))
                //{
                //    cmd.CommandType = CommandType.StoredProcedure;
                //    await cmd.ExecuteNonQueryAsync();
                //}

                transaction.Commit();
            }
            catch
            {
                transaction.Rollback();
                throw;
            }
        }

        public void BulkInsert(SqlConnection connection, string tableName, DataTable dataTable, SqlTransaction transaction)
        {
            using var bulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.KeepIdentity, transaction);

            bulkCopy.DestinationTableName = tableName;
            bulkCopy.BulkCopyTimeout = 600;
            //bulkCopy.BatchSize = 5000;
            foreach (DataColumn column in dataTable.Columns)
            {
                bulkCopy.ColumnMappings.Add(column.ColumnName, column.ColumnName);
            }

            bulkCopy.WriteToServer(dataTable);
        }
    }
}

using FileProcessingServices;
using Microsoft.Data.SqlClient;

namespace FileProcessingServices
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;
        private readonly IServiceScopeFactory _scopeFactory;

        public Worker(ILogger<Worker> logger, IServiceScopeFactory scopeFactory)
        {
            _logger = logger;
            _scopeFactory = scopeFactory;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            //while (!stoppingToken.IsCancellationRequested)
            //{
            if (_logger.IsEnabled(LogLevel.Information))
            {
                _logger.LogInformation("*********************Worker running at: {time}", DateTimeOffset.Now +"*************************");
                using var scope = _scopeFactory.CreateScope();
                var fileProcesser = scope.ServiceProvider.GetRequiredService<IFileProcesser>();
                _logger.LogInformation("*********************FileUpload Start at: {time}", DateTimeOffset.Now +"************************");
                await fileProcesser.UploadFile();
                _logger.LogInformation("*********************FileUpload End at: {time}", DateTimeOffset.Now +"**************************");

            }
            //await Task.Delay(1000, stoppingToken);
            //}
        }
    }
}

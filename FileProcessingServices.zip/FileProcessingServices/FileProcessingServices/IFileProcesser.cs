﻿using DataManager.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Task = System.Threading.Tasks.Task;

namespace FileProcessingServices
{
    public interface IFileProcesser
    {
      Task UploadFile();   
    }
}

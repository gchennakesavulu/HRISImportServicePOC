using DataManager;
using DataManager.Models;
using FileProcessingServices;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

var builder = Host.CreateApplicationBuilder(args);

builder.Services.AddHostedService<Worker>();
builder.Services.AddDbContext<PositionManagerDbContext>(options =>
options.UseSqlServer(builder.Configuration.GetConnectionString("PMDatabase")));
builder.Services.AddScoped<IFileProcesser, FileProcesser>();
builder.Services.AddScoped<IMetaValueRepository, MetaValueRepository>();
builder.Services.AddScoped<IBusinessEntityRepository, BusinessEntityRepository>();
var configuration =
    new ConfigurationBuilder()
        .SetBasePath(AppContext.BaseDirectory)
        .AddJsonFile("appsettings.json")
        .Build();
var host = builder.Build();
host.Run();


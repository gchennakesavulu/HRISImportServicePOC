﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileProcessingServices.Models
{
    public class ImportConfiguration
    {
       // public Dictionary<string,Dictionary<string, string>> ImportMappings {get;set;}
    }
}

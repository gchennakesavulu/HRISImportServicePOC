﻿using DataManager.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataManager
{
    public class BusinessEntityRepository:IBusinessEntityRepository
    {
        private readonly PositionManagerDbContext _context;
        public BusinessEntityRepository(PositionManagerDbContext context)
        {
            _context = context;
        }
        public async Task<int> GetBusinessEntityIdByName(string name)
        {
            return await _context.BusinessEntities.Where(x => x.Deleted == 0 && x.Name == name).Select(x => x.BusinessEntityId).FirstOrDefaultAsync();
        }
        public async Task<Dictionary<string, int>> GetBusinessEntityNamesWithIds()
        {
            return await _context.BusinessEntities.Where(x => x.Deleted == 0).ToDictionaryAsync(x => x.Name, x => x.BusinessEntityId);
        }
    }
}

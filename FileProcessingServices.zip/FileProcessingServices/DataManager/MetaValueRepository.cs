﻿using DataManager.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace DataManager
{
    public class MetaValueRepository : IMetaValueRepository
    {
        private readonly PositionManagerDbContext _context;
        public MetaValueRepository(PositionManagerDbContext context)
        {
            _context = context;
        }
        public async Task<List<MetaValue>> GetMetaValues()
        {
           return await _context.MetaValues.Where(x=>x.Deleted==0).ToListAsync();         
        }
        public async Task<int> GetMetaValueIdByName(string name)
        {
            return await _context.MetaValues.Where(x => x.Deleted == 0 && x.Name == name).Select(x => (int)x.MetaValueId).FirstOrDefaultAsync();
        }
        public async Task<Dictionary<string, int>> GetMetvalueNamesWithIds(List<int> metaTypeIds)
        {
            return await _context.MetaValues.Where(x => x.Deleted == 0 && metaTypeIds.Contains(x.MetaTypeId)).GroupBy(x => x.Name).
                Select(g => new{Name = g.Key,MetaValueId = g.Max(x => x.MetaValueId)}).
                ToDictionaryAsync(x => x.Name,x => x.MetaValueId,StringComparer.OrdinalIgnoreCase);
        }

    }
}

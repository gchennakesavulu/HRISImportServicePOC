﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataManager
{
    public interface IBusinessEntityRepository
    {
        Task<int> GetBusinessEntityIdByName(string name);
        Task<Dictionary<string, int>> GetBusinessEntityNamesWithIds();
    }
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class BulkIndexLog
{
    public int BulkIndexLogId { get; set; }

    public int ContextId { get; set; }

    public int IndexTypeId { get; set; }

    public int Deleted { get; set; }

    public DateTime? IndexStart { get; set; }

    public DateTime? IndexEnd { get; set; }

    public DateTime CreateDate { get; set; }

    public int CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual IndexType IndexType { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class JobPostingFieldValue
{
    public int JobPostingFieldValueId { get; set; }

    public int JobPostingId { get; set; }

    public int MetaTypeId { get; set; }

    public int? TmsdataTypeId { get; set; }

    public int? MetaValueId { get; set; }

    public bool IsSecure { get; set; }

    /// <summary>
    /// GroupID, GroupSequenceID and ValueInstanceID go hand in hand to define and store Multi Instance Data values with Multiple Values. 
    /// GroupID Identifies which group it is.
    /// e.g. 1 is LicenseFields group
    /// 2 is EducationGroup
    /// 3 is WorkHistory group etc.
    /// 
    /// GroupSequenceID identifies the instance of a group.
    /// e.g. if there are 5 licences, first license groupsequenceID is 1, second is 2, third is 3, fourth is 4 and fifth is 5.
    /// 
    /// ValueInstanceID identifies and stores the multiple values of a metatypeid from the value list. e.g. Skills matrix.. Multiple possible are 1-20, but the selected user values ar 5,11,19 etc.
    /// 
    /// The GroupID and SequenceID are for multiinstance data like the License and its child fields like LicenseState/LicenceName.
    /// 
    /// E.g. 3 License details collected will be in GroupIDs 1,2 and 3. Each element values of each Group would have a order collected in Sequence.
    /// 
    /// 
    /// 
    /// MetaTypeID 	GroupId 	SequenceId
    /// 1         	                1              	1
    /// 1        	                1 		2          
    /// 1		1		3
    /// 1		2		1
    /// 1		2		2
    /// 1		2		3
    /// 
    /// </summary>
    public int? GroupId { get; set; }

    /// <summary>
    /// GroupID, GroupSequenceID and ValueInstanceID go hand in hand to define and store Multi Instance Data values with Multiple Values. 
    /// GroupID Identifies which group it is.
    /// e.g. 1 is LicenseFields group
    /// 2 is EducationGroup
    /// 3 is WorkHistory group etc.
    /// 
    /// GroupSequenceID identifies the instance of a group.
    /// e.g. if there are 5 licences, first license groupsequenceID is 1, second is 2, third is 3, fourth is 4 and fifth is 5.
    /// 
    /// ValueInstanceID identifies and stores the multiple values of a metatypeid from the value list. e.g. Skills matrix.. Multiple possible are 1-20, but the selected user values ar 5,11,19 etc.
    /// 
    /// The GroupID and SequenceID are for multiinstance data like the License and its child fields like LicenseState/LicenceName.
    /// 
    /// E.g. 3 License details collected will be in GroupIDs 1,2 and 3. Each element values of each Group would have a order collected in Sequence.
    /// 
    /// 
    /// 
    /// MetaTypeID 	GroupId 	SequenceId
    /// 1         	                1              	1
    /// 1        	                1 		2          
    /// 1		1		3
    /// 1		2		1
    /// 1		2		2
    /// 1		2		3
    /// 
    /// </summary>
    public int? GroupSequenceId { get; set; }

    /// <summary>
    /// GroupID, GroupSequenceID and ValueInstanceID go hand in hand to define and store Multi Instance Data values with Multiple Values. 
    /// GroupID Identifies which group it is.
    /// e.g. 1 is LicenseFields group
    /// 2 is EducationGroup
    /// 3 is WorkHistory group etc.
    /// 
    /// GroupSequenceID identifies the instance of a group.
    /// e.g. if there are 5 licences, first license groupsequenceID is 1, second is 2, third is 3, fourth is 4 and fifth is 5.
    /// 
    /// ValueInstanceID identifies and stores the multiple values of a metatypeid from the value list. e.g. Skills matrix.. Multiple possible are 1-20, but the selected user values ar 5,11,19 etc.
    /// 
    /// The GroupID and SequenceID are for multiinstance data like the License and its child fields like LicenseState/LicenceName.
    /// 
    /// E.g. 3 License details collected will be in GroupIDs 1,2 and 3. Each element values of each Group would have a order collected in Sequence.
    /// 
    /// 
    /// 
    /// MetaTypeID 	GroupId 	SequenceId
    /// 1         	                1              	1
    /// 1        	                1 		2          
    /// 1		1		3
    /// 1		2		1
    /// 1		2		2
    /// 1		2		3
    /// 
    /// </summary>
    public int ValueInstanceId { get; set; }

    public string? ValueText { get; set; }

    public int? ValueInt { get; set; }

    public double? ValueFloat { get; set; }

    public DateTime? ValueDate { get; set; }

    public string? ValueEncrypted { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual JobPosting JobPosting { get; set; } = null!;

    public virtual MetaType MetaType { get; set; } = null!;

    public virtual MetaValue? MetaValue { get; set; }

    public virtual TmsdataType? TmsdataType { get; set; }
}

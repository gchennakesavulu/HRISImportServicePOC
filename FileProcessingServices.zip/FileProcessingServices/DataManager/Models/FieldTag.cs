﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class FieldTag
{
    public int FieldTagId { get; set; }

    public string Tag { get; set; } = null!;

    public bool IsDataSourceIdvalueLookup { get; set; }

    /// <summary>
    /// If the tag maps to a related table (see IsDataSourceIDValueLookup) and this fierld is not null, it defines what property/column of the related object is the value and how to lookup the display name. It overrides the default property/column defined by NavPropertyBinding. E.g. For the Requisition field HiringMangerID the related object is of UserProfile type and this field allows defining separate tags for FirstName, LastName and Email. If this field is null, then the value is defined by NavPropertyBinding and display name is defined by MetaTypeID or DataSourceFieldType (see MetaTypeID ).
    /// </summary>
    public int? IdlookupValueDataSourceFieldTypeId { get; set; }

    public int? ListDataSourceFieldTypeId { get; set; }

    public string? ListLookupValue { get; set; }

    public int DataSourceFieldTypeId { get; set; }

    public int FieldCategoryId { get; set; }

    public int? MetaTypeId { get; set; }

    /// <summary>
    /// Lookup key into the resource file that allows to customize the display name of the tag. If not null, this value is checked first. If null, the system will try to take IDLookupValueDataSourceFieldTypeID, etc. 
    /// 
    /// </summary>
    public string? ResourceLookupKey { get; set; }

    /// <summary>
    /// Resource manager key ID for ResourceLookupKey.
    /// 
    /// </summary>
    public int? ResourceManagerKeyId { get; set; }

    /// <summary>
    /// This bit indicates whethere the tag references a grouped multi-instance  value or single instance value.
    /// </summary>
    public bool IsGroupTag { get; set; }

    public int Deleted { get; set; }

    public int CreatedBy { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public int? GroupId { get; set; }

    public virtual DataSourceFieldType DataSourceFieldType { get; set; } = null!;

    public virtual FieldCategory FieldCategory { get; set; } = null!;

    public virtual ICollection<FormTypeMetaTypeFieldTag> FormTypeMetaTypeFieldTags { get; set; } = new List<FormTypeMetaTypeFieldTag>();

    public virtual ApplicationGroup? Group { get; set; }

    public virtual DataSourceFieldType? IdlookupValueDataSourceFieldType { get; set; }

    public virtual DataSourceFieldType? ListDataSourceFieldType { get; set; }

    public virtual MetaType? MetaType { get; set; }
}

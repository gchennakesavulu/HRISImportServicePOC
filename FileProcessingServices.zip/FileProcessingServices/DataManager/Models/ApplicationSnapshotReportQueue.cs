﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ApplicationSnapshotReportQueue
{
    public int ApplicationSnapshotReportQueueId { get; set; }

    public int? ApplicationId { get; set; }

    public int? SectionSequence { get; set; }

    public int? FieldSequence { get; set; }

    public string? SectionName { get; set; }

    public int? FieldId { get; set; }

    public string? DisplayName { get; set; }

    public int? TmsdataTypeId { get; set; }

    public string? FieldValue { get; set; }

    public int? ApplicationFormId { get; set; }

    public int? GroupId { get; set; }

    public int? GroupSequenceId { get; set; }

    public string? GroupName { get; set; }

    public bool? IsSecure { get; set; }

    public int? ColumnSequence { get; set; }

    public int? LabelOrientation { get; set; }

    public bool? Required { get; set; }

    public int? RowSequence { get; set; }
}

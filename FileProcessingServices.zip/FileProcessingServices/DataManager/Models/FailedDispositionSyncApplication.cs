﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class FailedDispositionSyncApplication
{
    public int FailedDispositionSyncApplicationId { get; set; }

    public string IndeedApplicationId { get; set; } = null!;

    public DateTime ScheduledDate { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }
}

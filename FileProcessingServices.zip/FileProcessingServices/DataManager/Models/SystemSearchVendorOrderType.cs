﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class SystemSearchVendorOrderType
{
    public int SystemSearchVendorOrderTypeId { get; set; }

    public int SystemSearchId { get; set; }

    public int VendorOrderTypeId { get; set; }

    public int VendorOrderStatusTypeId { get; set; }

    public int RoleTypeId { get; set; }

    public bool? Calculated { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual SystemSearch SystemSearch { get; set; } = null!;

    public virtual VendorOrderStatusType VendorOrderStatusType { get; set; } = null!;

    public virtual VendorOrderType VendorOrderType { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class RefactorAssessmentsVendorOrderTableMigration
{
    public int VendorOrderId { get; set; }

    public int VendorOrderDetailId { get; set; }

    public int AssessmentVendorOrderDetailId { get; set; }

    public int ApplicationId { get; set; }

    public int RowOrdinal { get; set; }

    public string? Description { get; set; }

    public string? VendorOrderIdentifier { get; set; }

    public int VendorId { get; set; }

    public int VendorOrderTypeId { get; set; }

    public int VendorOrderStatusTypeId { get; set; }

    public int VendorUserAccountId { get; set; }

    public string? StatusCode { get; set; }

    public string? StatusReason { get; set; }

    public string? OrderProcessingRedirectUrl { get; set; }

    public string? InviteUrl { get; set; }

    public string? ResultDescription { get; set; }

    public string? ResultLinkName { get; set; }

    public string? ResultLink { get; set; }

    public string? Score { get; set; }

    public bool? Passed { get; set; }

    public DateTime? CompletionDate { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public string? VendorOrderSubtypeIdentifier { get; set; }

    public int? VendorOfferingId { get; set; }

    public DateTime? ExpirationDate { get; set; }

    public virtual Vendor Vendor { get; set; } = null!;

    public virtual VendorOrderStatusType VendorOrderStatusType { get; set; } = null!;

    public virtual VendorOrderType VendorOrderType { get; set; } = null!;

    public virtual VendorUserAccount VendorUserAccount { get; set; } = null!;
}

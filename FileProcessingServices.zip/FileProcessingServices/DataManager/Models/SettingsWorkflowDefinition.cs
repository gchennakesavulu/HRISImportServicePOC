﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class SettingsWorkflowDefinition
{
    public int SettingsWorkflowDefinitionId { get; set; }

    public int WorkflowTypeId { get; set; }

    public string WorkflowIdentifier { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<SettingsWorkflow> SettingsWorkflows { get; set; } = new List<SettingsWorkflow>();
}

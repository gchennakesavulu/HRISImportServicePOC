﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class Permission
{
    public int PermissionId { get; set; }

    public string Name { get; set; } = null!;

    public int PermissionTypeId { get; set; }

    public int? ParentId { get; set; }

    public int DisplayOrder { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<Permission> InverseParent { get; set; } = new List<Permission>();

    public virtual Permission? Parent { get; set; }

    public virtual PermissionType PermissionType { get; set; } = null!;

    public virtual ICollection<RolePermission> RolePermissions { get; set; } = new List<RolePermission>();
}

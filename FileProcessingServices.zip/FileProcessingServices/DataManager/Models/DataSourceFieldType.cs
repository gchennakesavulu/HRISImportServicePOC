﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class DataSourceFieldType
{
    public int DataSourceTypeId { get; set; }

    public int DataSourceFieldTypeId { get; set; }

    public string ColumnName { get; set; } = null!;

    public string ColumnResourceLookupKey { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public int TmsdataTypeId { get; set; }

    public int ResourceManagerKeyId { get; set; }

    public virtual ICollection<ApplicationFormBinderMetaDatum> ApplicationFormBinderMetaData { get; set; } = new List<ApplicationFormBinderMetaDatum>();

    public virtual DataSourceType DataSourceType { get; set; } = null!;

    public virtual ICollection<FieldTag> FieldTagDataSourceFieldTypes { get; set; } = new List<FieldTag>();

    public virtual ICollection<FieldTag> FieldTagIdlookupValueDataSourceFieldTypes { get; set; } = new List<FieldTag>();

    public virtual ICollection<FieldTag> FieldTagListDataSourceFieldTypes { get; set; } = new List<FieldTag>();

    public virtual ICollection<FormType> FormTypes { get; set; } = new List<FormType>();

    public virtual ICollection<HrXmlMap> HrXmlMapConditionalElementDataSourceFieldTypes { get; set; } = new List<HrXmlMap>();

    public virtual ICollection<HrXmlMap> HrXmlMapDataSourceFieldTypes { get; set; } = new List<HrXmlMap>();

    public virtual ICollection<HrXmlMap> HrXmlMapLookupDataSourceFieldTypes { get; set; } = new List<HrXmlMap>();

    public virtual ICollection<HrXmlMap> HrXmlMapMultiElementDataSourceFieldTypes { get; set; } = new List<HrXmlMap>();

    public virtual TmsdataType TmsdataType { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class VendorOrderDetail
{
    public int VendorOrderResultId { get; set; }

    public string? Description { get; set; }

    public string? StatusCode { get; set; }

    public string? StatusReason { get; set; }

    public string? ResultLinkName { get; set; }

    public string? ResultLink { get; set; }

    public string? ResultDescription { get; set; }

    public string? Score { get; set; }

    public bool? Passed { get; set; }

    public int VendorOrderId { get; set; }

    public int? JobFamilyId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<AssessmentVendorOrderDetail> AssessmentVendorOrderDetails { get; set; } = new List<AssessmentVendorOrderDetail>();

    public virtual JobFamily? JobFamily { get; set; }

    public virtual RefactorVendorOrderVendorOrderDetailMapping? RefactorVendorOrderVendorOrderDetailMapping { get; set; }

    public virtual VendorOrder VendorOrder { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class NewHireNoteView
{
    public int NewHireId { get; set; }

    public long? NoteCount { get; set; }
}

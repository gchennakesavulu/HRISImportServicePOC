﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class TmsdataType
{
    public int TmsdataTypeId { get; set; }

    public string Name { get; set; } = null!;

    public string? Description { get; set; }

    public bool? IsHidden { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<ApplicationFieldValue> ApplicationFieldValues { get; set; } = new List<ApplicationFieldValue>();

    public virtual ICollection<ApplicationFormBinderMetaDatum> ApplicationFormBinderMetaData { get; set; } = new List<ApplicationFormBinderMetaDatum>();

    public virtual ICollection<AttributeType> AttributeTypes { get; set; } = new List<AttributeType>();

    public virtual ICollection<ControlType> ControlTypes { get; set; } = new List<ControlType>();

    public virtual ICollection<DataSourceFieldType> DataSourceFieldTypes { get; set; } = new List<DataSourceFieldType>();

    public virtual ICollection<JobPostingFieldValue> JobPostingFieldValues { get; set; } = new List<JobPostingFieldValue>();

    public virtual ICollection<JobTemplateFieldValue> JobTemplateFieldValues { get; set; } = new List<JobTemplateFieldValue>();

    public virtual ICollection<MetaType> MetaTypes { get; set; } = new List<MetaType>();

    public virtual ICollection<NewHireFieldValue> NewHireFieldValues { get; set; } = new List<NewHireFieldValue>();

    public virtual ICollection<RequisitionFieldValue> RequisitionFieldValues { get; set; } = new List<RequisitionFieldValue>();
}

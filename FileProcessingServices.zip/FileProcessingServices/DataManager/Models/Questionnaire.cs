﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class Questionnaire
{
    public int QuestionnaireId { get; set; }

    public string Name { get; set; } = null!;

    public int QuestionnaireTypeId { get; set; }

    public string DisplayName { get; set; } = null!;

    public string? InstructionalText { get; set; }

    public bool Active { get; set; }

    public bool IsTemplate { get; set; }

    /// <summary>
    /// This flag indicates that the questionnaire is not shared by multipe consumer, which affords more options for editing and saving in place because only a single consumer will be affected. 
    /// </summary>
    public bool IsPrivateInstance { get; set; }

    /// <summary>
    /// Indicates that the questionnaire is read only. For example a questionnarei, private or templat, that is used by a posted job cannot be changed and is marked read only.
    /// </summary>
    public bool IsReadOnly { get; set; }

    public int? OriginalQuestionnaireId { get; set; }

    /// <summary>
    /// The identifier of the Questionnaire in the external system of record.
    /// </summary>
    public string? Hrisidentifier { get; set; }

    /// <summary>
    /// used to determine if the questionaire is the most recent revision
    /// </summary>
    public bool IsMostRecent { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<ApplicationMostRecent> ApplicationMostRecents { get; set; } = new List<ApplicationMostRecent>();

    public virtual ICollection<Questionnaire> InverseOriginalQuestionnaire { get; set; } = new List<Questionnaire>();

    public virtual ICollection<JobTemplateInstance> JobTemplateInstancePreQualificationQuestionnaires { get; set; } = new List<JobTemplateInstance>();

    public virtual ICollection<JobTemplateInstance> JobTemplateInstanceRankingQuestionnaires { get; set; } = new List<JobTemplateInstance>();

    public virtual ICollection<JobTemplate> JobTemplatePreQualificationQuestionnaires { get; set; } = new List<JobTemplate>();

    public virtual ICollection<JobTemplate> JobTemplateRankingQuestionnaires { get; set; } = new List<JobTemplate>();

    public virtual ICollection<MetaType> MetaTypes { get; set; } = new List<MetaType>();

    public virtual Questionnaire? OriginalQuestionnaire { get; set; }

    public virtual ICollection<QuestionnaireResponse> QuestionnaireResponses { get; set; } = new List<QuestionnaireResponse>();

    public virtual QuestionnaireType QuestionnaireType { get; set; } = null!;

    public virtual ICollection<Question> Questions { get; set; } = new List<Question>();
}

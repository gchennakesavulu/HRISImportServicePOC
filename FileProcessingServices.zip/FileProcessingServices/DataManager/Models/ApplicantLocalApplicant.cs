﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ApplicantLocalApplicant
{
    public int ApplicantLocalApplicantId { get; set; }

    public int ApplicantId { get; set; }

    public int LocalApplicantId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual LocalApplicant LocalApplicant { get; set; } = null!;
}

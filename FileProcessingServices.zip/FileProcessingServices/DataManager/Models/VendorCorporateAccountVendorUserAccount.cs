﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class VendorCorporateAccountVendorUserAccount
{
    public int VendorCorporateAccountVendorUserAccountId { get; set; }

    public int VendorCorporateAccountId { get; set; }

    public int VendorUserAccountId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual VendorCorporateAccount VendorCorporateAccount { get; set; } = null!;

    public virtual VendorUserAccount VendorUserAccount { get; set; } = null!;
}

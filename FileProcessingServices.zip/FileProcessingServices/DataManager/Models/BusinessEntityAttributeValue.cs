﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class BusinessEntityAttributeValue
{
    public int BusinessEntityAttributeValueId { get; set; }

    public int BusinessEntityId { get; set; }

    public int AttributeValueId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual AttributeValue AttributeValue { get; set; } = null!;

    public virtual BusinessEntity BusinessEntity { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class SortOrderType
{
    public int SortOrderTypeId { get; set; }

    public string Name { get; set; } = null!;

    public DateTime CreateDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int Deleted { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<MetaType> MetaTypes { get; set; } = new List<MetaType>();
}

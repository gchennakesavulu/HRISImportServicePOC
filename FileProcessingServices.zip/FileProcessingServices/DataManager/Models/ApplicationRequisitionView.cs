﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ApplicationRequisitionView
{
    public int RequisitionId { get; set; }

    public string RequisitionTitle { get; set; } = null!;

    public string? RequisitionNumber { get; set; }

    public int BusinessEntityId { get; set; }

    public string? Code { get; set; }

    public string? Shift { get; set; }

    public string? Schedule { get; set; }

    public string? HiringManagerLast { get; set; }

    public string? HiringManagerFirst { get; set; }

    public string? HiringManagerMiddle { get; set; }

    public string? RecruiterLast { get; set; }

    public string? RecruiterFirst { get; set; }

    public string? RecruiterMiddle { get; set; }

    public DateTime? PostingDate { get; set; }

    public int? RankingQuestionnaireId { get; set; }

    public int? PrequalificationQuestionnaireId { get; set; }

    public int RequisitionStatusTypeId { get; set; }

    public string? ContactFirst { get; set; }

    public string? ContactLast { get; set; }

    public string? ContactMiddle { get; set; }

    public int Deleted { get; set; }

    public string? Hrisidentifier { get; set; }

    public double? Fte { get; set; }
}

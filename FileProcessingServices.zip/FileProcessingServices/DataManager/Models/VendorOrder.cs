﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class VendorOrder
{
    public int VendorOrderId { get; set; }

    public string? Description { get; set; }

    public string? VendorOrderIdentifier { get; set; }

    public int VendorId { get; set; }

    public int VendorOrderTypeId { get; set; }

    public int VendorOrderStatusTypeId { get; set; }

    public int VendorUserAccountId { get; set; }

    public string? StatusCode { get; set; }

    public string? StatusReason { get; set; }

    public string? OrderProcessingRedirectUrl { get; set; }

    public string? InviteUrl { get; set; }

    public string? ResultDescription { get; set; }

    public string? ResultLinkName { get; set; }

    public string? ResultLink { get; set; }

    public string? Score { get; set; }

    public bool? Passed { get; set; }

    public DateTime? CompletionDate { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public string? VendorOrderSubtypeIdentifier { get; set; }

    public int? VendorOfferingId { get; set; }

    public DateTime? ExpirationDate { get; set; }

    public virtual ICollection<ApplicationCommunication> ApplicationCommunications { get; set; } = new List<ApplicationCommunication>();

    public virtual ICollection<ApplicationVendorOrder> ApplicationVendorOrders { get; set; } = new List<ApplicationVendorOrder>();

    public virtual ICollection<AssessmentVendorOrder> AssessmentVendorOrders { get; set; } = new List<AssessmentVendorOrder>();

    public virtual ICollection<LocalApplicantVendorOrder> LocalApplicantVendorOrders { get; set; } = new List<LocalApplicantVendorOrder>();

    public virtual ICollection<RefactorVendorOrderVendorOrderDetailMapping> RefactorVendorOrderVendorOrderDetailMappings { get; set; } = new List<RefactorVendorOrderVendorOrderDetailMapping>();

    public virtual ICollection<ReferenceAssessmentReference> ReferenceAssessmentReferences { get; set; } = new List<ReferenceAssessmentReference>();

    public virtual ICollection<RequisitionVendorOrder> RequisitionVendorOrders { get; set; } = new List<RequisitionVendorOrder>();

    public virtual Vendor Vendor { get; set; } = null!;

    public virtual ICollection<VendorOrderDetail> VendorOrderDetails { get; set; } = new List<VendorOrderDetail>();

    public virtual ICollection<VendorOrderResult> VendorOrderResults { get; set; } = new List<VendorOrderResult>();

    public virtual VendorOrderStatusType VendorOrderStatusType { get; set; } = null!;

    public virtual ICollection<VendorOrderStatusTypeHistory> VendorOrderStatusTypeHistories { get; set; } = new List<VendorOrderStatusTypeHistory>();

    public virtual VendorOrderType VendorOrderType { get; set; } = null!;

    public virtual VendorUserAccount VendorUserAccount { get; set; } = null!;
}

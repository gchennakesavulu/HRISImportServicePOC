﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class FormTypeFieldCategory
{
    public int FormTypeFieldCategoryId { get; set; }

    public int FieldCategoryId { get; set; }

    public int FormTypeId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual FieldCategory FieldCategory { get; set; } = null!;

    public virtual FormType FormType { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ApplicationDocumentAcl
{
    public int ApplicationDocumentAclid { get; set; }

    public int ApplicationDocumentId { get; set; }

    public int? RoleTypeId { get; set; }

    public int? TmsuserId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ApplicationDocument ApplicationDocument { get; set; } = null!;

    public virtual RoleType? RoleType { get; set; }

    public virtual UserProfile? Tmsuser { get; set; }
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class UserPreference
{
    public int UserPreferenceId { get; set; }

    public int ClientSettingId { get; set; }

    public int TmsuserId { get; set; }

    public string Value { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ClientSetting ClientSetting { get; set; } = null!;

    public virtual Tmsuser Tmsuser { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class CareerSite
{
    public int CareerSiteId { get; set; }

    public string Name { get; set; } = null!;

    public int StartingBusinessEntityTypeId { get; set; }

    public int? EndingBusinessEntityTypeId { get; set; }

    public int SiteId { get; set; }

    public bool IsInternal { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    /// <summary>
    /// This Column Value decides whether the &apos;Application Status&apos; grid column in SubmittedApplicationHistory View in Career site gets displays or not.
    /// </summary>
    public bool DisplayApplicationStatusToJobSeeker { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<AcknowledgementCareerSite> AcknowledgementCareerSites { get; set; } = new List<AcknowledgementCareerSite>();

    public virtual ICollection<AcknowledgementPublished> AcknowledgementPublisheds { get; set; } = new List<AcknowledgementPublished>();

    public virtual ICollection<ApplicationStatusMessage> ApplicationStatusMessages { get; set; } = new List<ApplicationStatusMessage>();

    public virtual BusinessEntityType? EndingBusinessEntityType { get; set; }

    public virtual BusinessEntityType StartingBusinessEntityType { get; set; } = null!;

    public virtual ICollection<WebMessage> WebMessages { get; set; } = new List<WebMessage>();
}

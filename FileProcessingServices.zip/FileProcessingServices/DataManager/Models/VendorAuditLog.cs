﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class VendorAuditLog
{
    public int VendorAuditLogId { get; set; }

    public int VendorId { get; set; }

    public int TmsuserId { get; set; }

    public string Result { get; set; } = null!;

    public string Entity { get; set; } = null!;

    public string Operation { get; set; } = null!;

    public DateTime OperationTime { get; set; }

    public string? Reason { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual UserProfile Tmsuser { get; set; } = null!;

    public virtual Vendor Vendor { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class RequisitionStatusType
{
    public int RequisitionStatusTypeId { get; set; }

    public string? Name { get; set; }

    /// <summary>
    /// Flag used to indicate if type should be included in the Manage Applications Search&apos;s Job Posting Status filter.
    /// </summary>
    public bool ApplicantFilter { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<JobTemplatePropagationRequisitionStatusInstance> JobTemplatePropagationRequisitionStatusInstances { get; set; } = new List<JobTemplatePropagationRequisitionStatusInstance>();

    public virtual ICollection<Requisition> Requisitions { get; set; } = new List<Requisition>();

    public virtual ICollection<SettingsClientJobTemplatePropagationRequisitionStatusType> SettingsClientJobTemplatePropagationRequisitionStatusTypes { get; set; } = new List<SettingsClientJobTemplatePropagationRequisitionStatusType>();

    public virtual ICollection<SettingsWorkflowStep> SettingsWorkflowSteps { get; set; } = new List<SettingsWorkflowStep>();

    public virtual ICollection<SystemSearchStatusType> SystemSearchStatusTypes { get; set; } = new List<SystemSearchStatusType>();
}

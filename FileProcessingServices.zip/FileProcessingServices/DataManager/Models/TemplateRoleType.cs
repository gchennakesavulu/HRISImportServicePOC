﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class TemplateRoleType
{
    public int TemplateRoleTypeId { get; set; }

    public int TemplateId { get; set; }

    public int RoleTypeId { get; set; }

    public int SenderRecipient { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual RoleType RoleType { get; set; } = null!;

    public virtual Template Template { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class SettingsInternal
{
    public int SettingsInternalId { get; set; }

    public short MaxRoles { get; set; }

    public short MaxHierarchyLevels { get; set; }

    public short MaxQuestionsPerQuestionnaire { get; set; }

    public short MaxAnswersPerQuestion { get; set; }

    public short MaxCustomFormWidth { get; set; }

    public short MaxSavedSearches { get; set; }

    public int MaxRecentActivityRecords { get; set; }

    public bool RequisitionApprovalEnabled { get; set; }

    public bool RequisitionDocumentAttachEnabled { get; set; }

    public bool RequisitionDocumentAttachRequired { get; set; }

    public int MaxRequisitionAttachmentFileSize { get; set; }

    public short MaxRequisitionAttachmentFileCount { get; set; }

    public int MaxApplicationAttachmentFileSize { get; set; }

    public short MaxApplicationAttachmentFileCount { get; set; }

    public int MaxSeekerDocumentCount { get; set; }

    public bool SeekerAttachAdocEnabled { get; set; }

    public bool CareerMailEnabled { get; set; }

    public bool ResumeParsingEnabled { get; set; }

    /// <summary>
    /// Turn on and off &quot;Onboarding&quot; features for a given client.
    /// </summary>
    public bool OnBoardingEnabled { get; set; }

    public bool BackgroundChecksEnabled { get; set; }

    /// <summary>
    /// Turn on or off HRIS Integration features for a given client
    /// </summary>
    public bool HrisintegrationsEnabled { get; set; }

    public bool AssessmentsEnabled { get; set; }

    public bool AssessmentsRequired { get; set; }

    public bool ReferenceChecksEnabled { get; set; }

    public bool TalentPoolEnabled { get; set; }

    public bool EstablishHierarchyEnabled { get; set; }

    public bool SendPasswordEmailForImportedUsers { get; set; }

    public bool SearchEngineIndexingEnabled { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    /// <summary>
    /// Turn on and off &quot;Onboarding Enabled Mobile&quot; features for a given client.
    /// </summary>
    public bool MobileOnboardingEnabled { get; set; }

    /// <summary>
    /// If this is enabled Background Check Forms will be require
    /// </summary>
    public bool BackgroundCheckFormsRequired { get; set; }

    public bool ApplicantAnalyticsEnabled { get; set; }

    public bool TimezoneEnabled { get; set; }

    public int? PfmintegrationImportId { get; set; }

    public bool LeanCapitalIntegrationEnabled { get; set; }

    public int MaxNewHireAttachmentFileSize { get; set; }

    public short MaxNewHireAttachmentFileCount { get; set; }

    public bool ProviderIntegrationEnabled { get; set; }

    public virtual MetaValue? PfmintegrationImport { get; set; }

    public virtual ICollection<SettingsClient> SettingsClients { get; set; } = new List<SettingsClient>();
}

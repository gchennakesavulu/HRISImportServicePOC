﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class DocumentGroupOnBoardingDocument
{
    public int DocumentGroupOnBoardingDocumentId { get; set; }

    public int DocumentGroupId { get; set; }

    public int OnBoardingDocumentId { get; set; }

    public int Sequence { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual DocumentGroup DocumentGroup { get; set; } = null!;

    public virtual OnBoardingDocument OnBoardingDocument { get; set; } = null!;
}

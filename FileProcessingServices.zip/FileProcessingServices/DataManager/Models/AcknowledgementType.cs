﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class AcknowledgementType
{
    public int AcknowledgementTypeId { get; set; }

    public string Name { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<AcknowledgementPublished> AcknowledgementPublisheds { get; set; } = new List<AcknowledgementPublished>();

    public virtual ICollection<Acknowledgement> Acknowledgements { get; set; } = new List<Acknowledgement>();

    public virtual ICollection<ApplicationAcknowledgement> ApplicationAcknowledgements { get; set; } = new List<ApplicationAcknowledgement>();

    public virtual ICollection<SettingsWorkflowDefaultSequentialStep> SettingsWorkflowDefaultSequentialSteps { get; set; } = new List<SettingsWorkflowDefaultSequentialStep>();

    public virtual ICollection<SettingsWorkflowSequentialStep> SettingsWorkflowSequentialSteps { get; set; } = new List<SettingsWorkflowSequentialStep>();
}

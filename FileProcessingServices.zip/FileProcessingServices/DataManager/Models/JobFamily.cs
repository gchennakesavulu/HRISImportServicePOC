﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class JobFamily
{
    public int JobFamilyId { get; set; }

    public string Name { get; set; } = null!;

    public string JobFamilyIdentifier { get; set; } = null!;

    public short? DisplayOrder { get; set; }

    public int? ParentId { get; set; }

    public string JobFamilyAttribute { get; set; } = null!;

    public int? VendorId { get; set; }

    public int? NoExpJobFamilyId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<AssessmentVendorOrderDetail> AssessmentVendorOrderDetails { get; set; } = new List<AssessmentVendorOrderDetail>();

    public virtual ICollection<JobTemplateInstance> JobTemplateInstances { get; set; } = new List<JobTemplateInstance>();

    public virtual ICollection<JobTemplate> JobTemplates { get; set; } = new List<JobTemplate>();

    public virtual Vendor? Vendor { get; set; }

    public virtual ICollection<VendorOrderDetail> VendorOrderDetails { get; set; } = new List<VendorOrderDetail>();
}

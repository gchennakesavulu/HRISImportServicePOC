﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class DocumentGroup
{
    public int DocumentGroupId { get; set; }

    public string Name { get; set; } = null!;

    public string? Description { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<DocumentGroupBusinessEntity> DocumentGroupBusinessEntities { get; set; } = new List<DocumentGroupBusinessEntity>();

    public virtual ICollection<DocumentGroupJobTemplate> DocumentGroupJobTemplates { get; set; } = new List<DocumentGroupJobTemplate>();

    public virtual ICollection<DocumentGroupOnBoardingDocument> DocumentGroupOnBoardingDocuments { get; set; } = new List<DocumentGroupOnBoardingDocument>();
}

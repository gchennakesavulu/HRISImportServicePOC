﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class WebMessage
{
    public int WebMessageId { get; set; }

    public int CareerSiteId { get; set; }

    public string Name { get; set; } = null!;

    public DateTime StartDate { get; set; }

    public DateTime EndDate { get; set; }

    public bool DisplayFirst { get; set; }

    public string MessageText { get; set; } = null!;

    public string? BackgroundColor { get; set; }

    public bool HasBorder { get; set; }

    public decimal WidthPercent { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual CareerSite CareerSite { get; set; } = null!;
}

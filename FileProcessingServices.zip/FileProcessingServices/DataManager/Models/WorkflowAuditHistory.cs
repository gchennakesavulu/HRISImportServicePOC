﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class WorkflowAuditHistory
{
    public int WorkflowAuditHistoryId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    /// <summary>
    /// The user id of the user originating the action. 
    /// </summary>
    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    /// <summary>
    /// ID of the business object being audited, e.g. ApplicationID or RequisitionID
    /// </summary>
    public int ContextObjectId { get; set; }

    /// <summary>
    /// The new status type id assigned to the context object. If the audited change does not involve status change this value must be null.
    /// 
    /// NOTE: The set of values for this column depends on the WorkflowTypeID.
    /// </summary>
    public int? StatusTypeId { get; set; }

    /// <summary>
    /// Audit type ID describes the change if it does not result in status change. This field can be null if the status change happened and the value of StatusTypeID is not null. 
    /// 
    /// NOTE: The set of values for this column depends on the WorkflowTypeID.
    /// </summary>
    public int? AuditTypeId { get; set; }

    public string? Comment { get; set; }

    /// <summary>
    /// Workflow type ID of the process being audited, e.g. 1 - &quot;Internal Applicant&quot; or 3 - &quot;Requisition&quot;
    /// </summary>
    public int WorkflowTypeId { get; set; }

    /// <summary>
    /// User ID of the user who is the recipient of the action being audited. E.g. recruiter ID to whom a requisition is reassigned or an approver id who is assigned as the next approver.
    /// NOTE: The originator of the action is tracked in CreatedBy field.
    /// </summary>
    public int? RecipientTmsuserId { get; set; }

    public DateTime? StatusOverrideDate { get; set; }
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class TextMessageEventType
{
    public int TextMessageEventTypeId { get; set; }

    public string Name { get; set; } = null!;

    public string? Description { get; set; }

    public int Deleted { get; set; }

    public int Active { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<TextMessage> TextMessages { get; set; } = new List<TextMessage>();
}

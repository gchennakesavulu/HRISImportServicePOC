﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class OnBoardingDocument
{
    public int OnBoardingDocumentId { get; set; }

    public string DisplayName { get; set; } = null!;

    public string? TaskName { get; set; }

    public int TypeMetaValueId { get; set; }

    public int OnBoardingDocumentStateTypeId { get; set; }

    public string? FileName { get; set; }

    public string? FileLocation { get; set; }

    public DateTime? DateActivated { get; set; }

    public DateTime? DateInActivated { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public string? CardFlow { get; set; }

    public bool HreditEnabled { get; set; }

    public virtual ICollection<DocumentGroupOnBoardingDocument> DocumentGroupOnBoardingDocuments { get; set; } = new List<DocumentGroupOnBoardingDocument>();

    public virtual ICollection<OnBoardingDocumentBusinessEntity> OnBoardingDocumentBusinessEntities { get; set; } = new List<OnBoardingDocumentBusinessEntity>();

    public virtual ICollection<OnBoardingDocumentInstance> OnBoardingDocumentInstances { get; set; } = new List<OnBoardingDocumentInstance>();

    public virtual OnBoardingDocumentStateType OnBoardingDocumentStateType { get; set; } = null!;

    public virtual MetaValue TypeMetaValue { get; set; } = null!;
}

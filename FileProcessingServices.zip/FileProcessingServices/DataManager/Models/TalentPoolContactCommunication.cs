﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class TalentPoolContactCommunication
{
    public int TalentPoolContactCommunicationId { get; set; }

    public int TalentPoolContactId { get; set; }

    public int CommunicationId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual Communication Communication { get; set; } = null!;

    public virtual TalentPoolContact TalentPoolContact { get; set; } = null!;
}

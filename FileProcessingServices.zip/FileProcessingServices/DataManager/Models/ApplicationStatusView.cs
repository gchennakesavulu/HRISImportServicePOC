﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ApplicationStatusView
{
    public int? LocalApplicantId { get; set; }

    public int? NewActive { get; set; }

    public int? NotHired { get; set; }

    public int? Viable { get; set; }

    public int? Hired { get; set; }

    public long? Total { get; set; }
}

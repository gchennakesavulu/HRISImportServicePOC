﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class RequisitionView
{
    public int RequisitionId { get; set; }

    public int RequisitionStatusTypeId { get; set; }

    public int BusinessEntityId { get; set; }

    public int RecruiterId { get; set; }

    public int HiringManagerId { get; set; }

    public int? ApproverId { get; set; }

    public int CategoryId { get; set; }

    public int? JobPostingId { get; set; }

    public string? RequisitionNumber { get; set; }

    public string? RequisitionStatusType { get; set; }

    public string Organization { get; set; } = null!;

    public string PositionTitle { get; set; } = null!;

    public string? JobCategory { get; set; }

    public string? Shift { get; set; }

    public string? Schedule { get; set; }

    public string? JobCode { get; set; }

    public string? Hrisidentifier { get; set; }

    public bool? IsFeaturedJob { get; set; }

    public string? RecruiterFirstName { get; set; }

    public string? RecruiterLastName { get; set; }

    public string? RecruiterMiddleName { get; set; }

    public string? RecruiterPhone { get; set; }

    public string? HiringManagerFirstName { get; set; }

    public string? HiringManagerLastName { get; set; }

    public string? HiringManagerMiddleName { get; set; }

    public string? HiringManagerPhone { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public DateTime? JobTemplateInstanceModifiedDate { get; set; }

    public int IsInternalOnly { get; set; }

    public bool? StartAsInternalOnly { get; set; }

    public DateTime? StartDate { get; set; }

    public DateTime? EndDate { get; set; }

    public DateTime? EndInternalOnlyDate { get; set; }

    public DateTime? FilledDate { get; set; }

    public int Deleted { get; set; }

    public string? HiredApplicant { get; set; }

    public string? JobPostingTitle { get; set; }

    public double? Fte { get; set; }

    public string? Hours { get; set; }

    public int? ShiftId { get; set; }

    public int? ScheduleId { get; set; }

    public string JobPostingDisplayTitle { get; set; } = null!;

    public DateTime? JobPostingCreatedDate { get; set; }

    public bool? IsHiddenOnCareerSite { get; set; }
}

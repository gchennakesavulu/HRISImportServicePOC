﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class DatabaseVersionHistory
{
    public int DatabaseVersionHistoryId { get; set; }

    public string? PreviousVersionNumber { get; set; }

    public string NewVersionNumber { get; set; } = null!;

    public string ScriptName { get; set; } = null!;
}

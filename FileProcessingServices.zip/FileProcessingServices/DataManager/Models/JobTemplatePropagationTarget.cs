﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class JobTemplatePropagationTarget
{
    public int JobTemplatePropagationTargetId { get; set; }

    public string Name { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<JobTemplatePropagationJobSummary> JobTemplatePropagationJobSummaries { get; set; } = new List<JobTemplatePropagationJobSummary>();

    public virtual ICollection<JobTemplatePropagationRequisitionSyncErrorLog> JobTemplatePropagationRequisitionSyncErrorLogs { get; set; } = new List<JobTemplatePropagationRequisitionSyncErrorLog>();
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class JobDistributionJobInfo
{
    public int JobDistributionJobInfoId { get; set; }

    public int JobPostingId { get; set; }

    public int VendorId { get; set; }

    public int JobDistributionJobId { get; set; }

    public int InitiatedUser { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual Tmsuser InitiatedUserNavigation { get; set; } = null!;

    public virtual ICollection<JobDistributionPostingInfo> JobDistributionPostingInfos { get; set; } = new List<JobDistributionPostingInfo>();

    public virtual JobPosting JobPosting { get; set; } = null!;

    public virtual Vendor Vendor { get; set; } = null!;
}

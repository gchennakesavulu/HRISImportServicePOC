﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class Communication
{
    public int CommunicationId { get; set; }

    public int? ReplyToCommunicationId { get; set; }

    public int? ThreadId { get; set; }

    /// <summary>
    /// GroupSendDate links the communications that were sent as one group. For example when an applicaiton is sent to a manager, a number of additional communications may be created at the same time for tasks to fill custom forms, etc. CreatedDate may be different for them depending on how EntityFramework or other tool saved the groupped communications. The use of date allows the groups to be sortable and the groups defined uniquely enough for each communication thread.
    /// 
    /// </summary>
    public DateTime? GroupSendDate { get; set; }

    public int SenderUserId { get; set; }

    /// <summary>
    /// This column is required to record the sender user role type that participated in the communication at the time the communication was sent.
    /// </summary>
    public int SenderUserRoleTypeId { get; set; }

    public int? RecipientUserId { get; set; }

    /// <summary>
    /// This column is required to record the recipient user role type that participated in the communication at the time the communication was sent. 
    /// </summary>
    public int? RecipientUserRoleTypeId { get; set; }

    public string? SenderEmail { get; set; }

    public string? RecipientEmail { get; set; }

    public string? Ccemail { get; set; }

    public string? Bccemail { get; set; }

    public bool IsToApplicant { get; set; }

    public int? TemplateTypeId { get; set; }

    /// <summary>
    /// SubjectMetaValueID is the selected meta value ID in case communications subject is chosen from a set defied as a meta type. This vlue defines some other aspects of the communication, such as color of the flag in UI, etc. 
    /// </summary>
    public int? SubjectMetaValueId { get; set; }

    public string? Subject { get; set; }

    public string? Body { get; set; }

    public int? TaskId { get; set; }

    public int? SavedAsDocumentId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public bool HasAttachments { get; set; }

    public bool IsNoReply { get; set; }

    public bool IsHidden { get; set; }

    public virtual ICollection<ApplicationCommunication> ApplicationCommunications { get; set; } = new List<ApplicationCommunication>();

    public virtual ICollection<ApplicationMostRecent> ApplicationMostRecents { get; set; } = new List<ApplicationMostRecent>();

    public virtual ICollection<CommunicationCcBccUserProfile> CommunicationCcBccUserProfiles { get; set; } = new List<CommunicationCcBccUserProfile>();

    public virtual ICollection<CommunicationDocument> CommunicationDocuments { get; set; } = new List<CommunicationDocument>();

    public virtual ICollection<Communication> InverseReplyToCommunication { get; set; } = new List<Communication>();

    public virtual UserProfile? RecipientUser { get; set; }

    public virtual RoleType? RecipientUserRoleType { get; set; }

    public virtual Communication? ReplyToCommunication { get; set; }

    public virtual Document? SavedAsDocument { get; set; }

    public virtual UserProfile SenderUser { get; set; } = null!;

    public virtual RoleType SenderUserRoleType { get; set; } = null!;

    public virtual MetaValue? SubjectMetaValue { get; set; }

    public virtual ICollection<TalentPoolContactCommunication> TalentPoolContactCommunications { get; set; } = new List<TalentPoolContactCommunication>();

    public virtual Task? Task { get; set; }

    public virtual TemplateType? TemplateType { get; set; }
}

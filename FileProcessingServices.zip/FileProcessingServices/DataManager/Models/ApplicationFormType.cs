﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ApplicationFormType
{
    public int ApplicationFormTypeId { get; set; }

    public string Name { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<ApplicationFieldValue> ApplicationFieldValues { get; set; } = new List<ApplicationFieldValue>();

    public virtual ICollection<ApplicationForm> ApplicationForms { get; set; } = new List<ApplicationForm>();

    public virtual ICollection<SettingsWorkflowDefaultSequentialStep> SettingsWorkflowDefaultSequentialSteps { get; set; } = new List<SettingsWorkflowDefaultSequentialStep>();

    public virtual ICollection<SettingsWorkflowSequentialStep> SettingsWorkflowSequentialSteps { get; set; } = new List<SettingsWorkflowSequentialStep>();
}

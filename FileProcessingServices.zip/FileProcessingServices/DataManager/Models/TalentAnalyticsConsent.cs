﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class TalentAnalyticsConsent
{
    public int TalentAnalyticsConsentId { get; set; }

    public bool IsConsented { get; set; }

    public string ConsentFullName { get; set; } = null!;

    public DateTime DateConsented { get; set; }

    public string? Ipaddress { get; set; }

    public int TmsuserId { get; set; }

    public int? TalentAnalyticsConsentTermsConditionsId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual TalentAnalyticsConsentTermsCondition? TalentAnalyticsConsentTermsConditions { get; set; }

    public virtual UserProfile Tmsuser { get; set; } = null!;
}

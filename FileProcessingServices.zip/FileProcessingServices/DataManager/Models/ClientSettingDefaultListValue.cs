﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ClientSettingDefaultListValue
{
    public int ClientSettingDefaultListValuesId { get; set; }

    public int ClientSettingId { get; set; }

    public int MetaValueId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ClientSetting ClientSetting { get; set; } = null!;

    public virtual MetaValue MetaValue { get; set; } = null!;
}

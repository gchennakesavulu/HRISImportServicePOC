﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class VendorOrderResult
{
    public int VendorOrderResultId { get; set; }

    public int VendorOrderId { get; set; }

    public string Identifier { get; set; } = null!;

    public string Value { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual VendorOrder VendorOrder { get; set; } = null!;
}

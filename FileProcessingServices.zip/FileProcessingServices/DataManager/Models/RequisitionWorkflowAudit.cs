﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class RequisitionWorkflowAudit
{
    public int RequisitionWorkflowAuditId { get; set; }

    /// <summary>
    /// No foreign key to dbo.Requisition.RequisitionID due to contention problems with the Requisition Workflow accessing the same Requisition record that in some scenarios is locked by PM.
    /// 
    /// We will add the foreign key back once the contention problem has been address.
    /// </summary>
    public int RequisitionId { get; set; }

    public int? RequisitionStatusTypeId { get; set; }

    public int RequisitionAuditTypeId { get; set; }

    public int? TmsuserId { get; set; }

    public string? Comment { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }
}

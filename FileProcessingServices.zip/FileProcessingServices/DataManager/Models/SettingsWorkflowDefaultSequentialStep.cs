﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class SettingsWorkflowDefaultSequentialStep
{
    public int SettingsWorkflowDefaultSequentialStepId { get; set; }

    public int SettingsWorkflowId { get; set; }

    public int? DocumentTypeId { get; set; }

    public int? ApplicationFormId { get; set; }

    public int? ApplicationFormTypeId { get; set; }

    /// <summary>
    /// If step is Acknowledgement then need to select AcknowledgementTypeId which allows to identify this step is for the acknowldgement with specific type
    /// </summary>
    public int? AcknowledgementTypeId { get; set; }

    public string Name { get; set; } = null!;

    public int Sequence { get; set; }

    public string ControlName { get; set; } = null!;

    public bool IsRequired { get; set; }

    public bool SnapshotRequired { get; set; }

    public bool Active { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual AcknowledgementType? AcknowledgementType { get; set; }

    public virtual ApplicationForm? ApplicationForm { get; set; }

    public virtual ApplicationFormType? ApplicationFormType { get; set; }

    public virtual DocumentType? DocumentType { get; set; }

    public virtual SettingsWorkflow SettingsWorkflow { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class AccountStateType
{
    public int AccountStateTypeId { get; set; }

    public string Name { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<Tmsuser> Tmsusers { get; set; } = new List<Tmsuser>();

    public virtual ICollection<UserAccountStateTypeHistory> UserAccountStateTypeHistories { get; set; } = new List<UserAccountStateTypeHistory>();
}

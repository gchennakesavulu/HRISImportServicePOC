﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class NewHireView
{
    public int NewHireId { get; set; }

    public int ApplicationId { get; set; }

    public int NewHireStatusTypeId { get; set; }

    public DateTime? OnBoardingDate { get; set; }

    public int? NewHireFormId { get; set; }

    public int RequisitionId { get; set; }

    public string ApplicantLastName { get; set; } = null!;

    public string ApplicantFirstName { get; set; } = null!;

    public string ApplicantName { get; set; } = null!;

    public bool IsInternal { get; set; }

    public DateTime ApplicationDate { get; set; }

    public string ApplicationType { get; set; } = null!;

    public string? CurrentStatus { get; set; }

    public string CurrentStatusFullName { get; set; } = null!;

    public DateTime? ApplicationStatusDate { get; set; }

    public string RequisitionTitle { get; set; } = null!;

    public string? RequisitionNumber { get; set; }

    public int? ApplicantId { get; set; }

    public int? LocalApplicantId { get; set; }

    public long NoteCount { get; set; }

    public int NewActive { get; set; }

    public int NotHired { get; set; }

    public int Viable { get; set; }

    public int Hired { get; set; }

    public int BusinessEntityId { get; set; }

    public string Organization { get; set; } = null!;

    public int ApplicationStatusTypeId { get; set; }

    public int ApplicationTypeId { get; set; }

    public int RecruiterId { get; set; }

    public int HiringManagerId { get; set; }

    public string? Email { get; set; }

    public string? ApplicantMiddleName { get; set; }

    public string? PhoneNumber { get; set; }

    public string? PhoneType { get; set; }

    public string? Street1 { get; set; }

    public string? Street2 { get; set; }

    public string? City { get; set; }

    public string? State { get; set; }

    public string? Country { get; set; }

    public string? Zipcode { get; set; }

    public string? JobCode { get; set; }

    public string? LocalApplicantLastName { get; set; }

    public string? LocalApplicantFirstName { get; set; }

    public string? LocalApplicantMiddleName { get; set; }

    public string? LocalApplicantName { get; set; }

    public string? LocalStreet1 { get; set; }

    public string? LocalStreet2 { get; set; }

    public string? LocalCity { get; set; }

    public string? LocalState { get; set; }

    public string? LcoalCountry { get; set; }

    public string? LocalZipcode { get; set; }

    public string? LocalPhoneNumber { get; set; }

    public string? LocalPhoneType { get; set; }

    public string? LocalEmail { get; set; }

    public int Deleted { get; set; }

    public DateTime? StartDate { get; set; }

    public bool HasResumeDocument { get; set; }

    public string? RecruiterName { get; set; }

    public bool HasCoverLetter { get; set; }

    public bool HasApplicationDocument { get; set; }

    public bool HasShortApplicationDocument { get; set; }

    public DateTime? OrientationDate { get; set; }

    public DateTime? OrientationDate2 { get; set; }

    public DateTime? OrientationDate3 { get; set; }

    public DateTime? OrientationDate4 { get; set; }
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class JobDistributionPostingInfo
{
    public int JobDistributionPostingInfoId { get; set; }

    public int JobDistributionJobInfoId { get; set; }

    public int JobDistributionPostingId { get; set; }

    public string SiteName { get; set; } = null!;

    public string? TotalCost { get; set; }

    public int? NumberOfClicks { get; set; }

    public int? NumberOfApplies { get; set; }

    public string? JobBoardStatus { get; set; }

    public DateTime? OrderDate { get; set; }

    public DateTime? ExpirationDate { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public bool? Incomplete { get; set; }

    public virtual JobDistributionJobInfo JobDistributionJobInfo { get; set; } = null!;
}

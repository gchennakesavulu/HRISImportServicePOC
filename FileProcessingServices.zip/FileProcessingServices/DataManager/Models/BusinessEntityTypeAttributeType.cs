﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class BusinessEntityTypeAttributeType
{
    public int BusinessEntityTypeAttributeTypeId { get; set; }

    public int BusinessEntityTypeId { get; set; }

    public int AttributeTypeId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual AttributeType AttributeType { get; set; } = null!;

    public virtual BusinessEntityType BusinessEntityType { get; set; } = null!;
}

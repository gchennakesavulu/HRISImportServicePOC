﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ApplicationShiftView
{
    public int ApplicationId { get; set; }

    public string? Shift { get; set; }
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ApplicationInternalNoteView
{
    public int ApplicationId { get; set; }

    public long? NoteCount { get; set; }
}

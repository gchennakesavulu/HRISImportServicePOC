﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class WorkflowAssociation
{
    public int WorkflowAssociationId { get; set; }

    public int SettingsWorkflowId { get; set; }

    public int ParentSettingsWorkflowId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual SettingsWorkflow ParentSettingsWorkflow { get; set; } = null!;

    public virtual SettingsWorkflow SettingsWorkflow { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ReportCategory
{
    public int ReportCategoryId { get; set; }

    public string Name { get; set; } = null!;

    /// <summary>
    /// IsHidden can be used to specify a set of reports to make unavailable. (e.g. not show in the UI)
    /// </summary>
    public bool IsHidden { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<Report> Reports { get; set; } = new List<Report>();
}

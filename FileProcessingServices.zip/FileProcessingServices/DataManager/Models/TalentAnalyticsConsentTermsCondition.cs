﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class TalentAnalyticsConsentTermsCondition
{
    public int TalentAnalyticsConsentTermsConditionsId { get; set; }

    public string TermsConditionsName { get; set; } = null!;

    public string ConsentText { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<TalentAnalyticsConsent> TalentAnalyticsConsents { get; set; } = new List<TalentAnalyticsConsent>();
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class JobDistributionJobSync
{
    public int JobDistributionJobSyncId { get; set; }

    public int VendorId { get; set; }

    public DateTime? LastSyncDate { get; set; }

    public bool IsFullLoad { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual Vendor Vendor { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ApplicationApplicationForm
{
    public int ApplicationApplicationFormId { get; set; }

    public int ApplicationId { get; set; }

    public int ApplicationFormId { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public int Deleted { get; set; }

    public virtual Application Application { get; set; } = null!;

    public virtual ApplicationForm ApplicationForm { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ApplicationGroup
{
    public int ApplicationGroupId { get; set; }

    public string Name { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<ApplicationFieldValue> ApplicationFieldValues { get; set; } = new List<ApplicationFieldValue>();

    public virtual ICollection<ApplicationFormBinderMetaDatum> ApplicationFormBinderMetaData { get; set; } = new List<ApplicationFormBinderMetaDatum>();

    public virtual ICollection<FieldTag> FieldTags { get; set; } = new List<FieldTag>();

    public virtual ICollection<HrXmlMap> HrXmlMaps { get; set; } = new List<HrXmlMap>();
}

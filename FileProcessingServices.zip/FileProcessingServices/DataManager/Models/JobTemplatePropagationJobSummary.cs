﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class JobTemplatePropagationJobSummary
{
    public int JobTemplatePropagationJobSummaryId { get; set; }

    public int JobTemplatePropagationJobInstanceId { get; set; }

    public int JobTemplatePropagationTargetId { get; set; }

    public DateTime StartDate { get; set; }

    public DateTime? QueuedDate { get; set; }

    public DateTime? ProcessingDate { get; set; }

    public DateTime? EndDate { get; set; }

    public int Status { get; set; }

    public string? StatusMessage { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual JobTemplatePropagationJobInstance JobTemplatePropagationJobInstance { get; set; } = null!;

    public virtual JobTemplatePropagationTarget JobTemplatePropagationTarget { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class InterviewParticipant
{
    public int InterviewParticipantId { get; set; }

    public int InterviewId { get; set; }

    public int TmsuserId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual Interview Interview { get; set; } = null!;

    public virtual Tmsuser Tmsuser { get; set; } = null!;
}

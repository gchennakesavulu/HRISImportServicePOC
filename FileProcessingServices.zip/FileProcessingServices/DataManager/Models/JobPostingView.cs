﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class JobPostingView
{
    public int JobPostingId { get; set; }

    public string Title { get; set; } = null!;

    public string? JobSummary { get; set; }

    public string? FacilityDescription { get; set; }

    public int? FormId { get; set; }

    public int JobCategoryId { get; set; }

    public DateTime StartDate { get; set; }

    public DateTime? EndInternalOnlyDate { get; set; }

    public DateTime? EndDate { get; set; }

    public bool StartAsInternalOnly { get; set; }

    public bool Active { get; set; }

    public bool IsFeaturedJob { get; set; }

    public int RequisitionId { get; set; }

    public int BusinessEntityId { get; set; }

    public int JobTemplateInstanceId { get; set; }

    public string? RequisitionNumber { get; set; }

    public string Name { get; set; } = null!;

    public string? Code { get; set; }

    public string? JobDescription { get; set; }

    public string? Hours { get; set; }

    public int? ScheduleId { get; set; }

    public int? ShiftId { get; set; }

    public bool IsAvailableInJobAgent { get; set; }

    public int? ScheduleMetaValueId { get; set; }

    public int? ScheduleMetaTypeId { get; set; }

    public string? ScheduleName { get; set; }

    public int? ScheduleSequence { get; set; }

    public int? ShiftMetaValueId { get; set; }

    public int? ShiftMetaTypeId { get; set; }

    public string? ShiftName { get; set; }

    public int? ShiftSequence { get; set; }

    public int? CategoryMetaValueId { get; set; }

    public int? CategoryMetaTypeId { get; set; }

    public string? CategoryName { get; set; }

    public int? CategorySequence { get; set; }

    public string? PayGrade { get; set; }

    public string? SalaryRange { get; set; }

    public double? Fte { get; set; }

    public string? LocationAddress1 { get; set; }

    public string? LocationAddress2 { get; set; }

    public string? LocationCity { get; set; }

    public string? LocationState { get; set; }

    public string? LocationZipCode { get; set; }

    public bool? GeocodeValid { get; set; }

    public decimal? LocationLatitude { get; set; }

    public decimal? LocationLongitude { get; set; }

    public int? EducationMetaValueId { get; set; }

    public int? EducationMetaTypeId { get; set; }

    public string? EducationName { get; set; }

    public int? EducationSequence { get; set; }

    public bool? DisplayContactInfo { get; set; }

    public bool DisplayContactName { get; set; }

    public bool DisplayContactAddress { get; set; }

    public bool DisplayEmailAddress { get; set; }

    public bool DisplayPhoneNumber { get; set; }

    public bool DisplayFaxNumber { get; set; }

    public string? ContactFirstName { get; set; }

    public string? ContactLastName { get; set; }

    public string? EmailAddress { get; set; }

    public string? Address { get; set; }

    public string? City { get; set; }

    public string? State { get; set; }

    public string? Zipcode { get; set; }

    public string? PhoneNumber { get; set; }

    public string? FaxNumber { get; set; }

    public bool IsHiddenOnCareerSite { get; set; }
}

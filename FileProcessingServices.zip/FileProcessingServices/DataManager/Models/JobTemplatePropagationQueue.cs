﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class JobTemplatePropagationQueue
{
    public int JobTemplatePropagationQueueId { get; set; }

    public string Uuid { get; set; } = null!;

    public int QueueType { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }
}

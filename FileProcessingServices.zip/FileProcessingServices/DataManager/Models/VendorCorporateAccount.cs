﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class VendorCorporateAccount
{
    public int VendorCorporateAccountId { get; set; }

    public string AccountIdentifier { get; set; } = null!;

    public int VendorId { get; set; }

    public int BusinessEntityId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public string? Password { get; set; }

    public string? Salt { get; set; }

    public virtual BusinessEntity BusinessEntity { get; set; } = null!;

    public virtual Vendor Vendor { get; set; } = null!;

    public virtual ICollection<VendorCorporateAccountVendorUserAccount> VendorCorporateAccountVendorUserAccounts { get; set; } = new List<VendorCorporateAccountVendorUserAccount>();
}

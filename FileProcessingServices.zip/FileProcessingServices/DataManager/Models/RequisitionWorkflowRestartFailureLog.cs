﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class RequisitionWorkflowRestartFailureLog
{
    public int RequisitionWorkflowRestartFailureLogId { get; set; }

    public int RequisitionId { get; set; }

    public int WorkflowProcessId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }
}

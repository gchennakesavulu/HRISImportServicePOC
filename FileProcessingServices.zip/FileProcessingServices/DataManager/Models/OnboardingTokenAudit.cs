﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class OnboardingTokenAudit
{
    public int OnboardingTokenAuditId { get; set; }

    public string Token { get; set; } = null!;

    public int ApplicationId { get; set; }

    public string TokenData { get; set; } = null!;

    public bool WasSuccessful { get; set; }

    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string LastFourSsn { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }
}

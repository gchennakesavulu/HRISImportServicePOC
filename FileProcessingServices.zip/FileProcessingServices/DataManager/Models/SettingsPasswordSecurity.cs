﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class SettingsPasswordSecurity
{
    public int SettingsPasswordSecurityId { get; set; }

    public int MinPasswordLength { get; set; }

    public bool UseCapitalLetter { get; set; }

    public bool UseNumber { get; set; }

    public bool UseSpecialCharacter { get; set; }

    public int CareerSiteExpireDays { get; set; }

    public int ExpireDays { get; set; }

    public int MaxPasswordRetries { get; set; }

    public int PasswordReuseCount { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }
}

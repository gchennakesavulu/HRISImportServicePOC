﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class Role
{
    public int RoleId { get; set; }

    public int RoleTypeId { get; set; }

    public string Name { get; set; } = null!;

    public string? Description { get; set; }

    public bool IsSystemRole { get; set; }

    public int? MyOwnAcldataSourceTypeId { get; set; }

    public bool SuiteConfigurationAccess { get; set; }

    public int DashboardCountTypeId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public int CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<RolePermission> RolePermissions { get; set; } = new List<RolePermission>();

    public virtual RoleType1 RoleType { get; set; } = null!;

    public virtual ICollection<TmsuserRole> TmsuserRoles { get; set; } = new List<TmsuserRole>();
}

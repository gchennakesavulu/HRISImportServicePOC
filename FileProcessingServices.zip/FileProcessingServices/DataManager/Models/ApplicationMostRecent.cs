﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ApplicationMostRecent
{
    public int ApplicationMostRecentId { get; set; }

    public int ApplicationId { get; set; }

    /// <summary>
    /// Denormalized column to store the latest applicant score
    /// </summary>
    public decimal? Score { get; set; }

    /// <summary>
    /// Denormalized column to store the latest Hiring Manager score
    /// </summary>
    public decimal? Hmscore { get; set; }

    /// <summary>
    /// Denormalized column to store the latest Recruiter score
    /// </summary>
    public decimal? Hrscore { get; set; }

    /// <summary>
    /// Denormalized column to store the latest Hiring Manager Response CommunicationID. We need to store the Hiring Manager latest CommunicationID to help reduce the query time and improve performance as getting the latest Hiring Manager Response CommunicationID of the application requires subquery to find the max communicationID of the Hiring Manager.
    /// </summary>
    public int? HmresponseLatestCommunicationId { get; set; }

    public bool RespondedToHmlatestCommunication { get; set; }

    public int? EducationId { get; set; }

    public int? ExperienceId { get; set; }

    public int? LicensureId { get; set; }

    public string? ShiftIds { get; set; }

    public string? ScheduleIds { get; set; }

    public int? RankingQuestionnaireId { get; set; }

    /// <summary>
    /// Denormalized column to store the latest Background Check Status tied to an application. We need to store the BackgroundCheckStatusTypeID to help reduce the query time and improve performance.
    /// </summary>
    public int? BackgroundCheckStatusTypeId { get; set; }

    /// <summary>
    /// Denormalized column to store the latest Test Assessment Status Type  tied to an application. We need to store the TestAssessmentStatusTypeID to help reduce the query time and improve performance.
    /// </summary>
    public int? TestAssessmentStatusTypeId { get; set; }

    /// <summary>
    /// Denormalized column to store the latest Reference Check Status Type  tied to an application. We need to store the ReferenceCheckStatusTypeID to help reduce the query time and improve performance.
    /// </summary>
    public int? ReferenceCheckStatusTypeId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public int? ApplicantAnalyticsStatusTypeId { get; set; }

    public virtual Application Application { get; set; } = null!;

    public virtual VendorOrderStatusType? BackgroundCheckStatusType { get; set; }

    public virtual Communication? HmresponseLatestCommunication { get; set; }

    public virtual Questionnaire? RankingQuestionnaire { get; set; }

    public virtual VendorOrderStatusType? ReferenceCheckStatusType { get; set; }

    public virtual VendorOrderStatusType? TestAssessmentStatusType { get; set; }
}

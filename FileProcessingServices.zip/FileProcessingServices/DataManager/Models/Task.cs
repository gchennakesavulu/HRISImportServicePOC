﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class Task
{
    public int TaskId { get; set; }

    public int TaskTypeId { get; set; }

    public string Name { get; set; } = null!;

    public int OriginatorUserId { get; set; }

    public int AssignedToUserId { get; set; }

    public int? AssignedToRoleTypeId { get; set; }

    public int TaskStatusTypeId { get; set; }

    public DateTime TaskStatusDate { get; set; }

    public int ContextObjectId { get; set; }

    public int ContextDataSourceTypeId { get; set; }

    /// <summary>
    /// Object that is the target of the task
    /// </summary>
    public int TargetObjectId { get; set; }

    public int TargetDataSourceTypeId { get; set; }

    /// <summary>
    /// IsVisible - control visibility of the task in UI.
    /// Tasks are always created in the scenarios where they are needed whether a user explicitly requests them, explicitly asks not to create them in UI, or when task creation is disabled by a setting.
    /// This user election will define only the visibility of a task in the UI and the ability of the user to manage the task. If the task is not visible, it will be automatically managed by the system.
    /// 
    /// </summary>
    public bool IsVisible { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual RoleType? AssignedToRoleType { get; set; }

    public virtual UserProfile AssignedToUser { get; set; } = null!;

    public virtual ICollection<Communication> Communications { get; set; } = new List<Communication>();

    public virtual DataSourceType ContextDataSourceType { get; set; } = null!;

    public virtual UserProfile OriginatorUser { get; set; } = null!;

    public virtual DataSourceType TargetDataSourceType { get; set; } = null!;

    public virtual TaskStatusType TaskStatusType { get; set; } = null!;

    public virtual TaskType TaskType { get; set; } = null!;
}

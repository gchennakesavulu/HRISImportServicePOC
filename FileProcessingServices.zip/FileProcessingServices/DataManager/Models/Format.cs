﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class Format
{
    public int FormatId { get; set; }

    public int ControlTypeId { get; set; }

    public string Name { get; set; } = null!;

    public string? Description { get; set; }

    public string? Mask { get; set; }

    public string? ValidationExpression { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ControlType ControlType { get; set; } = null!;

    public virtual ICollection<FormMetaType> FormMetaTypes { get; set; } = new List<FormMetaType>();
}

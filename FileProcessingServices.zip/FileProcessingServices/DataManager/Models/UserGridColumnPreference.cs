﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class UserGridColumnPreference
{
    public int UserGridColumnPreferencesId { get; set; }

    public int TmsuserId { get; set; }

    public int GridTypeId { get; set; }

    public string ColumnDefinitions { get; set; } = null!;

    public string CustomFormFields { get; set; } = null!;

    public string? DefaultSortModel { get; set; }

    public int? DefaultPageSize { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual GridType GridType { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class OnBoardingWelcomeMessage
{
    public int OnBoardingWelcomeMessageId { get; set; }

    public string Name { get; set; } = null!;

    public int BusinessEntityId { get; set; }

    public bool Active { get; set; }

    public string MessageText { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual BusinessEntity BusinessEntity { get; set; } = null!;
}

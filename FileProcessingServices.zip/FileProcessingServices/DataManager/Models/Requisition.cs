﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class Requisition
{
    public int RequisitionId { get; set; }

    public int BusinessEntityId { get; set; }

    public int JobTemplateInstanceId { get; set; }

    public int FormId { get; set; }

    public int RequisitionStatusTypeId { get; set; }

    public int? OpenReasonMetaValueId { get; set; }

    public string? CreatorApprovalComment { get; set; }

    public int? FilledByApplicantId { get; set; }

    /// <summary>
    /// This is the date the Requisition was moved to &apos;Filled&apos; Status, or Null if not in that status.
    /// </summary>
    public DateTime? FilledDate { get; set; }

    public double? Fte { get; set; }

    public string? RequisitionNumber { get; set; }

    public int RecruiterId { get; set; }

    public int HiringManagerId { get; set; }

    /// <summary>
    /// Represents the TMSUserID of the current approver of the requisition.  If the requisition is not in the approval process, the value should be NULL.  
    /// </summary>
    public int? ApproverId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public bool PreventPosting { get; set; }

    public bool IncludeHmcommunication { get; set; }

    public virtual ICollection<Application> Applications { get; set; } = new List<Application>();

    public virtual UserProfile? Approver { get; set; }

    public virtual BusinessEntity BusinessEntity { get; set; } = null!;

    public virtual LocalApplicant? FilledByApplicant { get; set; }

    public virtual Form Form { get; set; } = null!;

    public virtual UserProfile HiringManager { get; set; } = null!;

    public virtual ICollection<HrarequisitionLock> HrarequisitionLocks { get; set; } = new List<HrarequisitionLock>();

    public virtual ICollection<JobPosting> JobPostings { get; set; } = new List<JobPosting>();

    public virtual JobTemplateInstance JobTemplateInstance { get; set; } = null!;

    public virtual ICollection<JobTemplatePropagationRequisition> JobTemplatePropagationRequisitions { get; set; } = new List<JobTemplatePropagationRequisition>();

    public virtual ICollection<NewHire> NewHires { get; set; } = new List<NewHire>();

    public virtual MetaValue? OpenReasonMetaValue { get; set; }

    public virtual UserProfile Recruiter { get; set; } = null!;

    public virtual ICollection<RequisitionAcl> RequisitionAcls { get; set; } = new List<RequisitionAcl>();

    public virtual ICollection<RequisitionAdditionalUser> RequisitionAdditionalUsers { get; set; } = new List<RequisitionAdditionalUser>();

    public virtual ICollection<RequisitionApprover> RequisitionApprovers { get; set; } = new List<RequisitionApprover>();

    public virtual ICollection<RequisitionDocument> RequisitionDocuments { get; set; } = new List<RequisitionDocument>();

    public virtual ICollection<RequisitionFieldValue> RequisitionFieldValues { get; set; } = new List<RequisitionFieldValue>();

    public virtual RequisitionStatusType RequisitionStatusType { get; set; } = null!;

    public virtual ICollection<RequisitionVendorOrder> RequisitionVendorOrders { get; set; } = new List<RequisitionVendorOrder>();
}

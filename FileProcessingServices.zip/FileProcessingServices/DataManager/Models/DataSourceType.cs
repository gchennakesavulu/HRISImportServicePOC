﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class DataSourceType
{
    public int DataSourceTypeId { get; set; }

    public int ScopeLevelId { get; set; }

    public string TableName { get; set; } = null!;

    public string TableResourceLookUpKey { get; set; } = null!;

    public int DatabaseConfigurationId { get; set; }

    public int ResourceManagerKeyId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<DataSourceFieldType> DataSourceFieldTypes { get; set; } = new List<DataSourceFieldType>();

    public virtual ICollection<FormType> FormTypes { get; set; } = new List<FormType>();

    public virtual ICollection<Note> Notes { get; set; } = new List<Note>();

    public virtual ICollection<RecentActivity> RecentActivities { get; set; } = new List<RecentActivity>();

    public virtual ICollection<Search> Searches { get; set; } = new List<Search>();

    public virtual ICollection<SystemSearch> SystemSearches { get; set; } = new List<SystemSearch>();

    public virtual ICollection<Task> TaskContextDataSourceTypes { get; set; } = new List<Task>();

    public virtual ICollection<Task> TaskTargetDataSourceTypes { get; set; } = new List<Task>();
}

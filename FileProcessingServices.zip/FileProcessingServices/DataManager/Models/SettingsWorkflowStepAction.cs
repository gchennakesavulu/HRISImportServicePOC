﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class SettingsWorkflowStepAction
{
    public int SettingsWorkflowStepActionId { get; set; }

    /// <summary>
    /// This is a temporary column until Requsition Audit is completed, at which point it should be removed.
    /// </summary>
    public int? RequisitionAuditTypeId { get; set; }

    public int SettingsWorkflowStepId { get; set; }

    public string Name { get; set; } = null!;

    public string? DisplayNameResourceKey { get; set; }

    public string? AuditEntryResourceKey { get; set; }

    public bool IsUserAction { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public int Deleted { get; set; }

    public virtual RequisitionAuditType? RequisitionAuditType { get; set; }

    public virtual SettingsWorkflowStep SettingsWorkflowStep { get; set; } = null!;
}

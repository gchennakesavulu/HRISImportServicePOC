﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ApplicationStatusType
{
    public int ApplicationStatusTypeId { get; set; }

    public string Name { get; set; } = null!;

    public string? ShortName { get; set; }

    /// <summary>
    /// A column to indicate if a disposition is associated with a given status.
    /// </summary>
    public bool IsDispositionApplicable { get; set; }

    /// <summary>
    /// A column to store the default message displayed to the applicant.
    /// </summary>
    public string? DefaultMessage { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public int? Sequence { get; set; }

    public virtual ICollection<ApplicationStatusFullMessage> ApplicationStatusFullMessages { get; set; } = new List<ApplicationStatusFullMessage>();

    public virtual ICollection<ApplicationStatusMessage> ApplicationStatusMessages { get; set; } = new List<ApplicationStatusMessage>();

    public virtual ICollection<Application> Applications { get; set; } = new List<Application>();

    public virtual ICollection<SettingsApplyLimitApplicationStatusType> SettingsApplyLimitApplicationStatusTypes { get; set; } = new List<SettingsApplyLimitApplicationStatusType>();

    public virtual ICollection<SettingsWorkflowStep> SettingsWorkflowSteps { get; set; } = new List<SettingsWorkflowStep>();

    public virtual ICollection<SystemSearchStatusType> SystemSearchStatusTypes { get; set; } = new List<SystemSearchStatusType>();
}

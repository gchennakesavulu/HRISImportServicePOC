﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class NewHire
{
    public int NewHireId { get; set; }

    public int ApplicationId { get; set; }

    public int RequisitionId { get; set; }

    public int NewHireStatusTypeId { get; set; }

    public int? NewHireFormId { get; set; }

    public DateTime? OnBoardingDate { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual Application Application { get; set; } = null!;

    public virtual ICollection<FailedProviderNewHireApplication> FailedProviderNewHireApplications { get; set; } = new List<FailedProviderNewHireApplication>();

    public virtual ICollection<NewHireDocument> NewHireDocuments { get; set; } = new List<NewHireDocument>();

    public virtual ICollection<NewHireFieldValue> NewHireFieldValues { get; set; } = new List<NewHireFieldValue>();

    public virtual Form? NewHireForm { get; set; }

    public virtual NewHireStatusType NewHireStatusType { get; set; } = null!;

    public virtual ICollection<OnBoardingDocumentInstance> OnBoardingDocumentInstances { get; set; } = new List<OnBoardingDocumentInstance>();

    public virtual Requisition Requisition { get; set; } = null!;
}

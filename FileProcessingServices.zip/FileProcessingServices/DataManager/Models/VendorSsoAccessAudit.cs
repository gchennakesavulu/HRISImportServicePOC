﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class VendorSsoAccessAudit
{
    public int VendorSsoAccessAuditId { get; set; }

    public int TmsuserId { get; set; }

    public int VendorId { get; set; }

    public int VendorSsoAccessOperationId { get; set; }

    public DateTime VendorSsoAccessAuditDate { get; set; }

    public virtual UserProfile Tmsuser { get; set; } = null!;
}

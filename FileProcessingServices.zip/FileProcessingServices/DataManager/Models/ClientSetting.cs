﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ClientSetting
{
    public int ClientSettingId { get; set; }

    public string? Name { get; set; }

    public string? Description { get; set; }

    public string? DefaultValue { get; set; }

    public string? CurrentValue { get; set; }

    public int ClientSettingTypeId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public int? ControlTypeId { get; set; }

    public int? MetaTypeId { get; set; }

    public bool? UserPreferenceOverridable { get; set; }

    public int? DisplayOrder { get; set; }

    public virtual ICollection<ClientSettingDefaultListValue> ClientSettingDefaultListValues { get; set; } = new List<ClientSettingDefaultListValue>();

    public virtual ClientSettingType ClientSettingType { get; set; } = null!;

    public virtual ControlType? ControlType { get; set; }

    public virtual MetaType? MetaType { get; set; }

    public virtual ICollection<UserPreference> UserPreferences { get; set; } = new List<UserPreference>();
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class LegacyAccountApplicationTracking
{
    public int LegacyAccountApplicationTrackingId { get; set; }

    public int LegacyAccountId { get; set; }

    public int ApplicationId { get; set; }

    public int ApplicationStateTypeId { get; set; }

    public int? JobPostingId { get; set; }

    public string JobTitle { get; set; } = null!;

    public int RequisitionId { get; set; }

    public string? RequisitionNumber { get; set; }

    public int BusinessEntityId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual LegacyAccount LegacyAccount { get; set; } = null!;
}

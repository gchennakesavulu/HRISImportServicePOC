﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ApplicationFormBinderMetaDatum
{
    public int ApplicationFormBinderMetaDataId { get; set; }

    public int ApplicationFormId { get; set; }

    public int SectionId { get; set; }

    public int SectionSequence { get; set; }

    public string? SectionName { get; set; }

    public int? ApplicationGroupId { get; set; }

    public int? ApplicationGroupSequence { get; set; }

    public int? FieldId { get; set; }

    public int? DataSourceFieldTypeId { get; set; }

    public string FieldLabel { get; set; } = null!;

    public bool IsUsingStandardDisplayName { get; set; }

    public int LabelOrientation { get; set; }

    public int ColumnSequence { get; set; }

    public int FieldSequence { get; set; }

    public bool Required { get; set; }

    public bool HasMultipleValues { get; set; }

    public int TmsdataTypeId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ApplicationForm ApplicationForm { get; set; } = null!;

    public virtual ApplicationGroup? ApplicationGroup { get; set; }

    public virtual DataSourceFieldType? DataSourceFieldType { get; set; }

    public virtual MetaType? Field { get; set; }

    public virtual TmsdataType TmsdataType { get; set; } = null!;
}

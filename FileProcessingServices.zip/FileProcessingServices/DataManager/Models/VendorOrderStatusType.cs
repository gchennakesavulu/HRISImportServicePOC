﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class VendorOrderStatusType
{
    public int VendorOrderStatusTypeId { get; set; }

    public string Name { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<ApplicationMostRecent> ApplicationMostRecentBackgroundCheckStatusTypes { get; set; } = new List<ApplicationMostRecent>();

    public virtual ICollection<ApplicationMostRecent> ApplicationMostRecentReferenceCheckStatusTypes { get; set; } = new List<ApplicationMostRecent>();

    public virtual ICollection<ApplicationMostRecent> ApplicationMostRecentTestAssessmentStatusTypes { get; set; } = new List<ApplicationMostRecent>();

    public virtual ICollection<RefactorAssessmentsVendorOrderTableMigration> RefactorAssessmentsVendorOrderTableMigrations { get; set; } = new List<RefactorAssessmentsVendorOrderTableMigration>();

    public virtual ICollection<SystemSearchVendorOrderType> SystemSearchVendorOrderTypes { get; set; } = new List<SystemSearchVendorOrderType>();

    public virtual ICollection<VendorOrderStatusTypeHistory> VendorOrderStatusTypeHistories { get; set; } = new List<VendorOrderStatusTypeHistory>();

    public virtual ICollection<VendorOrder> VendorOrders { get; set; } = new List<VendorOrder>();
}

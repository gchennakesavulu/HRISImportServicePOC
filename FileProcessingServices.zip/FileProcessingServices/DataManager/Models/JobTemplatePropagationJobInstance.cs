﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class JobTemplatePropagationJobInstance
{
    public int JobTemplatePropagationJobInstanceId { get; set; }

    public int JobTemplatePropagationJobId { get; set; }

    public DateTime StartDate { get; set; }

    public DateTime? EndDate { get; set; }

    public int Status { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual JobTemplatePropagationJob JobTemplatePropagationJob { get; set; } = null!;

    public virtual ICollection<JobTemplatePropagationJobSummary> JobTemplatePropagationJobSummaries { get; set; } = new List<JobTemplatePropagationJobSummary>();

    public virtual ICollection<JobTemplatePropagationRequisitionSyncErrorLog> JobTemplatePropagationRequisitionSyncErrorLogs { get; set; } = new List<JobTemplatePropagationRequisitionSyncErrorLog>();
}

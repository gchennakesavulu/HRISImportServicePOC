﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class HrXmlMap
{
    public int HrXmlMapId { get; set; }

    public int HrXmlTypeId { get; set; }

    public string SchemaVersion { get; set; } = null!;

    public string ElementName { get; set; } = null!;

    public string ElementPath { get; set; } = null!;

    public int? SectionId { get; set; }

    public string? AttributeName { get; set; }

    public string? AttributeValue { get; set; }

    public bool IsMultiElement { get; set; }

    public bool IsGroupMember { get; set; }

    public bool IsGroup { get; set; }

    public bool IsRepeatedElement { get; set; }

    public int? RepeatedElementSequence { get; set; }

    public bool IsLookupId { get; set; }

    public int? LookupDataSourceFieldTypeId { get; set; }

    public string? GroupNewParentPath { get; set; }

    public int? ApplicationGroupId { get; set; }

    public int? DataSourceFieldTypeId { get; set; }

    public int? MetaTypeId { get; set; }

    public int? MultiElementDataSourceFieldTypeId { get; set; }

    public string? MultiElementLookupValue { get; set; }

    public bool IsConditionalElement { get; set; }

    public int? ConditionalElementDataSourceFieldTypeId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ApplicationGroup? ApplicationGroup { get; set; }

    public virtual DataSourceFieldType? ConditionalElementDataSourceFieldType { get; set; }

    public virtual DataSourceFieldType? DataSourceFieldType { get; set; }

    public virtual HrXmlType HrXmlType { get; set; } = null!;

    public virtual DataSourceFieldType? LookupDataSourceFieldType { get; set; }

    public virtual MetaType? MetaType { get; set; }

    public virtual DataSourceFieldType? MultiElementDataSourceFieldType { get; set; }
}

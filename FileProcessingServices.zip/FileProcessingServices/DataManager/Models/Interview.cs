﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class Interview
{
    public int InterviewId { get; set; }

    public string MeetingId { get; set; } = null!;

    public int OrganizerId { get; set; }

    public int ApplicationId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public DateTime? ConfirmedDate { get; set; }

    public int? InterviewStatus { get; set; }

    public virtual Application Application { get; set; } = null!;

    public virtual ICollection<InterviewParticipant> InterviewParticipants { get; set; } = new List<InterviewParticipant>();

    public virtual Tmsuser Organizer { get; set; } = null!;
}

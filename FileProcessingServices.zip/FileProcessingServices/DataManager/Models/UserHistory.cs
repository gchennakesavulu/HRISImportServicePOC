﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class UserHistory
{
    public int UserHistoryId { get; set; }

    public string ContextIdentifier { get; set; } = null!;

    public int TmsuserId { get; set; }

    public string? ContextObjectId { get; set; }

    public string? AlternateIdentifier { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class SettingsClientJobTemplatePropagationField
{
    public int SettingsClientJobTemplatePropagationFieldId { get; set; }

    public int SettingsClientId { get; set; }

    public int JobTemplatePropagationFieldId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual JobTemplatePropagationField JobTemplatePropagationField { get; set; } = null!;

    public virtual SettingsClient SettingsClient { get; set; } = null!;
}

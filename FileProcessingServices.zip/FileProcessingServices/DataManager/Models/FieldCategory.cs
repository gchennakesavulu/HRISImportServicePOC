﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class FieldCategory
{
    public int FieldCategoryId { get; set; }

    public string Name { get; set; } = null!;

    public string ResourceLookupKey { get; set; } = null!;

    public int ResourceManagerKeyId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<FieldTag> FieldTags { get; set; } = new List<FieldTag>();

    public virtual ICollection<FormTypeFieldCategory> FormTypeFieldCategories { get; set; } = new List<FormTypeFieldCategory>();

    public virtual ICollection<FormType> FormTypes { get; set; } = new List<FormType>();

    public virtual ICollection<TemplateTypeFieldCategory> TemplateTypeFieldCategories { get; set; } = new List<TemplateTypeFieldCategory>();
}

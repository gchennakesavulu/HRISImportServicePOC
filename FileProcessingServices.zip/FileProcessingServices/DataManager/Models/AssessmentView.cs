﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class AssessmentView
{
    public string VendorName { get; set; } = null!;

    public string StatusName { get; set; } = null!;

    public string? Description { get; set; }

    public string? ResultLink { get; set; }

    public string? OrderIdentifier { get; set; }

    public int VendorOrderId { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? JobFamilyName { get; set; }

    public int VendorOrderStatusTypeId { get; set; }

    public int LocalApplicantId { get; set; }

    public int VendorTypeId { get; set; }

    public int? JobFamilyId { get; set; }

    public bool IsInternal { get; set; }

    public int VendorId { get; set; }

    public int AssessmentVendorOrderId { get; set; }

    public DateTime? CompletionDate { get; set; }

    public int AssessmentVendorOrderDetailId { get; set; }
}

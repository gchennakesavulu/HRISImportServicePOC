﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class Search
{
    public int SearchId { get; set; }

    public int DataSourceTypeId { get; set; }

    public int TmsuserId { get; set; }

    public string Name { get; set; } = null!;

    public string Criteria { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public bool IsDefault { get; set; }

    public virtual DataSourceType DataSourceType { get; set; } = null!;
}

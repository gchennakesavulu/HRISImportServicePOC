﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class JobTemplate
{
    public int JobTemplateId { get; set; }

    public string Name { get; set; } = null!;

    public string? JobPostingTitle { get; set; }

    public string? Code { get; set; }

    public string? JobDescription { get; set; }

    public string? JobSummary { get; set; }

    public int? FormId { get; set; }

    public string? KnowledgeSkillsAbilities { get; set; }

    public string? Hours { get; set; }

    /// <summary>
    /// Implied foreign key to TMSSecurity.dbo.NationalJobCategory.NationalJobCategoryID.
    /// 
    /// A populated value on a JobTemplate record indicates what Nation Job Category a given JobTemplate should appear under.
    /// </summary>
    public int? NationalJobCategoryId { get; set; }

    public int CategoryId { get; set; }

    public int? EducationId { get; set; }

    public int? EeojobGroupId { get; set; }

    public int? ScheduleId { get; set; }

    public int? ShiftId { get; set; }

    public int? SalaryRangeId { get; set; }

    public int? PayGradeId { get; set; }

    public int? JobStatusId { get; set; }

    public int? RankingQuestionnaireId { get; set; }

    public int? PreQualificationQuestionnaireId { get; set; }

    public int? PreQualMessageTemplateId { get; set; }

    public int? AssessmentPackageId { get; set; }

    public int? InternalEmailReplyTemplateId { get; set; }

    public int? ExternalEmailReplyTemplateId { get; set; }

    public bool UseDefaultInternalEmailReplyTemplate { get; set; }

    public bool UseDefaultExternalEmailReplyTemplate { get; set; }

    /// <summary>
    /// HRIS ID for data migration to tie back to source of datafeed
    /// </summary>
    public string? Hrisidentifier { get; set; }

    public bool Active { get; set; }

    public bool IsAvailableInJobAgent { get; set; }

    public int? BehavioralAssessmentVendorId { get; set; }

    public int? JobFamilyId { get; set; }

    public int? ReferenceBenchmarkTypeId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public int? AutoInviteBackTemplateId { get; set; }

    public bool UseDefaultShortApplyEmailReplyTemplate { get; set; }

    public int? LeanCapitalJobFamilyTypeId { get; set; }

    public int? BehavioralAssessmentVendorOfferingId { get; set; }

    public int PostingBrandingHierarchyLevelId { get; set; }

    public int? ReferenceAssessmentVendorOfferingId { get; set; }

    public int? ReferenceAssessmentDivisionId { get; set; }

    public int? ReferenceAssessmentWorkforceSegmentId { get; set; }

    public bool ShortFormAssessmentOnly { get; set; }

    public virtual AssessmentPackage? AssessmentPackage { get; set; }

    public virtual Template? AutoInviteBackTemplate { get; set; }

    public virtual Vendor? BehavioralAssessmentVendor { get; set; }

    public virtual MetaValue Category { get; set; } = null!;

    public virtual ICollection<DocumentGroupJobTemplate> DocumentGroupJobTemplates { get; set; } = new List<DocumentGroupJobTemplate>();

    public virtual MetaValue? Education { get; set; }

    public virtual MetaValue? EeojobGroup { get; set; }

    public virtual Template? ExternalEmailReplyTemplate { get; set; }

    public virtual Form? Form { get; set; }

    public virtual Template? InternalEmailReplyTemplate { get; set; }

    public virtual JobFamily? JobFamily { get; set; }

    public virtual MetaValue? JobStatus { get; set; }

    public virtual ICollection<JobTemplateBusinessEntity> JobTemplateBusinessEntities { get; set; } = new List<JobTemplateBusinessEntity>();

    public virtual ICollection<JobTemplateFieldValue> JobTemplateFieldValues { get; set; } = new List<JobTemplateFieldValue>();

    public virtual ICollection<JobTemplateInstance> JobTemplateInstances { get; set; } = new List<JobTemplateInstance>();

    public virtual ICollection<JobTemplateLeanCapitalJobFamilyType> JobTemplateLeanCapitalJobFamilyTypes { get; set; } = new List<JobTemplateLeanCapitalJobFamilyType>();

    public virtual ICollection<JobTemplateMetaValue> JobTemplateMetaValues { get; set; } = new List<JobTemplateMetaValue>();

    public virtual ICollection<JobTemplatePropagationHrisjobTemplate> JobTemplatePropagationHrisjobTemplates { get; set; } = new List<JobTemplatePropagationHrisjobTemplate>();

    public virtual ICollection<JobTemplatePropagationJob> JobTemplatePropagationJobs { get; set; } = new List<JobTemplatePropagationJob>();

    public virtual LeanCapitalJobFamilyType? LeanCapitalJobFamilyType { get; set; }

    public virtual MetaValue? PayGrade { get; set; }

    public virtual BusinessEntityType PostingBrandingHierarchyLevel { get; set; } = null!;

    public virtual Template? PreQualMessageTemplate { get; set; }

    public virtual Questionnaire? PreQualificationQuestionnaire { get; set; }

    public virtual Questionnaire? RankingQuestionnaire { get; set; }

    public virtual ReferenceBenchmarkType? ReferenceBenchmarkType { get; set; }

    public virtual MetaValue? SalaryRange { get; set; }

    public virtual MetaValue? Schedule { get; set; }

    public virtual MetaValue? Shift { get; set; }
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class SettingsTimeZone
{
    public int SettingsTimeZoneId { get; set; }

    public string TimeZoneId { get; set; } = null!;

    public string? TimeZoneDisplayName { get; set; }

    public string TimeZoneName { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }
}

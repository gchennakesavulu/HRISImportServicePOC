﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ControlType
{
    public int ControlTypeId { get; set; }

    public string Name { get; set; } = null!;

    public string? Description { get; set; }

    public int? TmsdataTypeId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<ClientSetting> ClientSettings { get; set; } = new List<ClientSetting>();

    public virtual ICollection<Format> Formats { get; set; } = new List<Format>();

    public virtual TmsdataType? TmsdataType { get; set; }

    public virtual ICollection<VendorAttribute> VendorAttributes { get; set; } = new List<VendorAttribute>();
}

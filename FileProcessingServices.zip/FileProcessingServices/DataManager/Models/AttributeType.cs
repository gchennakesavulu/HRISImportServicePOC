﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class AttributeType
{
    public int AttributeTypeId { get; set; }

    public string Name { get; set; } = null!;

    public string? Description { get; set; }

    public bool Active { get; set; }

    public bool IsSystem { get; set; }

    public int? TmsdataTypeId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public bool IsRequired { get; set; }

    public virtual ICollection<AttributeValue> AttributeValues { get; set; } = new List<AttributeValue>();

    public virtual ICollection<BusinessEntityTypeAttributeType> BusinessEntityTypeAttributeTypes { get; set; } = new List<BusinessEntityTypeAttributeType>();

    public virtual ICollection<TemplateTypeAttributeType> TemplateTypeAttributeTypes { get; set; } = new List<TemplateTypeAttributeType>();

    public virtual TmsdataType? TmsdataType { get; set; }
}

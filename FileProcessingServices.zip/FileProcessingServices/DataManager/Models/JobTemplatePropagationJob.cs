﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class JobTemplatePropagationJob
{
    public int JobTemplatePropagationJobId { get; set; }

    public int JobTemplateId { get; set; }

    public DateTime JobCreateDate { get; set; }

    public DateTime? JobEndDate { get; set; }

    public int Source { get; set; }

    public int Status { get; set; }

    public int? TmsuserId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual JobTemplate JobTemplate { get; set; } = null!;

    public virtual ICollection<JobTemplatePropagationFieldInstance> JobTemplatePropagationFieldInstances { get; set; } = new List<JobTemplatePropagationFieldInstance>();

    public virtual ICollection<JobTemplatePropagationJobInstance> JobTemplatePropagationJobInstances { get; set; } = new List<JobTemplatePropagationJobInstance>();

    public virtual ICollection<JobTemplatePropagationRequisitionStatusInstance> JobTemplatePropagationRequisitionStatusInstances { get; set; } = new List<JobTemplatePropagationRequisitionStatusInstance>();

    public virtual ICollection<JobTemplatePropagationRequisition> JobTemplatePropagationRequisitions { get; set; } = new List<JobTemplatePropagationRequisition>();

    public virtual Tmsuser? Tmsuser { get; set; }
}

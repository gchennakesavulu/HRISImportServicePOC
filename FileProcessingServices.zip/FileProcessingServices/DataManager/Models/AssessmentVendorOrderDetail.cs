﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class AssessmentVendorOrderDetail
{
    public int AssessmentVendorOrderDetailId { get; set; }

    public int AssessmentVendorOrderId { get; set; }

    public int? VendorOrderResultId { get; set; }

    public int? JobFamilyId { get; set; }

    public string? ResultLink { get; set; }

    public bool IsInternal { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public int? VendorOfferingId { get; set; }

    public virtual AssessmentVendorOrder AssessmentVendorOrder { get; set; } = null!;

    public virtual JobFamily? JobFamily { get; set; }

    public virtual VendorOrderDetail? VendorOrderResult { get; set; }
}

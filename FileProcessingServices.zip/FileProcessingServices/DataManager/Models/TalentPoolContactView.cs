﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class TalentPoolContactView
{
    public int TalentPoolContactId { get; set; }

    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string FullName { get; set; } = null!;

    public string? HomePhone { get; set; }

    public string? CellPhone { get; set; }

    public string? Email { get; set; }

    public string? Title { get; set; }

    public DateTime DateReceived { get; set; }

    public DateTime? ChangedDate { get; set; }

    public int? DateLastContacted { get; set; }

    public int TalentPoolContactStatusTypeId { get; set; }

    public string? Status { get; set; }

    public int? StatusId { get; set; }

    public string? Disposition { get; set; }

    public int? DispositionId { get; set; }

    public string? Address { get; set; }

    public string? Address2 { get; set; }

    public string? City { get; set; }

    public string? State { get; set; }

    public int? StateId { get; set; }

    public string? Zipcode { get; set; }

    public bool? AddressVerified { get; set; }

    public bool? EmailVerified { get; set; }
}

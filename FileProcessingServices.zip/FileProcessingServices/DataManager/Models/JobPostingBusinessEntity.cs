﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class JobPostingBusinessEntity
{
    public int JobPostingBusinessEntityId { get; set; }

    public int JobPostingId { get; set; }

    public int BusinessEntityId { get; set; }

    public int BusinessEntityTypeId { get; set; }

    public string? DisplayName { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual BusinessEntity BusinessEntity { get; set; } = null!;

    public virtual BusinessEntityType BusinessEntityType { get; set; } = null!;

    public virtual JobPosting JobPosting { get; set; } = null!;
}

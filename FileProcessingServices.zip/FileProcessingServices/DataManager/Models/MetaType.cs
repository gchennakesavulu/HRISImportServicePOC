﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class MetaType
{
    public int MetaTypeId { get; set; }

    public int ScopeLevelId { get; set; }

    public int SortOrderTypeId { get; set; }

    public int TmsdataTypeId { get; set; }

    public bool IsSecure { get; set; }

    public string DisplayName { get; set; } = null!;

    public string Name { get; set; } = null!;

    public string? Description { get; set; }

    public bool IsEeo { get; set; }

    public bool IsColorList { get; set; }

    public bool HasExtMessage { get; set; }

    public bool RequiresEncryption { get; set; }

    public bool Active { get; set; }

    /// <summary>
    /// This column, which will default to match the Name column, will be used to internally identify the field record.  this is being doine so that we can reliably correlate fileds across environments without having to rely on the tables int identity column being consistent.
    /// </summary>
    public string? InternalName { get; set; }

    /// <summary>
    /// This column will be used to uniquely identify a record in this table.  It is a calculated column that is calculated as the CHECKSUM of the InternalName column, given that it will uniquel identify the records in the table in the same manner as the InternalName column - it is being used so that we can work with unique records in this table in the most efficient manner (integer compares rather than string compares).
    /// </summary>
    public int? InternalNameId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public int? QuestionnaireId { get; set; }

    public bool? IsReportable { get; set; }

    public int? MetaTypeReportingTypeId { get; set; }

    public virtual ICollection<ApplicationFieldValue> ApplicationFieldValues { get; set; } = new List<ApplicationFieldValue>();

    public virtual ICollection<ApplicationFormBinderMetaDatum> ApplicationFormBinderMetaData { get; set; } = new List<ApplicationFormBinderMetaDatum>();

    public virtual ICollection<ApplicationGlobalCompare> ApplicationGlobalCompares { get; set; } = new List<ApplicationGlobalCompare>();

    public virtual ICollection<ClientSetting> ClientSettings { get; set; } = new List<ClientSetting>();

    public virtual ICollection<FieldTag> FieldTags { get; set; } = new List<FieldTag>();

    public virtual ICollection<FormMetaType> FormMetaTypes { get; set; } = new List<FormMetaType>();

    public virtual ICollection<FormTypeMetaTypeFieldTag> FormTypeMetaTypeFieldTags { get; set; } = new List<FormTypeMetaTypeFieldTag>();

    public virtual ICollection<HrXmlMap> HrXmlMaps { get; set; } = new List<HrXmlMap>();

    public virtual ICollection<JobPostingFieldValue> JobPostingFieldValues { get; set; } = new List<JobPostingFieldValue>();

    public virtual ICollection<JobTemplateFieldValue> JobTemplateFieldValues { get; set; } = new List<JobTemplateFieldValue>();

    public virtual ICollection<JobTemplateInstanceMetaValue> JobTemplateInstanceMetaValues { get; set; } = new List<JobTemplateInstanceMetaValue>();

    public virtual ICollection<JobTemplateMetaValue> JobTemplateMetaValues { get; set; } = new List<JobTemplateMetaValue>();

    public virtual ICollection<JobTemplatePropagationField> JobTemplatePropagationFields { get; set; } = new List<JobTemplatePropagationField>();

    public virtual MetaTypeReportingType? MetaTypeReportingType { get; set; }

    public virtual ICollection<MetaValue> MetaValues { get; set; } = new List<MetaValue>();

    public virtual ICollection<NewHireFieldValue> NewHireFieldValues { get; set; } = new List<NewHireFieldValue>();

    public virtual Questionnaire? Questionnaire { get; set; }

    public virtual ICollection<RequisitionFieldValue> RequisitionFieldValues { get; set; } = new List<RequisitionFieldValue>();

    public virtual SortOrderType SortOrderType { get; set; } = null!;

    public virtual TmsdataType TmsdataType { get; set; } = null!;
}

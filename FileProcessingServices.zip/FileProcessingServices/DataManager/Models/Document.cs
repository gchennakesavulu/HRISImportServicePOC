﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class Document
{
    public int DocumentId { get; set; }

    public int DocumentTypeId { get; set; }

    /// <summary>
    /// Provides information on how the Document source should be accessed for display based on the lookup of the DocumentSourceType.
    /// </summary>
    public int DocumentMediaTypeId { get; set; }

    /// <summary>
    /// For document of Questionnaire type this field points to the specific QuestionaireResponse (set of answers) for which the document is created.
    /// </summary>
    public int? QuestionnaireResponseId { get; set; }

    public string Name { get; set; } = null!;

    /// <summary>
    /// If the Document is not stored on a FileServer the complete content of the document is stored in this Column DocumentText.
    /// 
    /// </summary>
    public string? DocumentText { get; set; }

    /// <summary>
    /// FileLocation will be populated with the full path of the document which is stored on a file server. e.g.
    /// \\fileserver1\Dir\Year\Month\FileName.xyz
    /// 
    /// </summary>
    public string? FileLocation { get; set; }

    public bool IsVisible { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<ApplicationDocument> ApplicationDocuments { get; set; } = new List<ApplicationDocument>();

    public virtual ICollection<CommunicationDocument> CommunicationDocuments { get; set; } = new List<CommunicationDocument>();

    public virtual ICollection<Communication> Communications { get; set; } = new List<Communication>();

    public virtual DocumentMediaType DocumentMediaType { get; set; } = null!;

    public virtual DocumentType DocumentType { get; set; } = null!;

    public virtual ICollection<EsignatureDocument> EsignatureDocuments { get; set; } = new List<EsignatureDocument>();

    public virtual ICollection<NewHireDocument> NewHireDocuments { get; set; } = new List<NewHireDocument>();

    public virtual QuestionnaireResponse? QuestionnaireResponse { get; set; }

    public virtual ICollection<RequisitionDocument> RequisitionDocuments { get; set; } = new List<RequisitionDocument>();

    public virtual ICollection<TalentPoolContactDocument> TalentPoolContactDocuments { get; set; } = new List<TalentPoolContactDocument>();

    public virtual ICollection<TemplateDocument> TemplateDocuments { get; set; } = new List<TemplateDocument>();
}

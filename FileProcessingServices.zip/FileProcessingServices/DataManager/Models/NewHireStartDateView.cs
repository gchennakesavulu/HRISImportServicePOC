﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class NewHireStartDateView
{
    public int NewHireId { get; set; }

    public DateTime? StartDate { get; set; }
}

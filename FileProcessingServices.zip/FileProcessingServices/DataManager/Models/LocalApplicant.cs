﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class LocalApplicant
{
    public int LocalApplicantId { get; set; }

    /// <summary>
    /// Will hold the ID of the Legacy Account (PM10 Site Manager Account) the application is tied to.  Migration will be the only process that will populate this column.
    /// </summary>
    public int? LegacyAccountId { get; set; }

    public int? SourceNameMetaValueId { get; set; }

    public int? SourceCategoryMetaValueId { get; set; }

    public string ApplicantFirstName { get; set; } = null!;

    public string? ApplicantMiddleName { get; set; }

    public string ApplicantLastName { get; set; } = null!;

    public string? Email { get; set; }

    public string? Street1 { get; set; }

    public string? Street2 { get; set; }

    public string? City { get; set; }

    public int? StateMetaValueId { get; set; }

    public string? Zipcode { get; set; }

    public int? CountryMetaValueId { get; set; }

    public string? PhoneNumber { get; set; }

    public int? PhoneTypeMetaValueId { get; set; }

    public int? ContactMethodMetaValueId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    /// <summary>
    /// Added for PBI 28987,  Stores the Unencrypted value for the last four digits of the Applicant&apos;&apos;s Social Security Number.
    /// </summary>
    public string? LastFourSsn { get; set; }

    public virtual ICollection<ApplicantLocalApplicant> ApplicantLocalApplicants { get; set; } = new List<ApplicantLocalApplicant>();

    public virtual ICollection<Application> Applications { get; set; } = new List<Application>();

    public virtual ICollection<AssessmentVendorOrder> AssessmentVendorOrders { get; set; } = new List<AssessmentVendorOrder>();

    public virtual MetaValue? ContactMethodMetaValue { get; set; }

    public virtual MetaValue? CountryMetaValue { get; set; }

    public virtual ICollection<LocalApplicantVendorOrder> LocalApplicantVendorOrders { get; set; } = new List<LocalApplicantVendorOrder>();

    public virtual MetaValue? PhoneTypeMetaValue { get; set; }

    public virtual ICollection<Requisition> Requisitions { get; set; } = new List<Requisition>();

    public virtual MetaValue? SourceCategoryMetaValue { get; set; }

    public virtual MetaValue? SourceNameMetaValue { get; set; }

    public virtual MetaValue? StateMetaValue { get; set; }
}

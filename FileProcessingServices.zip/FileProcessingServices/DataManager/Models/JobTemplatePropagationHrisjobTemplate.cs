﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class JobTemplatePropagationHrisjobTemplate
{
    public int JobTemplatePropagationHrisjobTemplateId { get; set; }

    public int JobTemplatePropagationHrisid { get; set; }

    public int JobTemplateId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual JobTemplate JobTemplate { get; set; } = null!;

    public virtual JobTemplatePropagationHri JobTemplatePropagationHris { get; set; } = null!;
}

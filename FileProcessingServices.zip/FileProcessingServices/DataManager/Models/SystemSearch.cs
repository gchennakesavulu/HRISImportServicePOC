﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class SystemSearch
{
    public int SystemSearchId { get; set; }

    /// <summary>
    /// DataSourceTypeID refers to the type of the parent object for which the system search is defined.
    /// 
    /// E.g: Requisition or Application
    /// </summary>
    public int DataSourceTypeId { get; set; }

    public string Criteria { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual DataSourceType DataSourceType { get; set; } = null!;

    public virtual ICollection<SystemSearchOnboardingStatusType> SystemSearchOnboardingStatusTypes { get; set; } = new List<SystemSearchOnboardingStatusType>();

    public virtual ICollection<SystemSearchStatusType> SystemSearchStatusTypes { get; set; } = new List<SystemSearchStatusType>();

    public virtual ICollection<SystemSearchVendorOrderType> SystemSearchVendorOrderTypes { get; set; } = new List<SystemSearchVendorOrderType>();
}

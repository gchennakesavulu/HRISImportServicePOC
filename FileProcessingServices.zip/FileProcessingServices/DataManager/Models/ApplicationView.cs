﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ApplicationView
{
    public int ApplicationId { get; set; }

    public int RequisitionId { get; set; }

    public string ApplicantLastName { get; set; } = null!;

    public string ApplicantFirstName { get; set; } = null!;

    public string ApplicantName { get; set; } = null!;

    public bool IsInternal { get; set; }

    public DateTime ApplicationDate { get; set; }

    public string ApplicationType { get; set; } = null!;

    public string? CurrentStatus { get; set; }

    public string CurrentStatusFullName { get; set; } = null!;

    public DateTime? StatusDate { get; set; }

    public string RequisitionTitle { get; set; } = null!;

    public string? RequisitionNumber { get; set; }

    public int? ApplicantId { get; set; }

    public bool OriginatedInCareerSite { get; set; }

    public int? LocalApplicantId { get; set; }

    public string? Experience { get; set; }

    public string ExperienceFullName { get; set; } = null!;

    public string? Education { get; set; }

    public string EducationFullName { get; set; } = null!;

    public string? Shift { get; set; }

    public string ShiftFullName { get; set; } = null!;

    public string? Schedule { get; set; }

    public string ScheduleFullName { get; set; } = null!;

    public string? License { get; set; }

    public string LicenseFullName { get; set; } = null!;

    public string? HmsenderName { get; set; }

    public DateTime? HmcreateDate { get; set; }

    public string? Hmsubject { get; set; }

    public string? Hmbody { get; set; }

    public string? HmsubjectColor { get; set; }

    public int? HmresponseMetaValueId { get; set; }

    public long NoteCount { get; set; }

    public int NewActive { get; set; }

    public int NotHired { get; set; }

    public int Viable { get; set; }

    public int Hired { get; set; }

    public decimal? Score { get; set; }

    public decimal? Hrscore { get; set; }

    public decimal? Hmscore { get; set; }

    public int ScreeningAssessment { get; set; }

    public int ScreeningBackground { get; set; }

    public int ScreeningReference { get; set; }

    public int BusinessEntityId { get; set; }

    public int ApplicationStatusTypeId { get; set; }

    public int CategoryId { get; set; }

    public int? ShiftId { get; set; }

    public int? DispositionMetaValueId { get; set; }

    public string? DispositionText { get; set; }

    public int ApplicationTypeId { get; set; }

    public int JobTemplateId { get; set; }

    public int RecruiterId { get; set; }

    public int HiringManagerId { get; set; }

    public string? Email { get; set; }

    public string? ApplicantMiddleName { get; set; }

    public string? PhoneNumber { get; set; }

    public string? PhoneType { get; set; }

    public string? Street1 { get; set; }

    public string? Street2 { get; set; }

    public string? City { get; set; }

    public string? State { get; set; }

    public string? Country { get; set; }

    public string? Zipcode { get; set; }

    public string? JobCode { get; set; }

    public string? Hrisidentifier { get; set; }

    public bool ViewedByHiringManager { get; set; }

    public string? LocalApplicantLastName { get; set; }

    public string? LocalApplicantFirstName { get; set; }

    public string? LocalApplicantMiddleName { get; set; }

    public string? LocalApplicantName { get; set; }

    public string? LocalStreet1 { get; set; }

    public string? LocalStreet2 { get; set; }

    public string? LocalCity { get; set; }

    public string? LocalState { get; set; }

    public string? LcoalCountry { get; set; }

    public string? LocalZipcode { get; set; }

    public string? LocalPhoneNumber { get; set; }

    public string? LocalPhoneType { get; set; }

    public string? LocalEmail { get; set; }

    public int Deleted { get; set; }

    public int RequisitionStatusTypeId { get; set; }

    public string? RequisitionStatusTypeName { get; set; }

    public int? RankingQuestionnaireId { get; set; }

    public bool HasApplicationDocument { get; set; }

    public bool HasShortApplicationDocument { get; set; }

    public bool HasResumeDocument { get; set; }

    public string? ReceivedVia { get; set; }

    public int? BackgroundCheckStatusTypeId { get; set; }

    public int? TestAssessmentStatusTypeId { get; set; }

    public int? ReferenceCheckStatusTypeId { get; set; }

    public int CreatedBy { get; set; }

    public bool? RespondedToHmlatestCommunication { get; set; }

    public int? JobFamilyId { get; set; }

    public int ApplicantAnalyticsStatusTypeId { get; set; }

    public bool HasCoverLetter { get; set; }

    public bool IncludeHmcommunication { get; set; }

    public int? HmresponseLatestCommunicationId { get; set; }
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class JobTemplatePropagationRequisition
{
    public int JobTemplatePropagationRequisitionId { get; set; }

    public int JobTemplatePropagationJobId { get; set; }

    public int RequisitionId { get; set; }

    public bool? Dbenabled { get; set; }

    public bool? Esenabled { get; set; }

    public bool? Vipenabled { get; set; }

    public bool? Jtenabled { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual JobTemplatePropagationJob JobTemplatePropagationJob { get; set; } = null!;

    public virtual ICollection<JobTemplatePropagationRequisitionSyncErrorLog> JobTemplatePropagationRequisitionSyncErrorLogs { get; set; } = new List<JobTemplatePropagationRequisitionSyncErrorLog>();

    public virtual ICollection<JobTemplatePropagationRequisitionSyncStatus> JobTemplatePropagationRequisitionSyncStatuses { get; set; } = new List<JobTemplatePropagationRequisitionSyncStatus>();

    public virtual Requisition Requisition { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class JobTemplatePropagationRequisitionSyncStatus
{
    public int JobTemplatePropagationRequisitionSyncStatusId { get; set; }

    public int JobTemplatePropagationRequisitionId { get; set; }

    public int? Dbstatus { get; set; }

    public int? Esstatus { get; set; }

    public int? Vipstatus { get; set; }

    public int? Jtstatus { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual JobTemplatePropagationRequisition JobTemplatePropagationRequisition { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class DocumentType
{
    public int DocumentTypeId { get; set; }

    public string Name { get; set; } = null!;

    public bool IsOptionalManagerDocument { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<Document> Documents { get; set; } = new List<Document>();

    public virtual ICollection<SettingsClientDocumentType> SettingsClientDocumentTypes { get; set; } = new List<SettingsClientDocumentType>();

    public virtual ICollection<SettingsWorkflowDefaultSequentialStep> SettingsWorkflowDefaultSequentialSteps { get; set; } = new List<SettingsWorkflowDefaultSequentialStep>();

    public virtual ICollection<SettingsWorkflowSequentialStep> SettingsWorkflowSequentialSteps { get; set; } = new List<SettingsWorkflowSequentialStep>();
}

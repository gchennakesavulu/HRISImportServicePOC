﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class JobTemplatePropagationHri
{
    public int JobTemplatePropagationHrisid { get; set; }

    public DateTime JobCreateDate { get; set; }

    public int? TmsuserId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<JobTemplatePropagationHrisjobTemplate> JobTemplatePropagationHrisjobTemplates { get; set; } = new List<JobTemplatePropagationHrisjobTemplate>();

    public virtual Tmsuser? Tmsuser { get; set; }
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

/// <summary>
/// This table FormPublished is higly transacstional and
/// therefore it is denormalized from the Form table.
/// The Path and FileName fields exist in both this table and the Form table if the Form is published..
/// </summary>
public partial class FormPublished
{
    public int FormPublishedId { get; set; }

    public int FormId { get; set; }

    public int FormTypeId { get; set; }

    public int BusinessEntityId { get; set; }

    public string Path { get; set; } = null!;

    public string FileName { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual BusinessEntity BusinessEntity { get; set; } = null!;

    public virtual Form Form { get; set; } = null!;

    public virtual FormType FormType { get; set; } = null!;
}

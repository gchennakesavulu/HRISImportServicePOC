﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class FormTypeMetaTypeFieldTag
{
    public int FormTypeMetaTypeFieldTagId { get; set; }

    public int FormTypeId { get; set; }

    public int MetaTypeId { get; set; }

    public int FieldTagId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual FieldTag FieldTag { get; set; } = null!;

    public virtual FormType FormType { get; set; } = null!;

    public virtual MetaType MetaType { get; set; } = null!;
}

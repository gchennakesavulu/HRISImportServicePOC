﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ApplicationStatusFullMessage
{
    public int ApplicationStatusFullMessageId { get; set; }

    public int ApplicationStatusTypeId { get; set; }

    /// <summary>
    /// A column to store the full application status message from PM10.
    /// </summary>
    public string? Message { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ApplicationStatusType ApplicationStatusType { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ContactInformation
{
    public int ContactInformationId { get; set; }

    public string? Address { get; set; }

    public string? City { get; set; }

    public string? State { get; set; }

    public string? ZipCode { get; set; }

    public string? WorkPhone { get; set; }

    public string? FaxNumber { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<Tmsuser> Tmsusers { get; set; } = new List<Tmsuser>();
}

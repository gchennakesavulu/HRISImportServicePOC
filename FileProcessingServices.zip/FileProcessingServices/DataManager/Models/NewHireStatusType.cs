﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class NewHireStatusType
{
    public int NewHireStatusTypeId { get; set; }

    public string Name { get; set; } = null!;

    public string? ShortName { get; set; }

    public string? DefaultMessage { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<NewHire> NewHires { get; set; } = new List<NewHire>();

    public virtual ICollection<SettingsWorkflowStep> SettingsWorkflowSteps { get; set; } = new List<SettingsWorkflowStep>();

    public virtual ICollection<SystemSearchOnboardingStatusType> SystemSearchOnboardingStatusTypes { get; set; } = new List<SystemSearchOnboardingStatusType>();
}

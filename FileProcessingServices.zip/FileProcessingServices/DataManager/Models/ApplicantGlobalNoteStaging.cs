﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ApplicantGlobalNoteStaging
{
    public int ApplicantGlobalNoteStagingId { get; set; }

    public int ApplicantId { get; set; }

    public int GlobalNoteId { get; set; }

    public int GlobalNoteStagingId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual Note GlobalNote { get; set; } = null!;

    public virtual GlobalNoteStaging GlobalNoteStaging { get; set; } = null!;
}

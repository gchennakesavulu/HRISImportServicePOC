﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class SystemSearchOnboardingStatusType
{
    public int SystemSearchOnboardingStatusTypeId { get; set; }

    /// <summary>
    /// SystemSearch foreign key
    /// </summary>
    public int SystemSearchId { get; set; }

    /// <summary>
    /// NewHireStatusTypeId foreign key
    /// </summary>
    public int NewHireStatusTypeId { get; set; }

    /// <summary>
    /// Onboardingdocumentstatustypeid foreign key
    /// </summary>
    public int? OnBoardingDocumentStatusTypeId { get; set; }

    public int RoleTypeId { get; set; }

    public bool? Calculated { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual NewHireStatusType NewHireStatusType { get; set; } = null!;

    public virtual OnBoardingDocumentStatusType? OnBoardingDocumentStatusType { get; set; }

    public virtual SystemSearch SystemSearch { get; set; } = null!;
}

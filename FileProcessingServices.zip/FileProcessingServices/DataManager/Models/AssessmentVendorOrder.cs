﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class AssessmentVendorOrder
{
    public int AssessmentVendorOrderId { get; set; }

    public int VendorOrderId { get; set; }

    public int LocalApplicantId { get; set; }

    public int? ApplicationId { get; set; }

    public bool IsInternal { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual Application? Application { get; set; }

    public virtual ICollection<AssessmentVendorOrderDetail> AssessmentVendorOrderDetails { get; set; } = new List<AssessmentVendorOrderDetail>();

    public virtual LocalApplicant LocalApplicant { get; set; } = null!;

    public virtual VendorOrder VendorOrder { get; set; } = null!;
}

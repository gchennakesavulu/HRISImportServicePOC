﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class FailedProviderNewHireApplication
{
    public int FailedProviderNewHireApplicationId { get; set; }

    public int NewHireId { get; set; }

    public string RequestPayload { get; set; } = null!;

    public DateTime ScheduledDate { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public Guid? Suid { get; set; }

    public virtual NewHire NewHire { get; set; } = null!;
}

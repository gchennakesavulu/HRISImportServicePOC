﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class SettingsClient
{
    public int SettingsClientId { get; set; }

    public int SettingsInternalId { get; set; }

    public int DispositionReason { get; set; }

    public bool RequisitionNumberAutoGen { get; set; }

    public int? RequisitionNumberSequenceStart { get; set; }

    public bool RequisitionHiringManagerPrefillEnabled { get; set; }

    /// <summary>
    /// Client Setting for Enabling Approve Requisistion Without Logging in.
    /// </summary>
    public bool RequisitionApproveWithoutLoginEnabled { get; set; }

    public short PostJobsInternallyDefaultDays { get; set; }

    public bool PostJobsInternallyEnforceDefaultDays { get; set; }

    /// <summary>
    /// ApplicantCommentsEnabled. Column IncludeTextBoxWithComments A. If set to Yes, when sending or replying to comments, there will be a text box available for the User to enter in free text.
    ///             1. Default to Yes
    /// B. If set to No when sending or replying to comments, no text box is available.
    /// 
    /// </summary>
    public bool ApplicantCommentsEnabled { get; set; }

    /// <summary>
    /// Turn on and off task management. 
    /// For example, When turned on, the following should happen:
    ///  1. Task columns appear for both Recrutier and Hiring Enable TasksManager
    ///  2. &quot;Mark Tasks Complete&quot; action link appears for both Recruiters and Hiring managers on message rows that are associated with Tasks
    ///  3. Message reply dialogs contain the &quot;Create new task for recipient&quot; checkbox
    ///  4. Message reply dialogs contain a &quot;Mark task complete: &lt;taskname&gt; checkbox for messages associated with a specific task
    ///  5. &quot;Mark All Tasks Complete&quot; user role setting is enabled
    /// </summary>
    public bool ApplicantTasksEnabled { get; set; }

    public short NotifyManager { get; set; }

    public bool OauthLinkedInEnabled { get; set; }

    public bool DisplayReassignedApplications { get; set; }

    /// <summary>
    /// RecruiterAlertOnApplicationSubmission. Checkbox when turned on sends &apos;Send Applicant Apply Email Alert&apos;
    ///          Default -&gt; Off
    /// 
    /// 
    /// </summary>
    public bool RecruiterAlertOnApplicationSubmission { get; set; }

    public bool SendMessageReplyNotifications { get; set; }

    public bool SendInternalApplicationReply { get; set; }

    public bool SendExternalApplicationReply { get; set; }

    public bool ExternalCareerSiteShowExternalJobsOnly { get; set; }

    public bool InternalCareerSiteShowInternalJobsOnly { get; set; }

    public bool EmailApplicationToContactEnabled { get; set; }

    /// <summary>
    /// This column is used to select the option the client wants to use for displaying Social Securtiy #.  When set (1), the entire SSN # will be fully obscured, when off, the last four digits of the SSN # will be visible as follows:
    /// ***-***-####
    /// </summary>
    public bool MaskFullSsn { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public bool? EnforceDaylightSavings { get; set; }

    public int SettingsTimeZone { get; set; }

    public bool DisableSuccessAlerts { get; set; }

    public bool AdditionalHiringManagers { get; set; }

    public bool RequireApplicantSignatureDefault { get; set; }

    public bool EnableJobTemplatePropagation { get; set; }

    public virtual DispositionSettingsType DispositionReasonNavigation { get; set; } = null!;

    public virtual ICollection<SettingsClientDocumentType> SettingsClientDocumentTypes { get; set; } = new List<SettingsClientDocumentType>();

    public virtual ICollection<SettingsClientJobTemplatePropagationField> SettingsClientJobTemplatePropagationFields { get; set; } = new List<SettingsClientJobTemplatePropagationField>();

    public virtual ICollection<SettingsClientJobTemplatePropagationRequisitionStatusType> SettingsClientJobTemplatePropagationRequisitionStatusTypes { get; set; } = new List<SettingsClientJobTemplatePropagationRequisitionStatusType>();

    public virtual SettingsInternal SettingsInternal { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class DepartmentBusinessEntity
{
    public int DepartmentBusinessEntityId { get; set; }

    public int DepartmentId { get; set; }

    public int BusinessEntityId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual BusinessEntity BusinessEntity { get; set; } = null!;

    public virtual Department Department { get; set; } = null!;
}

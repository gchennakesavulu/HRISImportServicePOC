﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class GridType
{
    public int GridTypeId { get; set; }

    public string Name { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<GridColumnDefinition> GridColumnDefinitions { get; set; } = new List<GridColumnDefinition>();

    public virtual ICollection<UserGridColumnPreference> UserGridColumnPreferences { get; set; } = new List<UserGridColumnPreference>();
}

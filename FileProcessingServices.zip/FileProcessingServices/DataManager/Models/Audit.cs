﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class Audit
{
    public int AuditId { get; set; }

    public string? UserName { get; set; }

    public int? TmsuserId { get; set; }

    public DateTime OperationTime { get; set; }

    public string Result { get; set; } = null!;

    public string Ipaddress { get; set; } = null!;

    public int? ImpersonatingUserId { get; set; }

    public string? Reason { get; set; }

    public string Operation { get; set; } = null!;

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual Tmsuser? Tmsuser { get; set; }
}

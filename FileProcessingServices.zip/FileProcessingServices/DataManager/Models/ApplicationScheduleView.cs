﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ApplicationScheduleView
{
    public int ApplicationId { get; set; }

    public string? Schedule { get; set; }
}

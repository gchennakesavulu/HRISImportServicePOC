﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class Answer
{
    public int AnswerId { get; set; }

    public int QuestionId { get; set; }

    public string DisplayText { get; set; } = null!;

    public bool IsCorrect { get; set; }

    public int Sequence { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual Question Question { get; set; } = null!;

    public virtual ICollection<QuestionnaireResponseAnswer> QuestionnaireResponseAnswers { get; set; } = new List<QuestionnaireResponseAnswer>();
}

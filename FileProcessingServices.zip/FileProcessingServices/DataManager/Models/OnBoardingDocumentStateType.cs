﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class OnBoardingDocumentStateType
{
    public int OnBoardingDocumentStateTypeId { get; set; }

    public string Name { get; set; } = null!;

    public string? ShortName { get; set; }

    public string? DefaultMessage { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<OnBoardingDocument> OnBoardingDocuments { get; set; } = new List<OnBoardingDocument>();
}

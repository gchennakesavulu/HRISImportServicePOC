﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class TextMessage
{
    public int TextMessageId { get; set; }

    public int? ApplicationId { get; set; }

    public string Id { get; set; } = null!;

    public DateTime EventTime { get; set; }

    public int TextMessageEventTypeId { get; set; }

    public string Text { get; set; } = null!;

    public string ExternalNumber { get; set; } = null!;

    public int? SenderUserId { get; set; }

    public bool Viewed { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public int CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual Application? Application { get; set; }

    public virtual UserProfile? SenderUser { get; set; }

    public virtual TextMessageEventType TextMessageEventType { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class GridColumnDefinition
{
    public int GridColumnDefinitionId { get; set; }

    public int GridTypeId { get; set; }

    public string GridColumnDefinitionKey { get; set; } = null!;

    public string GridColumnDefinitionJson { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public int? ColumnOrder { get; set; }

    public virtual GridType GridType { get; set; } = null!;
}

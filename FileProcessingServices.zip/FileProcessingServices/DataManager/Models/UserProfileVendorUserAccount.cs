﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class UserProfileVendorUserAccount
{
    public int UserProfileVendorUserAccountId { get; set; }

    public int TmsuserId { get; set; }

    public int VendorUserAccountId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual UserProfile Tmsuser { get; set; } = null!;

    public virtual VendorUserAccount VendorUserAccount { get; set; } = null!;
}

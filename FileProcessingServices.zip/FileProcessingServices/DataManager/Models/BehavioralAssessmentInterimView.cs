﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class BehavioralAssessmentInterimView
{
    public int ApplicationId { get; set; }

    public int? VendorOfferingId { get; set; }

    public int VendorOrderStatusTypeId { get; set; }

    public int VendorOrderId { get; set; }

    public DateTime VendorOrderCreateDate { get; set; }

    public long? Countbig { get; set; }
}

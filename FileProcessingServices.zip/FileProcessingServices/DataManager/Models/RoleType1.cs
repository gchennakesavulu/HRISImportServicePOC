﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class RoleType1
{
    public int RoleTypeId { get; set; }

    public int ProductTypeId { get; set; }

    public string Name { get; set; } = null!;

    public bool? AccessAllCommunications { get; set; }

    public bool? AccessAllDocuments { get; set; }

    public int Rank { get; set; }

    public int? MyOwnAcldataSourceTypeDefaultId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<Role> Roles { get; set; } = new List<Role>();
}

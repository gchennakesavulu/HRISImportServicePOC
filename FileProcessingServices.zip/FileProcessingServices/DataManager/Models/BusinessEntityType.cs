﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class BusinessEntityType
{
    public int BusinessEntityTypeId { get; set; }

    public string Name { get; set; } = null!;

    public string? Description { get; set; }

    public bool Active { get; set; }

    public short HierarchyLevel { get; set; }

    public int? ParentId { get; set; }

    public string? Hrisidentifier { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<BusinessEntity> BusinessEntities { get; set; } = new List<BusinessEntity>();

    public virtual ICollection<BusinessEntityTypeAttributeType> BusinessEntityTypeAttributeTypes { get; set; } = new List<BusinessEntityTypeAttributeType>();

    public virtual ICollection<CareerSite> CareerSiteEndingBusinessEntityTypes { get; set; } = new List<CareerSite>();

    public virtual ICollection<CareerSite> CareerSiteStartingBusinessEntityTypes { get; set; } = new List<CareerSite>();

    public virtual ICollection<BusinessEntityType> InverseParent { get; set; } = new List<BusinessEntityType>();

    public virtual ICollection<JobPostingBusinessEntity> JobPostingBusinessEntities { get; set; } = new List<JobPostingBusinessEntity>();

    public virtual ICollection<JobTemplateInstance> JobTemplateInstances { get; set; } = new List<JobTemplateInstance>();

    public virtual ICollection<JobTemplate> JobTemplates { get; set; } = new List<JobTemplate>();

    public virtual BusinessEntityType? Parent { get; set; }
}

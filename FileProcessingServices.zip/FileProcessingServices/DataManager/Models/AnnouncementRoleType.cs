﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class AnnouncementRoleType
{
    public int AnnouncementRoleTypeId { get; set; }

    public int AnnouncementId { get; set; }

    public int RoleTypeId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual Announcement Announcement { get; set; } = null!;

    public virtual RoleType RoleType { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class SettingsApplyLimit
{
    public int SettingsApplyLimitId { get; set; }

    public string LimitType { get; set; } = null!;

    public int? DaysLimitedFor { get; set; }

    public int? Limit { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public string? Message { get; set; }

    public virtual ICollection<SettingsApplyLimitApplicationStatusType> SettingsApplyLimitApplicationStatusTypes { get; set; } = new List<SettingsApplyLimitApplicationStatusType>();
}

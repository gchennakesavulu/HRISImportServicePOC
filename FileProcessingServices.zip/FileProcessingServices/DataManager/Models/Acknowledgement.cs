﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class Acknowledgement
{
    public int AcknowledgementId { get; set; }

    public int AcknowledgementTypeId { get; set; }

    public string Name { get; set; } = null!;

    public string AcknowledgementText { get; set; } = null!;

    public bool IsPublished { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<AcknowledgementCareerSite> AcknowledgementCareerSites { get; set; } = new List<AcknowledgementCareerSite>();

    public virtual ICollection<AcknowledgementPublished> AcknowledgementPublisheds { get; set; } = new List<AcknowledgementPublished>();

    public virtual AcknowledgementType AcknowledgementType { get; set; } = null!;

    public virtual ICollection<ApplicationAcknowledgement> ApplicationAcknowledgements { get; set; } = new List<ApplicationAcknowledgement>();
}

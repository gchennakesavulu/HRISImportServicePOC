﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class FormMetaType
{
    public int FormMetaTypeId { get; set; }

    public int FormId { get; set; }

    public int MetaTypeId { get; set; }

    public int? FormatId { get; set; }

    public int? LinkFieldTagId { get; set; }

    public int? InternalNameId { get; set; }

    public int? GroupId { get; set; }

    public int? GroupSequenceId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual Form Form { get; set; } = null!;

    public virtual ICollection<FormMetaTypeAnnotation> FormMetaTypeAnnotations { get; set; } = new List<FormMetaTypeAnnotation>();

    public virtual Format? Format { get; set; }

    public virtual MetaType MetaType { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ApplicationAcknowledgement
{
    public int ApplicationAcknowledgementId { get; set; }

    public int AcknowledgementId { get; set; }

    public int AcknowledgementTypeId { get; set; }

    public int ApplicationId { get; set; }

    public string Signature { get; set; } = null!;

    public DateTime AcceptanceDate { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public string? IpAddress { get; set; }

    public virtual Acknowledgement Acknowledgement { get; set; } = null!;

    public virtual AcknowledgementType AcknowledgementType { get; set; } = null!;

    public virtual Application Application { get; set; } = null!;

    public virtual ICollection<ApplicationDocument> ApplicationDocuments { get; set; } = new List<ApplicationDocument>();
}

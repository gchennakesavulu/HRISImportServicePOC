﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class RefactorVendorOrderVendorOrderDetailMapping
{
    public int VendorOrderVendorOrderDetailMappingId { get; set; }

    public int VendorOrderId { get; set; }

    public int VendorOrderDetailId { get; set; }

    public int AssessmentVendorOrderDetailId { get; set; }

    public int Deleted { get; set; }

    public DateTime? CreateDate { get; set; }

    public DateTime ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual VendorOrder VendorOrder { get; set; } = null!;

    public virtual VendorOrderDetail VendorOrderDetail { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class AttributeValue
{
    public int AttributeValueId { get; set; }

    public int AttributeTypeId { get; set; }

    public string? Value { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual AttributeType AttributeType { get; set; } = null!;

    public virtual ICollection<BusinessEntityAttributeValue> BusinessEntityAttributeValues { get; set; } = new List<BusinessEntityAttributeValue>();

    public virtual ICollection<TemplateAttributeValue> TemplateAttributeValues { get; set; } = new List<TemplateAttributeValue>();
}

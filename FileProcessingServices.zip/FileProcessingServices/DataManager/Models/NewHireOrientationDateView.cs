﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class NewHireOrientationDateView
{
    public int NewHireId { get; set; }

    public DateTime? OrientationDate { get; set; }

    public DateTime? OrientationDate2 { get; set; }

    public DateTime? OrientationDate3 { get; set; }

    public DateTime? OrientationDate4 { get; set; }
}

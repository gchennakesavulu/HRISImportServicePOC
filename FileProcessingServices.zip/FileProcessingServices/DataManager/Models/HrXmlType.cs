﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

/// <summary>
/// The HR-XML schema supports many different schema types for Resume, Position, Background Check, Employee Data, etc.  Fields (MetaTypes) in the TMS system can be mapped to 1 or all of these types.
/// </summary>
public partial class HrXmlType
{
    public int HrXmlTypeId { get; set; }

    public string Name { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<HrXmlMap> HrXmlMaps { get; set; } = new List<HrXmlMap>();
}

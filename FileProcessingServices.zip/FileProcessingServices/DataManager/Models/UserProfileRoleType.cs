﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class UserProfileRoleType
{
    public int UserProfileRoleTypeId { get; set; }

    public int TmsuserId { get; set; }

    public int RoleTypeId { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public int Deleted { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual RoleType RoleType { get; set; } = null!;

    public virtual UserProfile Tmsuser { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class Template
{
    public int TemplateId { get; set; }

    public int TemplateTypeId { get; set; }

    public int TemplateSubtypeId { get; set; }

    /// <summary>
    /// IsDefault indicates the default internal and external application notification templates for Application Reply template type.
    /// </summary>
    public bool IsDefault { get; set; }

    public string Name { get; set; } = null!;

    public string? Description { get; set; }

    public bool Active { get; set; }

    public string? Body { get; set; }

    public bool IsAuto { get; set; }

    public bool IsAppliedToExternalApplicant { get; set; }

    public string? SubjectText { get; set; }

    public int? JobCategoryId { get; set; }

    public string? SenderEmailAddress { get; set; }

    public string? RecipientEmailAddress { get; set; }

    /// <summary>
    /// This column defines the Role to which a Template is available,
    /// 
    /// Some of the templates are only available to a specific Role.
    /// 
    /// E.g. hiring manager response to Recruiter should only be available to Hiring Managers, vs,
    /// Recruiter comments to Hiring Manager should only be available to Recruiter roles.
    /// </summary>
    public int? RoleTypeId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public bool ApplicantSignatureEnabled { get; set; }

    public virtual MetaValue? JobCategory { get; set; }

    public virtual ICollection<JobTemplate> JobTemplateAutoInviteBackTemplates { get; set; } = new List<JobTemplate>();

    public virtual ICollection<JobTemplate> JobTemplateExternalEmailReplyTemplates { get; set; } = new List<JobTemplate>();

    public virtual ICollection<JobTemplateInstance> JobTemplateInstances { get; set; } = new List<JobTemplateInstance>();

    public virtual ICollection<JobTemplate> JobTemplateInternalEmailReplyTemplates { get; set; } = new List<JobTemplate>();

    public virtual ICollection<JobTemplate> JobTemplatePreQualMessageTemplates { get; set; } = new List<JobTemplate>();

    public virtual RoleType? RoleType { get; set; }

    public virtual ICollection<SettingsWorkflowStep> SettingsWorkflowStepEscalationTemplates { get; set; } = new List<SettingsWorkflowStep>();

    public virtual ICollection<SettingsWorkflowStep> SettingsWorkflowStepNotificationTemplates { get; set; } = new List<SettingsWorkflowStep>();

    public virtual ICollection<SettingsWorkflow> SettingsWorkflows { get; set; } = new List<SettingsWorkflow>();

    public virtual ICollection<TemplateAttributeValue> TemplateAttributeValues { get; set; } = new List<TemplateAttributeValue>();

    public virtual ICollection<TemplateBusinessEntity> TemplateBusinessEntities { get; set; } = new List<TemplateBusinessEntity>();

    public virtual ICollection<TemplateDocument> TemplateDocuments { get; set; } = new List<TemplateDocument>();

    public virtual ICollection<TemplateRoleType> TemplateRoleTypes { get; set; } = new List<TemplateRoleType>();

    public virtual TemplateType TemplateType { get; set; } = null!;

    public virtual ICollection<TemplateUser> TemplateUsers { get; set; } = new List<TemplateUser>();
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ApplicationDocument
{
    public int ApplicationDocumentId { get; set; }

    public int DocumentId { get; set; }

    public int ApplicationId { get; set; }

    public int? ApplicationAcknowledgementId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual Application Application { get; set; } = null!;

    public virtual ApplicationAcknowledgement? ApplicationAcknowledgement { get; set; }

    public virtual ICollection<ApplicationDocumentAcl> ApplicationDocumentAcls { get; set; } = new List<ApplicationDocumentAcl>();

    public virtual Document Document { get; set; } = null!;
}

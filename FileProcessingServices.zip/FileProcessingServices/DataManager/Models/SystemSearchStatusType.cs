﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class SystemSearchStatusType
{
    public int SystemSearchStatusTypeId { get; set; }

    public int SystemSearchId { get; set; }

    public int RoleTypeId { get; set; }

    /// <summary>
    /// Requisition status type
    /// </summary>
    public int? RequisitionStatusTypeId { get; set; }

    /// <summary>
    /// Application status type
    /// </summary>
    public int? ApplicationStatusTypeId { get; set; }

    /// <summary>
    /// If systemsearch has calculated count. We are handling these records differently in stored procedure.Viewed, Not Viewed, Internal, External are calculated fields.
    /// </summary>
    public bool? Calculated { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ApplicationStatusType? ApplicationStatusType { get; set; }

    public virtual RequisitionStatusType? RequisitionStatusType { get; set; }

    public virtual RoleType RoleType { get; set; } = null!;

    public virtual SystemSearch SystemSearch { get; set; } = null!;
}

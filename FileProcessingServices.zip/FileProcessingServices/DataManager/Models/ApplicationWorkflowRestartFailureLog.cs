﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ApplicationWorkflowRestartFailureLog
{
    public int ApplicationWorkflowRestartFailureLogId { get; set; }

    public int ApplicationId { get; set; }

    public int WorkflowProcessId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }
}

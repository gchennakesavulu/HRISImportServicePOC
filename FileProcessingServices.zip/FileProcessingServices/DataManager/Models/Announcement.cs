﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class Announcement
{
    public int AnnouncementId { get; set; }

    public string Name { get; set; } = null!;

    /// <summary>
    /// The date when an Announcement becomes visible to a PositionManager user.
    /// </summary>
    public DateTime StartDate { get; set; }

    /// <summary>
    /// Determines the last date at which an Announcement is visible to a PostitionManager user.
    /// </summary>
    public DateTime EndDate { get; set; }

    /// <summary>
    /// The subject text that is displayed when a PostionManager user is presented with a list of Announcements.
    /// </summary>
    public string Subject { get; set; } = null!;

    /// <summary>
    /// The html text that is displayed when a PostitionManager user views an Announcement.
    /// </summary>
    public string AnnouncementText { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<AnnouncementRoleType> AnnouncementRoleTypes { get; set; } = new List<AnnouncementRoleType>();
}

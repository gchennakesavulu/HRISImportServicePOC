﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class PasswordHistory
{
    public int PasswordHistoryId { get; set; }

    public int TmsuserId { get; set; }

    public string Password { get; set; } = null!;

    public string Salt { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual Tmsuser Tmsuser { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class JobTemplatePropagationRequisitionStatusInstance
{
    public int JobTemplatePropagationRequisitionStatusInstanceId { get; set; }

    public int JobTemplatePropagationJobId { get; set; }

    public int RequisitionStatusTypeId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual JobTemplatePropagationJob JobTemplatePropagationJob { get; set; } = null!;

    public virtual RequisitionStatusType RequisitionStatusType { get; set; } = null!;
}

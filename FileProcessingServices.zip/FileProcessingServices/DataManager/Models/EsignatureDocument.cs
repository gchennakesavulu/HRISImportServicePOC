﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class EsignatureDocument
{
    public int EsignatureDocumentId { get; set; }

    public int? CommunicationId { get; set; }

    public int ApplicationId { get; set; }

    public int DocumentId { get; set; }

    public int? DocumentStatus { get; set; }

    public DateTime? DateSigned { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public string? Ipaddress { get; set; }

    public bool Acknowledged { get; set; }

    public int? EmailNotificationTemplateId { get; set; }

    public int? ApplicantSignatureTemplateId { get; set; }

    public DateTime? StatusDate { get; set; }

    public DateTime? DateSent { get; set; }

    public string? SubjectText { get; set; }

    public bool SendForHm { get; set; }

    public bool SendForAdditionalHm { get; set; }

    public bool SendForCustomEmailAddress { get; set; }

    public virtual Application Application { get; set; } = null!;

    public virtual Document Document { get; set; } = null!;

    public virtual ICollection<EsignatureDocumentCustomEmailAddress> EsignatureDocumentCustomEmailAddresses { get; set; } = new List<EsignatureDocumentCustomEmailAddress>();
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class JobPosting
{
    public int JobPostingId { get; set; }

    public int RequisitionId { get; set; }

    public string Title { get; set; } = null!;

    /// <summary>
    /// JobSummary stores the summary of the job description to be displayed on a job board (CareerSite). This field is initialized from the JobSummary field of the JobTemplateInstance of the Requisition and allows customizing the summary for this posting without affecting the Requisition or other JobPosting records.
    /// </summary>
    public string? JobSummary { get; set; }

    public int? FormId { get; set; }

    public int? ContactUserId { get; set; }

    public bool DisplayContactName { get; set; }

    public bool DisplayContactAddress { get; set; }

    public bool DisplayEmailAddress { get; set; }

    public bool DisplayPhoneNumber { get; set; }

    public bool DisplayFaxNumber { get; set; }

    public string? FacilityDescription { get; set; }

    public bool DisplayFacilityDescription { get; set; }

    public bool IsDraft { get; set; }

    public int BusinessEntityId { get; set; }

    /// <summary>
    /// Implied foreign key to TMSSecurity.dbo.NationalJobCategory.NationalJobCategoryID.
    /// 
    /// A populated value on a JobPosting record indicates what Nation Job Category a given JobPosting should appear under.
    /// </summary>
    public int? NationalJobCategoryId { get; set; }

    /// <summary>
    /// Maps to MetaValue.MetaValueID
    /// </summary>
    public int JobCategoryId { get; set; }

    public DateTime StartDate { get; set; }

    public DateTime? EndInternalOnlyDate { get; set; }

    public DateTime? EndDate { get; set; }

    public bool StartAsInternalOnly { get; set; }

    public bool Active { get; set; }

    public bool IsFeaturedJob { get; set; }

    public bool PostToHcsjobBoard { get; set; }

    /// <summary>
    /// RecruiterAlertOnApplicationSubmission. Checkbox when turned on sends &apos;Send Applicant Apply Email Alert&apos;
    /// 
    /// 
    /// </summary>
    public bool RecruiterAlertOnApplicationSubmission { get; set; }

    public bool EmailApplicationToContact { get; set; }

    public int? JobPostingLocationId { get; set; }

    public int? JobTargetJobId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public bool IsHiddenOnCareerSite { get; set; }

    public virtual ICollection<Application> Applications { get; set; } = new List<Application>();

    public virtual BusinessEntity BusinessEntity { get; set; } = null!;

    public virtual UserProfile? ContactUser { get; set; }

    public virtual UserProfile CreatedByNavigation { get; set; } = null!;

    public virtual Form? Form { get; set; }

    public virtual MetaValue JobCategory { get; set; } = null!;

    public virtual ICollection<JobDistributionJobInfo> JobDistributionJobInfos { get; set; } = new List<JobDistributionJobInfo>();

    public virtual ICollection<JobPostingBusinessEntity> JobPostingBusinessEntities { get; set; } = new List<JobPostingBusinessEntity>();

    public virtual ICollection<JobPostingFieldValue> JobPostingFieldValues { get; set; } = new List<JobPostingFieldValue>();

    public virtual JobPostingLocation? JobPostingLocation { get; set; }

    public virtual ICollection<JobPostingVendor> JobPostingVendors { get; set; } = new List<JobPostingVendor>();

    public virtual Requisition Requisition { get; set; } = null!;
}

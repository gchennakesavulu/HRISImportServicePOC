﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class OnBoardingDocumentInstance
{
    public int OnboardingDocumentInstanceId { get; set; }

    public int OnBoardingDocumentId { get; set; }

    public int NewHireId { get; set; }

    public int OnBoardingDocumentStatusTypeId { get; set; }

    public int? Sequence { get; set; }

    /// <summary>
    /// This column stores the last date the document status changed
    /// </summary>
    public DateTime StatusDate { get; set; }

    /// <summary>
    /// This is the file location (minus filename) for the prefilled or filled out Document Instance form.
    /// </summary>
    public string? FileLocation { get; set; }

    /// <summary>
    /// This is the file name (minus path) for the prefilled or filled out Document Instance form.
    /// </summary>
    public string? FileName { get; set; }

    /// <summary>
    /// This contains the data of the pre-filled or posted Document Instance.  With this data and an Onboarding Document we can generate a new PDF that has the NewHires populated information.
    /// </summary>
    public string? DocumentData { get; set; }

    /// <summary>
    /// This column contains the cryptography &quot;Salt&quot; that is used to symetrically encrypt/decrypt the system data embedded into the Document Instance.  
    /// </summary>
    public string? DocumentInstanceSalt { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual NewHire NewHire { get; set; } = null!;

    public virtual OnBoardingDocument OnBoardingDocument { get; set; } = null!;

    public virtual OnBoardingDocumentStatusType OnBoardingDocumentStatusType { get; set; } = null!;
}

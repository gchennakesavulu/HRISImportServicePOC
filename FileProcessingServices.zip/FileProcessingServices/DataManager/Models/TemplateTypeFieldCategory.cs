﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class TemplateTypeFieldCategory
{
    public int TemplateTypeFieldCategoryId { get; set; }

    public int FieldCategoryId { get; set; }

    public int TemplateTypeId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual FieldCategory FieldCategory { get; set; } = null!;

    public virtual TemplateType TemplateType { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class OnboardingEmailSettingsType
{
    public int OnboardingEmailSettingsTypeId { get; set; }

    public string Name { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<SettingsOnboarding> SettingsOnboardings { get; set; } = new List<SettingsOnboarding>();
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class LegacyAccount
{
    public int LegacyAccountId { get; set; }

    public string? Email { get; set; }

    public string Username { get; set; } = null!;

    public string Password { get; set; } = null!;

    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string? MiddleName { get; set; }

    public string? SecurityQuestion { get; set; }

    public string? SecurityAnswer { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public string? Salt { get; set; }

    public virtual ICollection<LegacyAccountApplicationTracking> LegacyAccountApplicationTrackings { get; set; } = new List<LegacyAccountApplicationTracking>();
}

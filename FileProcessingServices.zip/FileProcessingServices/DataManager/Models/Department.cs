﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class Department
{
    public int DepartmentId { get; set; }

    public int? FacilityId { get; set; }

    public string Name { get; set; } = null!;

    public string? Code { get; set; }

    public string? BudgetedFtes { get; set; }

    public string? NumberPositions { get; set; }

    public Guid? DepartmentGuid { get; set; }

    public string? Hrisidentifier { get; set; }

    public bool Active { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<DepartmentBusinessEntity> DepartmentBusinessEntities { get; set; } = new List<DepartmentBusinessEntity>();

    public virtual Facility? Facility { get; set; }
}

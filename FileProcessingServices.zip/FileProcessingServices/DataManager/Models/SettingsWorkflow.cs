﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class SettingsWorkflow
{
    public int SettingsWorkflowId { get; set; }

    public int SettingsWorkflowDefinitionId { get; set; }

    public int WorkflowTypeId { get; set; }

    public int? WorkflowSubTypeId { get; set; }

    public int? EscalationTemplateId { get; set; }

    public string Name { get; set; } = null!;

    public bool DoEscalation { get; set; }

    public long? EscalationTimeout { get; set; }

    public string? Description { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual Template? EscalationTemplate { get; set; }

    public virtual ICollection<SettingsWorkflowDefaultSequentialStep> SettingsWorkflowDefaultSequentialSteps { get; set; } = new List<SettingsWorkflowDefaultSequentialStep>();

    public virtual SettingsWorkflowDefinition SettingsWorkflowDefinition { get; set; } = null!;

    public virtual ICollection<SettingsWorkflowSequentialStep> SettingsWorkflowSequentialSteps { get; set; } = new List<SettingsWorkflowSequentialStep>();

    public virtual ICollection<SettingsWorkflowStep> SettingsWorkflowSteps { get; set; } = new List<SettingsWorkflowStep>();

    public virtual ICollection<WorkflowAssociation> WorkflowAssociationParentSettingsWorkflows { get; set; } = new List<WorkflowAssociation>();

    public virtual ICollection<WorkflowAssociation> WorkflowAssociationSettingsWorkflows { get; set; } = new List<WorkflowAssociation>();

    public virtual WorkflowSubType? WorkflowSubType { get; set; }
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class SettingsApplyLimitApplicationStatusType
{
    public int SettingsApplyLimitApplicationStatusTypeId { get; set; }

    public int SettingsApplyLimitId { get; set; }

    public int ApplicationStatusTypeId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ApplicationStatusType ApplicationStatusType { get; set; } = null!;

    public virtual SettingsApplyLimit SettingsApplyLimit { get; set; } = null!;
}

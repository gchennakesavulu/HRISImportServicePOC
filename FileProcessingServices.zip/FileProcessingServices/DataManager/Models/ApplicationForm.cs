﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ApplicationForm
{
    public int ApplicationFormId { get; set; }

    public int ApplicationFormTypeId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<ApplicationApplicationForm> ApplicationApplicationForms { get; set; } = new List<ApplicationApplicationForm>();

    public virtual ICollection<ApplicationFieldValue> ApplicationFieldValues { get; set; } = new List<ApplicationFieldValue>();

    public virtual ICollection<ApplicationFormBinderMetaDatum> ApplicationFormBinderMetaData { get; set; } = new List<ApplicationFormBinderMetaDatum>();

    public virtual ApplicationFormType ApplicationFormType { get; set; } = null!;

    public virtual ICollection<SettingsWorkflowDefaultSequentialStep> SettingsWorkflowDefaultSequentialSteps { get; set; } = new List<SettingsWorkflowDefaultSequentialStep>();

    public virtual ICollection<SettingsWorkflowSequentialStep> SettingsWorkflowSequentialSteps { get; set; } = new List<SettingsWorkflowSequentialStep>();
}

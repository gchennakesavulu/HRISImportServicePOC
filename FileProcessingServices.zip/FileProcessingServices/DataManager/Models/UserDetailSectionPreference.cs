﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class UserDetailSectionPreference
{
    public int UserDetailSectionPreferencesId { get; set; }

    public int TmsuserId { get; set; }

    public int DetailSectionTypeId { get; set; }

    public string SelectedFields { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual DetailSectionType DetailSectionType { get; set; } = null!;
}

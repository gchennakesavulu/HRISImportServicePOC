﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class SettingsClientDocumentType
{
    public int SettingsClientDocumentTypeId { get; set; }

    public int SettingsClientId { get; set; }

    public int DocumentTypeId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual DocumentType DocumentType { get; set; } = null!;

    public virtual SettingsClient SettingsClient { get; set; } = null!;
}

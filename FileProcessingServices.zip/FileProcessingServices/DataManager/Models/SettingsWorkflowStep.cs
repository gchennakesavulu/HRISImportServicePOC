﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class SettingsWorkflowStep
{
    public int SettingsWorkflowStepId { get; set; }

    public int SettingsWorkflowId { get; set; }

    public int? NotificationTemplateId { get; set; }

    public int? EscalationTemplateId { get; set; }

    /// <summary>
    /// NewHireStatusTypeID that maps to this workflow step. NULL for non NewHire workflows.
    /// </summary>
    public int? NewHireStatusTypeId { get; set; }

    /// <summary>
    /// RequisitionStatusTypeID that maps to this workflow step. NULL for non Requisition workflows.
    /// </summary>
    public int? RequisitionStatusTypeId { get; set; }

    /// <summary>
    /// ApplicationStatusTypeID that maps to this workflow step. NULL for non application workflows.
    /// </summary>
    public int? ApplicationStatusTypeId { get; set; }

    /// <summary>
    /// OnboardingDocumentStatusTypeID that maps to this workflow step. NULL for non Onboarding Document workflows.
    /// </summary>
    public int? OnBoardingDocumentStatusTypeId { get; set; }

    /// <summary>
    /// Indicates that this step is a system step expected by the system and that means that it is both require and immutable. 
    /// </summary>
    public bool? IsSystem { get; set; }

    /// <summary>
    /// The name of the corresponding workflow step. ActivityName in K2 Workflow.
    /// </summary>
    public string? StepName { get; set; }

    public int WorkflowStepIdentifier { get; set; }

    public bool DoEscalation { get; set; }

    public long? EscalationTimeout { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ApplicationStatusType? ApplicationStatusType { get; set; }

    public virtual Template? EscalationTemplate { get; set; }

    public virtual NewHireStatusType? NewHireStatusType { get; set; }

    public virtual Template? NotificationTemplate { get; set; }

    public virtual OnBoardingDocumentStatusType? OnBoardingDocumentStatusType { get; set; }

    public virtual RequisitionStatusType? RequisitionStatusType { get; set; }

    public virtual SettingsWorkflow SettingsWorkflow { get; set; } = null!;

    public virtual ICollection<SettingsWorkflowStepAction> SettingsWorkflowStepActions { get; set; } = new List<SettingsWorkflowStepAction>();

    public virtual ICollection<WorkflowStepUser> WorkflowStepUsers { get; set; } = new List<WorkflowStepUser>();
}

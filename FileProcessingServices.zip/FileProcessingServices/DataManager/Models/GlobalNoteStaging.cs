﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class GlobalNoteStaging
{
    public int GlobalNoteStagingId { get; set; }

    public string EncryptedSsn { get; set; } = null!;

    public byte[] TextHashBytes { get; set; } = null!;

    public string Text { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<ApplicantGlobalNoteStaging> ApplicantGlobalNoteStagings { get; set; } = new List<ApplicantGlobalNoteStaging>();
}

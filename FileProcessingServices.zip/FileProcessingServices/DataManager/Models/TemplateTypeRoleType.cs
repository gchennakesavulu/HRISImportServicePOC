﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class TemplateTypeRoleType
{
    public int TemplateTypeRoleTypeId { get; set; }

    public int RoleTypeId { get; set; }

    public int TemplateTypeId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual RoleType RoleType { get; set; } = null!;

    public virtual TemplateType TemplateType { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class RoleType
{
    public string Name { get; set; } = null!;

    public int RoleTypeId { get; set; }

    public string? Description { get; set; }

    public bool AccessAllDocuments { get; set; }

    public int Deleted { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    /// <summary>
    /// This bit, if set, indicates that the user role has access to view all communications and not just role specific communications.
    /// 
    /// E.g: Recuiters can see All communications, hiring managers can only see communications that they have started or need to respond to.
    /// </summary>
    public bool AccessAllCommunications { get; set; }

    /// <summary>
    /// If user has multiple position Types(Roles), the rank is a integer number given to the Role.If a user has multiple roles, the role with the higher rank is considered as default role.
    /// </summary>
    public int Rank { get; set; }

    public DateTime CreateDate { get; set; }

    public virtual ICollection<AnnouncementRoleType> AnnouncementRoleTypes { get; set; } = new List<AnnouncementRoleType>();

    public virtual ICollection<ApplicationAcl> ApplicationAcls { get; set; } = new List<ApplicationAcl>();

    public virtual ICollection<ApplicationDocumentAcl> ApplicationDocumentAcls { get; set; } = new List<ApplicationDocumentAcl>();

    public virtual ICollection<Communication> CommunicationRecipientUserRoleTypes { get; set; } = new List<Communication>();

    public virtual ICollection<Communication> CommunicationSenderUserRoleTypes { get; set; } = new List<Communication>();

    public virtual ICollection<QuestionnaireResponse> QuestionnaireResponses { get; set; } = new List<QuestionnaireResponse>();

    public virtual ICollection<SystemSearchStatusType> SystemSearchStatusTypes { get; set; } = new List<SystemSearchStatusType>();

    public virtual ICollection<Task> Tasks { get; set; } = new List<Task>();

    public virtual ICollection<TemplateRoleType> TemplateRoleTypes { get; set; } = new List<TemplateRoleType>();

    public virtual ICollection<TemplateTypeRoleType> TemplateTypeRoleTypes { get; set; } = new List<TemplateTypeRoleType>();

    public virtual ICollection<Template> Templates { get; set; } = new List<Template>();

    public virtual ICollection<UserProfileRoleType> UserProfileRoleTypes { get; set; } = new List<UserProfileRoleType>();
}

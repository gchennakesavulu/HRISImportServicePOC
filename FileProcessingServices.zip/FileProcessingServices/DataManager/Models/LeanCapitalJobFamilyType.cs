﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class LeanCapitalJobFamilyType
{
    public int LeanCapitalJobFamilyTypeId { get; set; }

    public string Name { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<JobTemplateInstanceLeanCapitalJobFamilyType> JobTemplateInstanceLeanCapitalJobFamilyTypes { get; set; } = new List<JobTemplateInstanceLeanCapitalJobFamilyType>();

    public virtual ICollection<JobTemplateInstance> JobTemplateInstances { get; set; } = new List<JobTemplateInstance>();

    public virtual ICollection<JobTemplateLeanCapitalJobFamilyType> JobTemplateLeanCapitalJobFamilyTypes { get; set; } = new List<JobTemplateLeanCapitalJobFamilyType>();

    public virtual ICollection<JobTemplate> JobTemplates { get; set; } = new List<JobTemplate>();
}

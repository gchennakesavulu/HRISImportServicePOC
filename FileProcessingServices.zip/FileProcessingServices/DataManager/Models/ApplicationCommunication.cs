﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ApplicationCommunication
{
    public int ApplicationCommunicationId { get; set; }

    public int ApplicationId { get; set; }

    public int CommunicationId { get; set; }

    public int? VendorOrderId { get; set; }

    public int Deleted { get; set; }

    public bool? IsAccessRemoved { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual Application Application { get; set; } = null!;

    public virtual Communication Communication { get; set; } = null!;

    public virtual VendorOrder? VendorOrder { get; set; }
}

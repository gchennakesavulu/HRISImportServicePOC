﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class UserWizardDatum
{
    public int UserWizardDataId { get; set; }

    public int TmsuserId { get; set; }

    public byte[] WizardData { get; set; } = null!;

    public int WizardTypeId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }
}

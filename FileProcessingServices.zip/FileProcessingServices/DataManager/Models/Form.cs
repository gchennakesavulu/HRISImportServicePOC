﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class Form
{
    public int FormId { get; set; }

    public int FormTypeId { get; set; }

    public string Name { get; set; } = null!;

    public string? FormLayoutXml { get; set; }

    public bool IsPublished { get; set; }

    public string? Path { get; set; }

    public string? FileName { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<FormBusinessEntity> FormBusinessEntities { get; set; } = new List<FormBusinessEntity>();

    public virtual ICollection<FormMetaType> FormMetaTypes { get; set; } = new List<FormMetaType>();

    public virtual ICollection<FormPublished> FormPublisheds { get; set; } = new List<FormPublished>();

    public virtual FormType FormType { get; set; } = null!;

    public virtual ICollection<JobPosting> JobPostings { get; set; } = new List<JobPosting>();

    public virtual ICollection<JobTemplate> JobTemplates { get; set; } = new List<JobTemplate>();

    public virtual ICollection<NewHire> NewHires { get; set; } = new List<NewHire>();

    public virtual ICollection<Requisition> Requisitions { get; set; } = new List<Requisition>();
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class SettingsOnboarding
{
    public int SettingsOnboardingId { get; set; }

    public bool PreSelectOnboardingDocumentsEnabled { get; set; }

    public int? SendOnboardingEmailSettingsTypeId { get; set; }

    /// <summary>
    /// Flag to indicate whether the client XML field file is used or not.  If this bit is set there there is a FieldMapping file uploaded for this client.  Defaults to not set.
    /// </summary>
    public bool UseFieldMappingFile { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public bool ReOpenClosedDocuments { get; set; }

    public virtual OnboardingEmailSettingsType? SendOnboardingEmailSettingsType { get; set; }
}

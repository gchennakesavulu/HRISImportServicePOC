﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class VendorAttribute
{
    /// <summary>
    /// VendorAttributeID is not an Identity primary key as it will be brought over from the global VendorAttribute table.
    /// </summary>
    public int VendorAttributeId { get; set; }

    public string Name { get; set; } = null!;

    public string Value { get; set; } = null!;

    public string? Description { get; set; }

    public int VendorId { get; set; }

    public int VendorAttributeTypeId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public int ControlTypeId { get; set; }

    public virtual ControlType ControlType { get; set; } = null!;

    public virtual Vendor Vendor { get; set; } = null!;

    public virtual VendorAttributeType VendorAttributeType { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class VendorOrderType
{
    public int VendorOrderTypeId { get; set; }

    public string Name { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<RefactorAssessmentsVendorOrderTableMigration> RefactorAssessmentsVendorOrderTableMigrations { get; set; } = new List<RefactorAssessmentsVendorOrderTableMigration>();

    public virtual ICollection<SystemSearchVendorOrderType> SystemSearchVendorOrderTypes { get; set; } = new List<SystemSearchVendorOrderType>();

    public virtual ICollection<VendorOrder> VendorOrders { get; set; } = new List<VendorOrder>();
}

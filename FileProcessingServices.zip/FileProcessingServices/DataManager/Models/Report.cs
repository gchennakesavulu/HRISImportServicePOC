﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class Report
{
    public int ReportId { get; set; }

    public int ReportCategoryId { get; set; }

    public string Name { get; set; } = null!;

    public string? Description { get; set; }

    public string ReportUrl { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ReportCategory ReportCategory { get; set; } = null!;
}

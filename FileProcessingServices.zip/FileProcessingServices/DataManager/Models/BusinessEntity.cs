﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class BusinessEntity
{
    public int BusinessEntityId { get; set; }

    public int BusinessEntityTypeId { get; set; }

    public string Name { get; set; } = null!;

    public string? DisplayName { get; set; }

    public string? Description { get; set; }

    public bool Active { get; set; }

    public int? ParentId { get; set; }

    public string? LogoFileLocation { get; set; }

    public string? Hrisidentifier { get; set; }

    /// <summary>
    /// Added State to this table to help with search performance. The value in this field can also be retrieved by joining to BusinessEntityAttrivuteValue and then the AttributeValue table.
    /// </summary>
    public string? State { get; set; }

    /// <summary>
    /// Added City to this table to help with search performance. The value in this field can also be retrieved by joining to BusinessEntityAttrivuteValue and then the AttributeValue table.
    /// </summary>
    public string? City { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<BusinessEntityAttributeValue> BusinessEntityAttributeValues { get; set; } = new List<BusinessEntityAttributeValue>();

    public virtual BusinessEntityType BusinessEntityType { get; set; } = null!;

    public virtual ICollection<DepartmentBusinessEntity> DepartmentBusinessEntities { get; set; } = new List<DepartmentBusinessEntity>();

    public virtual ICollection<DocumentGroupBusinessEntity> DocumentGroupBusinessEntities { get; set; } = new List<DocumentGroupBusinessEntity>();

    public virtual ICollection<FacilityBusinessEntity> FacilityBusinessEntities { get; set; } = new List<FacilityBusinessEntity>();

    public virtual ICollection<FormBusinessEntity> FormBusinessEntities { get; set; } = new List<FormBusinessEntity>();

    public virtual ICollection<FormPublished> FormPublisheds { get; set; } = new List<FormPublished>();

    public virtual ICollection<IdentityBusinessEntityMapping> IdentityBusinessEntityMappings { get; set; } = new List<IdentityBusinessEntityMapping>();

    public virtual ICollection<BusinessEntity> InverseParent { get; set; } = new List<BusinessEntity>();

    public virtual ICollection<JobPostingBusinessEntity> JobPostingBusinessEntities { get; set; } = new List<JobPostingBusinessEntity>();

    public virtual ICollection<JobPosting> JobPostings { get; set; } = new List<JobPosting>();

    public virtual ICollection<JobTemplateBusinessEntity> JobTemplateBusinessEntities { get; set; } = new List<JobTemplateBusinessEntity>();

    public virtual ICollection<MetaValueBusinessEntity> MetaValueBusinessEntities { get; set; } = new List<MetaValueBusinessEntity>();

    public virtual ICollection<OnBoardingDocumentBusinessEntity> OnBoardingDocumentBusinessEntities { get; set; } = new List<OnBoardingDocumentBusinessEntity>();

    public virtual ICollection<OnBoardingWelcomeMessage> OnBoardingWelcomeMessages { get; set; } = new List<OnBoardingWelcomeMessage>();

    public virtual BusinessEntity? Parent { get; set; }

    public virtual ICollection<Requisition> Requisitions { get; set; } = new List<Requisition>();

    public virtual ICollection<TemplateBusinessEntity> TemplateBusinessEntities { get; set; } = new List<TemplateBusinessEntity>();

    public virtual ICollection<VendorCorporateAccount> VendorCorporateAccounts { get; set; } = new List<VendorCorporateAccount>();
}

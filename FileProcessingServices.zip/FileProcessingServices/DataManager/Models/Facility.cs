﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class Facility
{
    public int FacilityId { get; set; }

    public string? Code { get; set; }

    public string Name { get; set; } = null!;

    public string? Address1 { get; set; }

    public string? Address2 { get; set; }

    public string? City { get; set; }

    public string? State { get; set; }

    public string? Zip { get; set; }

    public string? Url { get; set; }

    public string? Info { get; set; }

    public Guid? FacilityGuid { get; set; }

    public string? Hrisidentifier { get; set; }

    public bool Active { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<Department> Departments { get; set; } = new List<Department>();

    public virtual ICollection<FacilityBusinessEntity> FacilityBusinessEntities { get; set; } = new List<FacilityBusinessEntity>();
}

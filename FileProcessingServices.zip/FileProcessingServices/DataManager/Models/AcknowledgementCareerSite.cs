﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class AcknowledgementCareerSite
{
    public int AcknowledgementCareerSiteId { get; set; }

    public int CareerSiteId { get; set; }

    public int AcknowledgementId { get; set; }

    public bool IsLive { get; set; }

    public DateTime? LiveDate { get; set; }

    public DateTime? ExpirationDate { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual Acknowledgement Acknowledgement { get; set; } = null!;

    public virtual CareerSite CareerSite { get; set; } = null!;
}

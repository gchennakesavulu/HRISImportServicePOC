﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class RolePermission
{
    public int RolePermissionId { get; set; }

    public int RoleId { get; set; }

    public int PermissionId { get; set; }

    public bool HasAreaOfResponsibility { get; set; }

    public bool HasPositionInHierarchy { get; set; }

    public bool HasMyOwn { get; set; }

    public short? CustomLevel { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual Permission Permission { get; set; } = null!;

    public virtual Role Role { get; set; } = null!;
}

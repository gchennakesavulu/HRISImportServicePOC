﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class TemplateBusinessEntity
{
    public int TemplateBusinessEntityId { get; set; }

    public int TemplateId { get; set; }

    public int BusinessEntityId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual BusinessEntity BusinessEntity { get; set; } = null!;

    public virtual Template Template { get; set; } = null!;
}

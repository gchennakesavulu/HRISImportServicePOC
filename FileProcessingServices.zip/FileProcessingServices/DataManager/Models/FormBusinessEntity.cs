﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class FormBusinessEntity
{
    public int FormBusinessEntityId { get; set; }

    public int FormId { get; set; }

    public int BusinessEntityId { get; set; }

    public bool IsLive { get; set; }

    public DateTime? LiveDate { get; set; }

    public DateTime? ExpirationDate { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual BusinessEntity BusinessEntity { get; set; } = null!;

    public virtual Form Form { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class VendorOrderStatusTypeHistory
{
    public int VendorOrderStatusTypeHistoryId { get; set; }

    public int VendorOrderId { get; set; }

    public int VendorOrderStatusTypeId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual VendorOrder VendorOrder { get; set; } = null!;

    public virtual VendorOrderStatusType VendorOrderStatusType { get; set; } = null!;
}

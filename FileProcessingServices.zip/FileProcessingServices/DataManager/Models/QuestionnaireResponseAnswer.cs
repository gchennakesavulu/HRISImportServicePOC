﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class QuestionnaireResponseAnswer
{
    public int QuestionnaireResponseAnswerId { get; set; }

    /// <summary>
    /// This field groups sets of answers by an instance of QuestionnaireResponse. QuesionnaireResponse records are created each time a user answers a questionnaire.
    /// </summary>
    public int QuestionnaireResponseId { get; set; }

    public int QuestionId { get; set; }

    public int? AnswerId { get; set; }

    public string? AnswerText { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual Answer? Answer { get; set; }

    public virtual Question Question { get; set; } = null!;

    public virtual QuestionnaireResponse QuestionnaireResponse { get; set; } = null!;
}

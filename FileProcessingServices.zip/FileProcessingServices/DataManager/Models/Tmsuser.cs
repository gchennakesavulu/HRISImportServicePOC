﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class Tmsuser
{
    public int TmsuserId { get; set; }

    public string UserName { get; set; } = null!;

    public bool Active { get; set; }

    public string? Password { get; set; }

    public string? Salt { get; set; }

    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string? MiddleName { get; set; }

    public string Email { get; set; } = null!;

    public int? FailedLoginAttempts { get; set; }

    public DateTime? PasswordDate { get; set; }

    public string? Hrisidentifier { get; set; }

    public string? Ssoidentifier { get; set; }

    public string? JobTitle { get; set; }

    public int? TitleCategoryMetaValueId { get; set; }

    public int? ContactInformationId { get; set; }

    public int AccountStateTypeId { get; set; }

    public int PositionInHierarchyId { get; set; }

    public int? ManagerId { get; set; }

    public int? SendReqApprovalTo { get; set; }

    public bool IsSystemAccount { get; set; }

    public string? EmployeeId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public int ResetCount { get; set; }

    public virtual AccountStateType AccountStateType { get; set; } = null!;

    public virtual ICollection<Audit> Audits { get; set; } = new List<Audit>();

    public virtual ContactInformation? ContactInformation { get; set; }

    public virtual ICollection<ImpersonationAudit> ImpersonationAuditImpersonatedAsUsers { get; set; } = new List<ImpersonationAudit>();

    public virtual ICollection<ImpersonationAudit> ImpersonationAuditImpersonationUsers { get; set; } = new List<ImpersonationAudit>();

    public virtual ICollection<InterviewParticipant> InterviewParticipants { get; set; } = new List<InterviewParticipant>();

    public virtual ICollection<InterviewUser> InterviewUsers { get; set; } = new List<InterviewUser>();

    public virtual ICollection<Interview> Interviews { get; set; } = new List<Interview>();

    public virtual ICollection<Tmsuser> InverseManager { get; set; } = new List<Tmsuser>();

    public virtual ICollection<JobDistributionJobInfo> JobDistributionJobInfos { get; set; } = new List<JobDistributionJobInfo>();

    public virtual ICollection<JobTemplatePropagationHri> JobTemplatePropagationHris { get; set; } = new List<JobTemplatePropagationHri>();

    public virtual ICollection<JobTemplatePropagationJob> JobTemplatePropagationJobs { get; set; } = new List<JobTemplatePropagationJob>();

    public virtual Tmsuser? Manager { get; set; }

    public virtual ICollection<PasswordHistory> PasswordHistories { get; set; } = new List<PasswordHistory>();

    public virtual ICollection<TextMessageSnippet> TextMessageSnippets { get; set; } = new List<TextMessageSnippet>();

    public virtual ICollection<TmsuserAreaOfResponsibility> TmsuserAreaOfResponsibilities { get; set; } = new List<TmsuserAreaOfResponsibility>();

    public virtual ICollection<TmsuserRole> TmsuserRoles { get; set; } = new List<TmsuserRole>();

    public virtual ICollection<UserAccountStateTypeHistory> UserAccountStateTypeHistories { get; set; } = new List<UserAccountStateTypeHistory>();

    public virtual ICollection<UserPreference> UserPreferences { get; set; } = new List<UserPreference>();
}

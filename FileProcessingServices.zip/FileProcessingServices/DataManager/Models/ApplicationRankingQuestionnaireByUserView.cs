﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ApplicationRankingQuestionnaireByUserView
{
    public int ApplicationId { get; set; }

    public int? TmsuserId { get; set; }

    public decimal? Score { get; set; }
}

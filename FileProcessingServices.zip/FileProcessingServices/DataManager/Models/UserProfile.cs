﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class UserProfile
{
    public int TmsuserId { get; set; }

    public string FirstName { get; set; } = null!;

    public string? MiddleName { get; set; }

    public string LastName { get; set; } = null!;

    public string UserName { get; set; } = null!;

    public string Email { get; set; } = null!;

    public bool Active { get; set; }

    public string? JobTitle { get; set; }

    /// <summary>
    /// Mapped to the TitleCategory MetaTypeID. Will be used to group requisition approvers by Title category E.g: VP, CEO, etc.
    /// </summary>
    public int? TitleCategoryMetaValueId { get; set; }

    public int? ContactInformationId { get; set; }

    public int? SendReqApprovalTo { get; set; }

    public int PositionInHierarchyId { get; set; }

    public bool IsSystemAccount { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<ApplicationAcl> ApplicationAcls { get; set; } = new List<ApplicationAcl>();

    public virtual ICollection<ApplicationDocumentAcl> ApplicationDocumentAcls { get; set; } = new List<ApplicationDocumentAcl>();

    public virtual ICollection<CommunicationCcBccUserProfile> CommunicationCcBccUserProfiles { get; set; } = new List<CommunicationCcBccUserProfile>();

    public virtual ICollection<Communication> CommunicationRecipientUsers { get; set; } = new List<Communication>();

    public virtual ICollection<Communication> CommunicationSenderUsers { get; set; } = new List<Communication>();

    public virtual ContactInformation1? ContactInformation { get; set; }

    public virtual ICollection<JobPosting> JobPostingContactUsers { get; set; } = new List<JobPosting>();

    public virtual ICollection<JobPosting> JobPostingCreatedByNavigations { get; set; } = new List<JobPosting>();

    public virtual ICollection<Note> NoteCreatedByNavigations { get; set; } = new List<Note>();

    public virtual ICollection<Note> NoteModifiedByNavigations { get; set; } = new List<Note>();

    public virtual ICollection<Note> NoteNoteUsers { get; set; } = new List<Note>();

    public virtual ICollection<QuestionnaireResponse> QuestionnaireResponses { get; set; } = new List<QuestionnaireResponse>();

    public virtual ICollection<RecruitingAuditLog> RecruitingAuditLogs { get; set; } = new List<RecruitingAuditLog>();

    public virtual ICollection<RequisitionAcl> RequisitionAcls { get; set; } = new List<RequisitionAcl>();

    public virtual ICollection<RequisitionAdditionalUser> RequisitionAdditionalUsers { get; set; } = new List<RequisitionAdditionalUser>();

    public virtual ICollection<Requisition> RequisitionApprovers { get; set; } = new List<Requisition>();

    public virtual ICollection<RequisitionApprover> RequisitionApproversNavigation { get; set; } = new List<RequisitionApprover>();

    public virtual ICollection<Requisition> RequisitionHiringManagers { get; set; } = new List<Requisition>();

    public virtual ICollection<Requisition> RequisitionRecruiters { get; set; } = new List<Requisition>();

    public virtual ICollection<TalentAnalyticsConsent> TalentAnalyticsConsents { get; set; } = new List<TalentAnalyticsConsent>();

    public virtual ICollection<Task> TaskAssignedToUsers { get; set; } = new List<Task>();

    public virtual ICollection<Task> TaskOriginatorUsers { get; set; } = new List<Task>();

    public virtual ICollection<TextMessage> TextMessages { get; set; } = new List<TextMessage>();

    public virtual MetaValue? TitleCategoryMetaValue { get; set; }

    public virtual ICollection<UserProfileRoleType> UserProfileRoleTypes { get; set; } = new List<UserProfileRoleType>();

    public virtual ICollection<UserProfileVendorUserAccount> UserProfileVendorUserAccounts { get; set; } = new List<UserProfileVendorUserAccount>();

    public virtual ICollection<VendorAuditLog> VendorAuditLogs { get; set; } = new List<VendorAuditLog>();

    public virtual ICollection<VendorSsoAccessAudit> VendorSsoAccessAudits { get; set; } = new List<VendorSsoAccessAudit>();

    public virtual ICollection<VendorUserAccount> VendorUserAccounts { get; set; } = new List<VendorUserAccount>();
}

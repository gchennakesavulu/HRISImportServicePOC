﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class QuestionnaireResponse
{
    public int QuestionnaireResponseId { get; set; }

    public int QuestionnaireId { get; set; }

    public int ApplicationId { get; set; }

    public int? TmsuserId { get; set; }

    public int? RoleTypeId { get; set; }

    /// <summary>
    /// This field stores optional combined scrore of the questionnaire. Note: for a pass/fail type questionnaires it will store 1/0 for pass/fail.
    /// </summary>
    public decimal? Score { get; set; }

    public string? Comment { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual Application Application { get; set; } = null!;

    public virtual ICollection<Document> Documents { get; set; } = new List<Document>();

    public virtual Questionnaire Questionnaire { get; set; } = null!;

    public virtual ICollection<QuestionnaireResponseAnswer> QuestionnaireResponseAnswers { get; set; } = new List<QuestionnaireResponseAnswer>();

    public virtual RoleType? RoleType { get; set; }

    public virtual UserProfile? Tmsuser { get; set; }
}

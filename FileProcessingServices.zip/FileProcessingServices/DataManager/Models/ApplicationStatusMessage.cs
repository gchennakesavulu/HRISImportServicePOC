﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ApplicationStatusMessage
{
    public int ApplicationStatusMessageId { get; set; }

    public int ApplicationStatusTypeId { get; set; }

    public int CareerSiteId { get; set; }

    /// <summary>
    /// This column contains the status message that is displayed to the applicant.
    /// </summary>
    public string? Message { get; set; }

    /// <summary>
    /// A bit to indicate if the user checked off the option to append the disposition to the application status message.
    /// </summary>
    public bool IsDispositionIncluded { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public int? Sequence { get; set; }

    public virtual ApplicationStatusType ApplicationStatusType { get; set; } = null!;

    public virtual CareerSite CareerSite { get; set; } = null!;
}

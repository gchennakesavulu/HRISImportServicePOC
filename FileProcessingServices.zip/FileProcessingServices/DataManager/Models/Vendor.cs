﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class Vendor
{
    /// <summary>
    /// VendorID is not an Identity primary key as it will be brought over from the Global Vendor table.
    /// </summary>
    public int VendorId { get; set; }

    public string Name { get; set; } = null!;

    public string InternalIdentifier { get; set; } = null!;

    public string? Description { get; set; }

    public bool? IsPreferredPartner { get; set; }

    /// <summary>
    /// The ProviderKey identifies which Provider factory implementation is being used for the integration.
    /// </summary>
    public int ProviderKey { get; set; }

    /// <summary>
    /// The VendorType table is not brought down from the global database, so VendorTypeID is not expressed explicitly as a foreign key.
    /// </summary>
    public int VendorTypeId { get; set; }

    public bool? UseMessageEncryption { get; set; }

    public bool? UseMutualCertificate { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public string? InitiationWindowSource { get; set; }

    public int PostingMediaType { get; set; }

    public bool Active { get; set; }

    public virtual ICollection<JobDistributionJobInfo> JobDistributionJobInfos { get; set; } = new List<JobDistributionJobInfo>();

    public virtual ICollection<JobDistributionJobSync> JobDistributionJobSyncs { get; set; } = new List<JobDistributionJobSync>();

    public virtual ICollection<JobDistributionVendorApplication> JobDistributionVendorApplications { get; set; } = new List<JobDistributionVendorApplication>();

    public virtual ICollection<JobFamily> JobFamilies { get; set; } = new List<JobFamily>();

    public virtual ICollection<JobPostingVendor> JobPostingVendors { get; set; } = new List<JobPostingVendor>();

    public virtual ICollection<JobTemplateInstance> JobTemplateInstances { get; set; } = new List<JobTemplateInstance>();

    public virtual ICollection<JobTemplate> JobTemplates { get; set; } = new List<JobTemplate>();

    public virtual ICollection<RefactorAssessmentsVendorOrderTableMigration> RefactorAssessmentsVendorOrderTableMigrations { get; set; } = new List<RefactorAssessmentsVendorOrderTableMigration>();

    public virtual ICollection<VendorAttribute> VendorAttributes { get; set; } = new List<VendorAttribute>();

    public virtual ICollection<VendorAuditLog> VendorAuditLogs { get; set; } = new List<VendorAuditLog>();

    public virtual ICollection<VendorCorporateAccount> VendorCorporateAccounts { get; set; } = new List<VendorCorporateAccount>();

    public virtual ICollection<VendorOrder> VendorOrders { get; set; } = new List<VendorOrder>();

    public virtual ICollection<VendorUserAccount> VendorUserAccounts { get; set; } = new List<VendorUserAccount>();
}

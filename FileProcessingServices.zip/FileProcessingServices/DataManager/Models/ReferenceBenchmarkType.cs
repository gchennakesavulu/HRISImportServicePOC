﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ReferenceBenchmarkType
{
    public int ReferenceBenchmarkTypeId { get; set; }

    public string Name { get; set; } = null!;

    public string? Hrisidentifier { get; set; }

    public int? ParentId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<ReferenceBenchmarkType> InverseParent { get; set; } = new List<ReferenceBenchmarkType>();

    public virtual ICollection<JobTemplateInstance> JobTemplateInstances { get; set; } = new List<JobTemplateInstance>();

    public virtual ICollection<JobTemplate> JobTemplates { get; set; } = new List<JobTemplate>();

    public virtual ReferenceBenchmarkType? Parent { get; set; }
}

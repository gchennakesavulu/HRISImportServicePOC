﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class JobTemplatePropagationRequisitionSyncErrorLog
{
    public int JobTemplatePropagationRequisitionSyncErrorLogId { get; set; }

    public int? JobTemplatePropagationRequisitionId { get; set; }

    public int JobTemplatePropagationJobInstanceId { get; set; }

    public int JobTemplatePropagationTargetId { get; set; }

    public DateTime OperationTime { get; set; }

    public string? Reason { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual JobTemplatePropagationJobInstance JobTemplatePropagationJobInstance { get; set; } = null!;

    public virtual JobTemplatePropagationRequisition? JobTemplatePropagationRequisition { get; set; }

    public virtual JobTemplatePropagationTarget JobTemplatePropagationTarget { get; set; } = null!;
}

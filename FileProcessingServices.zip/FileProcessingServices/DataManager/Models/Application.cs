﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class Application
{
    public int ApplicationId { get; set; }

    public int? ApplicantId { get; set; }

    public int? LocalApplicantId { get; set; }

    public int RequisitionId { get; set; }

    public int ApplicationStatusTypeId { get; set; }

    public DateTime? ApplicationStatusDate { get; set; }

    public int ApplicationTypeId { get; set; }

    public int? NewHireFormId { get; set; }

    public DateTime ApplicationDate { get; set; }

    public string ApplicantFirstName { get; set; } = null!;

    public string? ApplicantMiddleName { get; set; }

    public string ApplicantLastName { get; set; } = null!;

    public string? Email { get; set; }

    public bool EmailVerified { get; set; }

    /// <summary>
    /// Added for PBI 28987,  Stores the Encrypted value for Social Security Number of Applicant.
    /// </summary>
    public string? EncryptedSsn { get; set; }

    /// <summary>
    /// Added for PBI 28987,  Stores the Unencrypted value for the last four digits of the Applicant&apos;&apos;s Social Security Number.
    /// </summary>
    public string? LastFourSsn { get; set; }

    public bool IsInternal { get; set; }

    /// <summary>
    /// If the application was sent by recruiters to multiple hiring managers for their review, this bit indicates if any of the hiring managers views the application.
    /// 
    /// Definition of viewed:
    /// 1. Hiring manager expands the master detail on the Manage applications page.
    /// 2. Hiring manager opens up the detail page.
    /// </summary>
    public bool ViewedByHiringManager { get; set; }

    public bool OriginatedInCareerSite { get; set; }

    public int? JobCategoryMetaValueId { get; set; }

    public int? DispositionMetaValueId { get; set; }

    public int? SourceNameMetaValueId { get; set; }

    public int? SourceCategoryMetaValueId { get; set; }

    /// <summary>
    /// Represents the communication channel through which the associated applicant found there way into the system.
    /// </summary>
    public int ReceivedViaMetaValueId { get; set; }

    public string? ResumeText { get; set; }

    public string? CoverLetter { get; set; }

    public DateTime? StartDate { get; set; }

    public int? SettingsWorkflowId { get; set; }

    /// <summary>
    /// (Deprecated)This filed stores the id of the workflow process instance. This value should be replaced by the corresponding workflow serial number that allows faster access to the workflow list items.
    /// </summary>
    public int? JobApplyWorkflowProcessId { get; set; }

    /// <summary>
    /// Will hold the ID of the Legacy Account (PM10 Site Manager Account) the application is tied to.  Migration will be the only process that will populate this column.
    /// </summary>
    public int? LegacyAccountId { get; set; }

    public string? Street1 { get; set; }

    public string? Street2 { get; set; }

    public string? City { get; set; }

    public int? StateMetaValueId { get; set; }

    public string? Zipcode { get; set; }

    public int? CountryMetaValueId { get; set; }

    public string? PhoneNumber { get; set; }

    public int? PhoneTypeMetaValueId { get; set; }

    public int? ContactMethodMetaValueId { get; set; }

    public int? CopiedFromApplicationId { get; set; }

    public int? JobPostingId { get; set; }

    /// <summary>
    /// Denormalized column to determine if the Application has an associated application document.
    /// </summary>
    public bool HasApplicationDocument { get; set; }

    /// <summary>
    /// Denormalized column to determine if the Application has an associated resume document.
    /// </summary>
    public bool HasResumeDocument { get; set; }

    public bool HasShortApplicationDocument { get; set; }

    public bool IsDraft { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public string? JobseekerApplicationId { get; set; }

    public bool HasCoverLetter { get; set; }

    public DateTime? InviteBackApplicationDate { get; set; }

    public Guid? Suid { get; set; }

    public virtual ICollection<ApplicationAcknowledgement> ApplicationAcknowledgements { get; set; } = new List<ApplicationAcknowledgement>();

    public virtual ICollection<ApplicationAcl> ApplicationAcls { get; set; } = new List<ApplicationAcl>();

    public virtual ICollection<ApplicationApplicationForm> ApplicationApplicationForms { get; set; } = new List<ApplicationApplicationForm>();

    public virtual ICollection<ApplicationCommunication> ApplicationCommunications { get; set; } = new List<ApplicationCommunication>();

    public virtual ICollection<ApplicationDocument> ApplicationDocuments { get; set; } = new List<ApplicationDocument>();

    public virtual ICollection<ApplicationFieldValue> ApplicationFieldValues { get; set; } = new List<ApplicationFieldValue>();

    public virtual ICollection<ApplicationGlobalCompare> ApplicationGlobalCompares { get; set; } = new List<ApplicationGlobalCompare>();

    public virtual ICollection<ApplicationMostRecent> ApplicationMostRecents { get; set; } = new List<ApplicationMostRecent>();

    public virtual ApplicationStatusType ApplicationStatusType { get; set; } = null!;

    public virtual ApplicationType ApplicationType { get; set; } = null!;

    public virtual ICollection<ApplicationVendorOrder> ApplicationVendorOrders { get; set; } = new List<ApplicationVendorOrder>();

    public virtual ICollection<AssessmentVendorOrder> AssessmentVendorOrders { get; set; } = new List<AssessmentVendorOrder>();

    public virtual MetaValue? ContactMethodMetaValue { get; set; }

    public virtual MetaValue? CountryMetaValue { get; set; }

    public virtual MetaValue? DispositionMetaValue { get; set; }

    public virtual ICollection<EsignatureDocument> EsignatureDocuments { get; set; } = new List<EsignatureDocument>();

    public virtual ICollection<Interview> Interviews { get; set; } = new List<Interview>();

    public virtual MetaValue? JobCategoryMetaValue { get; set; }

    public virtual ICollection<JobDistributionVendorApplication> JobDistributionVendorApplications { get; set; } = new List<JobDistributionVendorApplication>();

    public virtual JobPosting? JobPosting { get; set; }

    public virtual LocalApplicant? LocalApplicant { get; set; }

    public virtual ICollection<NewHire> NewHires { get; set; } = new List<NewHire>();

    public virtual MetaValue? PhoneTypeMetaValue { get; set; }

    public virtual ICollection<QuestionnaireResponse> QuestionnaireResponses { get; set; } = new List<QuestionnaireResponse>();

    public virtual MetaValue ReceivedViaMetaValue { get; set; } = null!;

    public virtual ICollection<ReferenceCheckApplicationLock> ReferenceCheckApplicationLocks { get; set; } = new List<ReferenceCheckApplicationLock>();

    public virtual Requisition Requisition { get; set; } = null!;

    public virtual MetaValue? SourceCategoryMetaValue { get; set; }

    public virtual MetaValue? SourceNameMetaValue { get; set; }

    public virtual MetaValue? StateMetaValue { get; set; }

    public virtual ICollection<TextMessage> TextMessages { get; set; } = new List<TextMessage>();
}

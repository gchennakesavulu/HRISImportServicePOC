﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class JobTemplateInstanceLeanCapitalJobFamilyType
{
    public int JobTemplateInstanceLeanCapitalJobFamilyTypeId { get; set; }

    public int JobTemplateInstanceId { get; set; }

    public int? LeanCapitalJobFamilyTypeId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual JobTemplateInstance JobTemplateInstance { get; set; } = null!;

    public virtual LeanCapitalJobFamilyType? LeanCapitalJobFamilyType { get; set; }
}

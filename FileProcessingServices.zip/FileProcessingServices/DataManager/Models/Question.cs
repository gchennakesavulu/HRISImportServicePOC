﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class Question
{
    public int QuestionId { get; set; }

    public int QuestionnaireId { get; set; }

    public string QuestionText { get; set; } = null!;

    public bool IsHorizontal { get; set; }

    public int QuestionDisplayTypeId { get; set; }

    public int Sequence { get; set; }

    public short? Weight { get; set; }

    public decimal? Score { get; set; }

    public bool IsRequired { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<Answer> Answers { get; set; } = new List<Answer>();

    public virtual QuestionDisplayType QuestionDisplayType { get; set; } = null!;

    public virtual Questionnaire Questionnaire { get; set; } = null!;

    public virtual ICollection<QuestionnaireResponseAnswer> QuestionnaireResponseAnswers { get; set; } = new List<QuestionnaireResponseAnswer>();
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class FormMetaTypeAnnotation
{
    public int FormMetaTypeAnnotationId { get; set; }

    public int AnnotationTypeId { get; set; }

    public int FormMetaTypeId { get; set; }

    public string? AnnotationFormat { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual AnnotationType AnnotationType { get; set; } = null!;

    public virtual FormMetaType FormMetaType { get; set; } = null!;
}

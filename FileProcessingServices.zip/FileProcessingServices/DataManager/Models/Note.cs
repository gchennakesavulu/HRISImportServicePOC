﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class Note
{
    public int NoteId { get; set; }

    /// <summary>
    /// There should always be some text in Text Column
    /// </summary>
    public string Text { get; set; } = null!;

    public int DataSourceTypeId { get; set; }

    public int? RecordId { get; set; }

    public int ContextObjectId { get; set; }

    public string? ModifiedUserLastName { get; set; }

    public string? ModifiedUserFirstName { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public string? Hrisidentifier { get; set; }

    public DateTime? NoteDate { get; set; }

    public int? NoteUserId { get; set; }

    public virtual ICollection<ApplicantGlobalNoteStaging> ApplicantGlobalNoteStagings { get; set; } = new List<ApplicantGlobalNoteStaging>();

    public virtual UserProfile CreatedByNavigation { get; set; } = null!;

    public virtual DataSourceType DataSourceType { get; set; } = null!;

    public virtual UserProfile? ModifiedByNavigation { get; set; }

    public virtual UserProfile? NoteUser { get; set; }
}

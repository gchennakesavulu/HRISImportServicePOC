﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class WorkflowStepUser
{
    public int WorkflowStepUserId { get; set; }

    public int SettingsWorkflowStepId { get; set; }

    public int TmsuserId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual SettingsWorkflowStep SettingsWorkflowStep { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class RequisitionVendorOrder
{
    public int RequisitionVendorOrderId { get; set; }

    public int RequisitionId { get; set; }

    public int VendorOrderId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual Requisition Requisition { get; set; } = null!;

    public virtual VendorOrder VendorOrder { get; set; } = null!;
}

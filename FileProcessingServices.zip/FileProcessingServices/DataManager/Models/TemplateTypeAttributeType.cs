﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class TemplateTypeAttributeType
{
    public int TemplateTypeAttributeTypeId { get; set; }

    public int TemplateTypeId { get; set; }

    public int AttributeTypeId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual AttributeType AttributeType { get; set; } = null!;

    public virtual TemplateType TemplateType { get; set; } = null!;
}

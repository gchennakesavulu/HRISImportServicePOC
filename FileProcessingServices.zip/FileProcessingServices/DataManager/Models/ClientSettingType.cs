﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ClientSettingType
{
    public int ClientSettingTypeId { get; set; }

    public string? Name { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public bool IsDynamicSetting { get; set; }

    public virtual ICollection<ClientSetting> ClientSettings { get; set; } = new List<ClientSetting>();
}

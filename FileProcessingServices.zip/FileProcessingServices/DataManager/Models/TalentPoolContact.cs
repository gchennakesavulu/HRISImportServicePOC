﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class TalentPoolContact
{
    public int TalentPoolContactId { get; set; }

    public string? Hrisidentifier { get; set; }

    public string? Code { get; set; }

    public string FirstName { get; set; } = null!;

    public string? MiddleName { get; set; }

    public string LastName { get; set; } = null!;

    public string? Address { get; set; }

    public string? Address2 { get; set; }

    public string? City { get; set; }

    public int? StateId { get; set; }

    public string? ZipCode { get; set; }

    public string? Email { get; set; }

    public string? HomePhone { get; set; }

    public string? CellPhone { get; set; }

    public string? Title { get; set; }

    public int? TalentPoolContactStatusTypeId { get; set; }

    public int? StatusId { get; set; }

    public int? DispositionId { get; set; }

    public bool? CanEmail { get; set; }

    public bool? IsAddressVerified { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual MetaValue? Disposition { get; set; }

    public virtual MetaValue? State { get; set; }

    public virtual MetaValue? Status { get; set; }

    public virtual ICollection<TalentPoolContactCommunication> TalentPoolContactCommunications { get; set; } = new List<TalentPoolContactCommunication>();

    public virtual ICollection<TalentPoolContactDocument> TalentPoolContactDocuments { get; set; } = new List<TalentPoolContactDocument>();
}

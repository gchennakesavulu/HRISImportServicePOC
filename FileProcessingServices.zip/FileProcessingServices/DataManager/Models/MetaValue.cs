﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class MetaValue
{
    public int MetaValueId { get; set; }

    public int MetaTypeId { get; set; }

    public string Name { get; set; } = null!;

    /// <summary>
    /// MetaValue values are passed via HrXml documents to 3rd party vendors. HrXml standard schema imposes restrictions on values such as gender (Male/Female) or Boolean values (true/false). These HrXml values may different from HCS values. For example, HCS uses Yes/No for Boolean. This column contains the value for this MetaValue that should be used to use to populate HrXml document if this value is different from the value of Name column.
    /// </summary>
    public string? HrXmlValue { get; set; }

    public string? Description { get; set; }

    public string? ShortName { get; set; }

    public bool Active { get; set; }

    public int? Sequence { get; set; }

    public string? Color { get; set; }

    public string? ExtMessage { get; set; }

    /// <summary>
    /// This column, which will default to match the Name column, will be used to internally identify the field record for a given meta type.  this is being doine so that we can reliably correlate fileds across environments without having to rely on the tables int identity column being consistent. The default value is set to a NEWID() and is set to the value of name in a post-deployment script because you cannot default a value to the value of another column.
    /// </summary>
    public string? InternalName { get; set; }

    /// <summary>
    /// This column will be used to uniquely identify a record in this table.  It is a calculated column that is a checksum of the InternalName column.
    /// 
    /// </summary>
    public int? InternalNameId { get; set; }

    /// <summary>
    /// The identifier of the MetaValue in the external system of record.
    /// </summary>
    public string? Hrisidentifier { get; set; }

    public int Deleted { get; set; }

    public DateTime? CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<Application> ApplicationContactMethodMetaValues { get; set; } = new List<Application>();

    public virtual ICollection<Application> ApplicationCountryMetaValues { get; set; } = new List<Application>();

    public virtual ICollection<Application> ApplicationDispositionMetaValues { get; set; } = new List<Application>();

    public virtual ICollection<ApplicationFieldValue> ApplicationFieldValues { get; set; } = new List<ApplicationFieldValue>();

    public virtual ICollection<ApplicationGlobalCompare> ApplicationGlobalCompares { get; set; } = new List<ApplicationGlobalCompare>();

    public virtual ICollection<Application> ApplicationJobCategoryMetaValues { get; set; } = new List<Application>();

    public virtual ICollection<Application> ApplicationPhoneTypeMetaValues { get; set; } = new List<Application>();

    public virtual ICollection<Application> ApplicationReceivedViaMetaValues { get; set; } = new List<Application>();

    public virtual ICollection<Application> ApplicationSourceCategoryMetaValues { get; set; } = new List<Application>();

    public virtual ICollection<Application> ApplicationSourceNameMetaValues { get; set; } = new List<Application>();

    public virtual ICollection<Application> ApplicationStateMetaValues { get; set; } = new List<Application>();

    public virtual ICollection<ClientSettingDefaultListValue> ClientSettingDefaultListValues { get; set; } = new List<ClientSettingDefaultListValue>();

    public virtual ICollection<Communication> Communications { get; set; } = new List<Communication>();

    public virtual ICollection<JobPostingFieldValue> JobPostingFieldValues { get; set; } = new List<JobPostingFieldValue>();

    public virtual ICollection<JobPosting> JobPostings { get; set; } = new List<JobPosting>();

    public virtual ICollection<JobTemplate> JobTemplateCategories { get; set; } = new List<JobTemplate>();

    public virtual ICollection<JobTemplate> JobTemplateEducations { get; set; } = new List<JobTemplate>();

    public virtual ICollection<JobTemplate> JobTemplateEeojobGroups { get; set; } = new List<JobTemplate>();

    public virtual ICollection<JobTemplateFieldValue> JobTemplateFieldValues { get; set; } = new List<JobTemplateFieldValue>();

    public virtual ICollection<JobTemplateInstance> JobTemplateInstanceCategories { get; set; } = new List<JobTemplateInstance>();

    public virtual ICollection<JobTemplateInstance> JobTemplateInstanceEducations { get; set; } = new List<JobTemplateInstance>();

    public virtual ICollection<JobTemplateInstance> JobTemplateInstanceEeojobGroups { get; set; } = new List<JobTemplateInstance>();

    public virtual ICollection<JobTemplateInstance> JobTemplateInstanceJobStatuses { get; set; } = new List<JobTemplateInstance>();

    public virtual ICollection<JobTemplateInstanceMetaValue> JobTemplateInstanceMetaValues { get; set; } = new List<JobTemplateInstanceMetaValue>();

    public virtual ICollection<JobTemplateInstance> JobTemplateInstancePayGrades { get; set; } = new List<JobTemplateInstance>();

    public virtual ICollection<JobTemplateInstance> JobTemplateInstanceSalaryRanges { get; set; } = new List<JobTemplateInstance>();

    public virtual ICollection<JobTemplateInstance> JobTemplateInstanceSchedules { get; set; } = new List<JobTemplateInstance>();

    public virtual ICollection<JobTemplateInstance> JobTemplateInstanceShifts { get; set; } = new List<JobTemplateInstance>();

    public virtual ICollection<JobTemplate> JobTemplateJobStatuses { get; set; } = new List<JobTemplate>();

    public virtual ICollection<JobTemplateMetaValue> JobTemplateMetaValues { get; set; } = new List<JobTemplateMetaValue>();

    public virtual ICollection<JobTemplate> JobTemplatePayGrades { get; set; } = new List<JobTemplate>();

    public virtual ICollection<JobTemplate> JobTemplateSalaryRanges { get; set; } = new List<JobTemplate>();

    public virtual ICollection<JobTemplate> JobTemplateSchedules { get; set; } = new List<JobTemplate>();

    public virtual ICollection<JobTemplate> JobTemplateShifts { get; set; } = new List<JobTemplate>();

    public virtual ICollection<LocalApplicant> LocalApplicantContactMethodMetaValues { get; set; } = new List<LocalApplicant>();

    public virtual ICollection<LocalApplicant> LocalApplicantCountryMetaValues { get; set; } = new List<LocalApplicant>();

    public virtual ICollection<LocalApplicant> LocalApplicantPhoneTypeMetaValues { get; set; } = new List<LocalApplicant>();

    public virtual ICollection<LocalApplicant> LocalApplicantSourceCategoryMetaValues { get; set; } = new List<LocalApplicant>();

    public virtual ICollection<LocalApplicant> LocalApplicantSourceNameMetaValues { get; set; } = new List<LocalApplicant>();

    public virtual ICollection<LocalApplicant> LocalApplicantStateMetaValues { get; set; } = new List<LocalApplicant>();

    public virtual MetaType MetaType { get; set; } = null!;

    public virtual ICollection<MetaValueBusinessEntity> MetaValueBusinessEntities { get; set; } = new List<MetaValueBusinessEntity>();

    public virtual ICollection<NewHireFieldValue> NewHireFieldValues { get; set; } = new List<NewHireFieldValue>();

    public virtual ICollection<OnBoardingDocument> OnBoardingDocuments { get; set; } = new List<OnBoardingDocument>();

    public virtual ICollection<RequisitionFieldValue> RequisitionFieldValues { get; set; } = new List<RequisitionFieldValue>();

    public virtual ICollection<Requisition> Requisitions { get; set; } = new List<Requisition>();

    public virtual ICollection<SettingsInternal> SettingsInternals { get; set; } = new List<SettingsInternal>();

    public virtual ICollection<TalentPoolContact> TalentPoolContactDispositions { get; set; } = new List<TalentPoolContact>();

    public virtual ICollection<TalentPoolContact> TalentPoolContactStates { get; set; } = new List<TalentPoolContact>();

    public virtual ICollection<TalentPoolContact> TalentPoolContactStatuses { get; set; } = new List<TalentPoolContact>();

    public virtual ICollection<Template> Templates { get; set; } = new List<Template>();

    public virtual ICollection<UserProfile> UserProfiles { get; set; } = new List<UserProfile>();
}

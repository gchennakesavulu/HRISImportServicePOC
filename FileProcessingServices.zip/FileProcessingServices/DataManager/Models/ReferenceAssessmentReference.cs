﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ReferenceAssessmentReference
{
    public int ReferenceAssessmentReferenceId { get; set; }

    public int VendorOrderId { get; set; }

    public int ReferenceIdentifier { get; set; }

    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string Status { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual VendorOrder VendorOrder { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class JobTemplatePropagationField
{
    public int JobTemplatePropagationFieldId { get; set; }

    public int MetaTypeId { get; set; }

    public string DisplayName { get; set; } = null!;

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<JobTemplatePropagationFieldInstance> JobTemplatePropagationFieldInstances { get; set; } = new List<JobTemplatePropagationFieldInstance>();

    public virtual MetaType MetaType { get; set; } = null!;

    public virtual ICollection<SettingsClientJobTemplatePropagationField> SettingsClientJobTemplatePropagationFields { get; set; } = new List<SettingsClientJobTemplatePropagationField>();
}

﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace DataManager.Models;

public partial class PositionManagerDbContext : DbContext
{
    public PositionManagerDbContext(DbContextOptions<PositionManagerDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<AccountStateType> AccountStateTypes { get; set; }

    public virtual DbSet<Acknowledgement> Acknowledgements { get; set; }

    public virtual DbSet<AcknowledgementCareerSite> AcknowledgementCareerSites { get; set; }

    public virtual DbSet<AcknowledgementPublished> AcknowledgementPublisheds { get; set; }

    public virtual DbSet<AcknowledgementType> AcknowledgementTypes { get; set; }

    public virtual DbSet<AnnotationType> AnnotationTypes { get; set; }

    public virtual DbSet<Announcement> Announcements { get; set; }

    public virtual DbSet<AnnouncementRoleType> AnnouncementRoleTypes { get; set; }

    public virtual DbSet<Answer> Answers { get; set; }

    public virtual DbSet<ApplicantGlobalNoteStaging> ApplicantGlobalNoteStagings { get; set; }

    public virtual DbSet<ApplicantLocalApplicant> ApplicantLocalApplicants { get; set; }

    public virtual DbSet<Application> Applications { get; set; }

    public virtual DbSet<ApplicationAcknowledgement> ApplicationAcknowledgements { get; set; }

    public virtual DbSet<ApplicationAcl> ApplicationAcls { get; set; }

    public virtual DbSet<ApplicationApplicationForm> ApplicationApplicationForms { get; set; }

    public virtual DbSet<ApplicationCommunication> ApplicationCommunications { get; set; }

    public virtual DbSet<ApplicationDocument> ApplicationDocuments { get; set; }

    public virtual DbSet<ApplicationDocumentAcl> ApplicationDocumentAcls { get; set; }

    public virtual DbSet<ApplicationFieldValue> ApplicationFieldValues { get; set; }

    public virtual DbSet<ApplicationForm> ApplicationForms { get; set; }

    public virtual DbSet<ApplicationFormBinderMetaDatum> ApplicationFormBinderMetaData { get; set; }

    public virtual DbSet<ApplicationFormType> ApplicationFormTypes { get; set; }

    public virtual DbSet<ApplicationGlobalCompare> ApplicationGlobalCompares { get; set; }

    public virtual DbSet<ApplicationGlobalNoteView> ApplicationGlobalNoteViews { get; set; }

    public virtual DbSet<ApplicationGroup> ApplicationGroups { get; set; }

    public virtual DbSet<ApplicationInternalNoteView> ApplicationInternalNoteViews { get; set; }

    public virtual DbSet<ApplicationMostRecent> ApplicationMostRecents { get; set; }

    public virtual DbSet<ApplicationNoteView> ApplicationNoteViews { get; set; }

    public virtual DbSet<ApplicationRankingQuestionnaireByUserView> ApplicationRankingQuestionnaireByUserViews { get; set; }

    public virtual DbSet<ApplicationRequisitionView> ApplicationRequisitionViews { get; set; }

    public virtual DbSet<ApplicationScheduleView> ApplicationScheduleViews { get; set; }

    public virtual DbSet<ApplicationShiftView> ApplicationShiftViews { get; set; }

    public virtual DbSet<ApplicationSnapshotReportQueue> ApplicationSnapshotReportQueues { get; set; }

    public virtual DbSet<ApplicationStatusFullMessage> ApplicationStatusFullMessages { get; set; }

    public virtual DbSet<ApplicationStatusMessage> ApplicationStatusMessages { get; set; }

    public virtual DbSet<ApplicationStatusType> ApplicationStatusTypes { get; set; }

    public virtual DbSet<ApplicationStatusView> ApplicationStatusViews { get; set; }

    public virtual DbSet<ApplicationType> ApplicationTypes { get; set; }

    public virtual DbSet<ApplicationVendorOrder> ApplicationVendorOrders { get; set; }

    public virtual DbSet<ApplicationView> ApplicationViews { get; set; }

    public virtual DbSet<ApplicationWorkflowRestartFailureLog> ApplicationWorkflowRestartFailureLogs { get; set; }

    public virtual DbSet<AssessmentPackage> AssessmentPackages { get; set; }

    public virtual DbSet<AssessmentVendorOrder> AssessmentVendorOrders { get; set; }

    public virtual DbSet<AssessmentVendorOrderDetail> AssessmentVendorOrderDetails { get; set; }

    public virtual DbSet<AssessmentView> AssessmentViews { get; set; }

    public virtual DbSet<AttributeType> AttributeTypes { get; set; }

    public virtual DbSet<AttributeValue> AttributeValues { get; set; }

    public virtual DbSet<Audit> Audits { get; set; }

    public virtual DbSet<BehavioralAssessmentInterimView> BehavioralAssessmentInterimViews { get; set; }

    public virtual DbSet<BehavioralAssessmentView> BehavioralAssessmentViews { get; set; }

    public virtual DbSet<BulkIndexLog> BulkIndexLogs { get; set; }

    public virtual DbSet<BusinessEntity> BusinessEntities { get; set; }

    public virtual DbSet<BusinessEntityAttributeValue> BusinessEntityAttributeValues { get; set; }

    public virtual DbSet<BusinessEntityType> BusinessEntityTypes { get; set; }

    public virtual DbSet<BusinessEntityTypeAttributeType> BusinessEntityTypeAttributeTypes { get; set; }

    public virtual DbSet<CareerSite> CareerSites { get; set; }

    public virtual DbSet<ClientSetting> ClientSettings { get; set; }

    public virtual DbSet<ClientSettingDefaultListValue> ClientSettingDefaultListValues { get; set; }

    public virtual DbSet<ClientSettingType> ClientSettingTypes { get; set; }

    public virtual DbSet<Communication> Communications { get; set; }

    public virtual DbSet<CommunicationCcBccUserProfile> CommunicationCcBccUserProfiles { get; set; }

    public virtual DbSet<CommunicationDocument> CommunicationDocuments { get; set; }

    public virtual DbSet<ContactInformation> ContactInformations { get; set; }

    public virtual DbSet<ContactInformation1> ContactInformations1 { get; set; }

    public virtual DbSet<ControlType> ControlTypes { get; set; }

    public virtual DbSet<DataSourceFieldType> DataSourceFieldTypes { get; set; }

    public virtual DbSet<DataSourceType> DataSourceTypes { get; set; }

    public virtual DbSet<DatabaseVersionHistory> DatabaseVersionHistories { get; set; }

    public virtual DbSet<Department> Departments { get; set; }

    public virtual DbSet<DepartmentBusinessEntity> DepartmentBusinessEntities { get; set; }

    public virtual DbSet<DetailSectionType> DetailSectionTypes { get; set; }

    public virtual DbSet<DispositionSettingsType> DispositionSettingsTypes { get; set; }

    public virtual DbSet<Document> Documents { get; set; }

    public virtual DbSet<DocumentGroup> DocumentGroups { get; set; }

    public virtual DbSet<DocumentGroupBusinessEntity> DocumentGroupBusinessEntities { get; set; }

    public virtual DbSet<DocumentGroupJobTemplate> DocumentGroupJobTemplates { get; set; }

    public virtual DbSet<DocumentGroupOnBoardingDocument> DocumentGroupOnBoardingDocuments { get; set; }

    public virtual DbSet<DocumentMediaType> DocumentMediaTypes { get; set; }

    public virtual DbSet<DocumentType> DocumentTypes { get; set; }

    public virtual DbSet<DraftObjectStore> DraftObjectStores { get; set; }

    public virtual DbSet<EsignatureDocument> EsignatureDocuments { get; set; }

    public virtual DbSet<EsignatureDocumentCustomEmailAddress> EsignatureDocumentCustomEmailAddresses { get; set; }

    public virtual DbSet<EstablishedHierarchy> EstablishedHierarchies { get; set; }

    public virtual DbSet<EstablishedHierarchyChangeType> EstablishedHierarchyChangeTypes { get; set; }

    public virtual DbSet<EventError> EventErrors { get; set; }

    public virtual DbSet<Facility> Facilities { get; set; }

    public virtual DbSet<FacilityBusinessEntity> FacilityBusinessEntities { get; set; }

    public virtual DbSet<FailedDispositionSyncApplication> FailedDispositionSyncApplications { get; set; }

    public virtual DbSet<FailedProviderNewHireApplication> FailedProviderNewHireApplications { get; set; }

    public virtual DbSet<FieldCategory> FieldCategories { get; set; }

    public virtual DbSet<FieldTag> FieldTags { get; set; }

    public virtual DbSet<Form> Forms { get; set; }

    public virtual DbSet<FormBusinessEntity> FormBusinessEntities { get; set; }

    public virtual DbSet<FormMetaType> FormMetaTypes { get; set; }

    public virtual DbSet<FormMetaTypeAnnotation> FormMetaTypeAnnotations { get; set; }

    public virtual DbSet<FormPublished> FormPublisheds { get; set; }

    public virtual DbSet<FormType> FormTypes { get; set; }

    public virtual DbSet<FormTypeFieldCategory> FormTypeFieldCategories { get; set; }

    public virtual DbSet<FormTypeMetaTypeFieldTag> FormTypeMetaTypeFieldTags { get; set; }

    public virtual DbSet<Format> Formats { get; set; }

    public virtual DbSet<GlobalNoteStaging> GlobalNoteStagings { get; set; }

    public virtual DbSet<GridColumnDefinition> GridColumnDefinitions { get; set; }

    public virtual DbSet<GridType> GridTypes { get; set; }

    public virtual DbSet<HierarchySetting> HierarchySettings { get; set; }

    public virtual DbSet<HrXmlMap> HrXmlMaps { get; set; }

    public virtual DbSet<HrXmlType> HrXmlTypes { get; set; }

    public virtual DbSet<HrarequisitionLock> HrarequisitionLocks { get; set; }

    public virtual DbSet<HrisimportProtectedRecord> HrisimportProtectedRecords { get; set; }

    public virtual DbSet<IdentityBusinessEntityMapping> IdentityBusinessEntityMappings { get; set; }

    public virtual DbSet<ImpersonationAudit> ImpersonationAudits { get; set; }

    public virtual DbSet<IndexLog> IndexLogs { get; set; }

    public virtual DbSet<IndexType> IndexTypes { get; set; }

    public virtual DbSet<Interview> Interviews { get; set; }

    public virtual DbSet<InterviewParticipant> InterviewParticipants { get; set; }

    public virtual DbSet<InterviewUser> InterviewUsers { get; set; }

    public virtual DbSet<JobDistributionJobInfo> JobDistributionJobInfos { get; set; }

    public virtual DbSet<JobDistributionJobSync> JobDistributionJobSyncs { get; set; }

    public virtual DbSet<JobDistributionPostingInfo> JobDistributionPostingInfos { get; set; }

    public virtual DbSet<JobDistributionVendorApplication> JobDistributionVendorApplications { get; set; }

    public virtual DbSet<JobFamily> JobFamilies { get; set; }

    public virtual DbSet<JobPosting> JobPostings { get; set; }

    public virtual DbSet<JobPostingBusinessEntity> JobPostingBusinessEntities { get; set; }

    public virtual DbSet<JobPostingFieldValue> JobPostingFieldValues { get; set; }

    public virtual DbSet<JobPostingLocation> JobPostingLocations { get; set; }

    public virtual DbSet<JobPostingVendor> JobPostingVendors { get; set; }

    public virtual DbSet<JobPostingView> JobPostingViews { get; set; }

    public virtual DbSet<JobTemplate> JobTemplates { get; set; }

    public virtual DbSet<JobTemplateBusinessEntity> JobTemplateBusinessEntities { get; set; }

    public virtual DbSet<JobTemplateFieldValue> JobTemplateFieldValues { get; set; }

    public virtual DbSet<JobTemplateInstance> JobTemplateInstances { get; set; }

    public virtual DbSet<JobTemplateInstanceLeanCapitalJobFamilyType> JobTemplateInstanceLeanCapitalJobFamilyTypes { get; set; }

    public virtual DbSet<JobTemplateInstanceMetaValue> JobTemplateInstanceMetaValues { get; set; }

    public virtual DbSet<JobTemplateLeanCapitalJobFamilyType> JobTemplateLeanCapitalJobFamilyTypes { get; set; }

    public virtual DbSet<JobTemplateMetaValue> JobTemplateMetaValues { get; set; }

    public virtual DbSet<JobTemplatePropagationField> JobTemplatePropagationFields { get; set; }

    public virtual DbSet<JobTemplatePropagationFieldInstance> JobTemplatePropagationFieldInstances { get; set; }

    public virtual DbSet<JobTemplatePropagationHri> JobTemplatePropagationHris { get; set; }

    public virtual DbSet<JobTemplatePropagationHrisjobTemplate> JobTemplatePropagationHrisjobTemplates { get; set; }

    public virtual DbSet<JobTemplatePropagationJob> JobTemplatePropagationJobs { get; set; }

    public virtual DbSet<JobTemplatePropagationJobInstance> JobTemplatePropagationJobInstances { get; set; }

    public virtual DbSet<JobTemplatePropagationJobSummary> JobTemplatePropagationJobSummaries { get; set; }

    public virtual DbSet<JobTemplatePropagationQueue> JobTemplatePropagationQueues { get; set; }

    public virtual DbSet<JobTemplatePropagationRequisition> JobTemplatePropagationRequisitions { get; set; }

    public virtual DbSet<JobTemplatePropagationRequisitionStatusInstance> JobTemplatePropagationRequisitionStatusInstances { get; set; }

    public virtual DbSet<JobTemplatePropagationRequisitionSyncErrorLog> JobTemplatePropagationRequisitionSyncErrorLogs { get; set; }

    public virtual DbSet<JobTemplatePropagationRequisitionSyncStatus> JobTemplatePropagationRequisitionSyncStatuses { get; set; }

    public virtual DbSet<JobTemplatePropagationTarget> JobTemplatePropagationTargets { get; set; }

    public virtual DbSet<LeanCapitalJobFamilyType> LeanCapitalJobFamilyTypes { get; set; }

    public virtual DbSet<LegacyAccount> LegacyAccounts { get; set; }

    public virtual DbSet<LegacyAccountApplicationTracking> LegacyAccountApplicationTrackings { get; set; }

    public virtual DbSet<LocalApplicant> LocalApplicants { get; set; }

    public virtual DbSet<LocalApplicantVendorOrder> LocalApplicantVendorOrders { get; set; }

    public virtual DbSet<MetaType> MetaTypes { get; set; }

    public virtual DbSet<MetaTypeReportingType> MetaTypeReportingTypes { get; set; }

    public virtual DbSet<MetaValue> MetaValues { get; set; }

    public virtual DbSet<MetaValueBusinessEntity> MetaValueBusinessEntities { get; set; }

    public virtual DbSet<MiscellaneousField> MiscellaneousFields { get; set; }

    public virtual DbSet<NewHire> NewHires { get; set; }

    public virtual DbSet<NewHireDocument> NewHireDocuments { get; set; }

    public virtual DbSet<NewHireFieldValue> NewHireFieldValues { get; set; }

    public virtual DbSet<NewHireNoteView> NewHireNoteViews { get; set; }

    public virtual DbSet<NewHireOrientationDateView> NewHireOrientationDateViews { get; set; }

    public virtual DbSet<NewHireStartDateView> NewHireStartDateViews { get; set; }

    public virtual DbSet<NewHireStatusType> NewHireStatusTypes { get; set; }

    public virtual DbSet<NewHireView> NewHireViews { get; set; }

    public virtual DbSet<Note> Notes { get; set; }

    public virtual DbSet<OnBoardingDocument> OnBoardingDocuments { get; set; }

    public virtual DbSet<OnBoardingDocumentBusinessEntity> OnBoardingDocumentBusinessEntities { get; set; }

    public virtual DbSet<OnBoardingDocumentInstance> OnBoardingDocumentInstances { get; set; }

    public virtual DbSet<OnBoardingDocumentStateType> OnBoardingDocumentStateTypes { get; set; }

    public virtual DbSet<OnBoardingDocumentStatusType> OnBoardingDocumentStatusTypes { get; set; }

    public virtual DbSet<OnBoardingWelcomeMessage> OnBoardingWelcomeMessages { get; set; }

    public virtual DbSet<OnboardingDocumentAuditType> OnboardingDocumentAuditTypes { get; set; }

    public virtual DbSet<OnboardingEmailSettingsType> OnboardingEmailSettingsTypes { get; set; }

    public virtual DbSet<OnboardingTokenAudit> OnboardingTokenAudits { get; set; }

    public virtual DbSet<PasswordHistory> PasswordHistories { get; set; }

    public virtual DbSet<Permission> Permissions { get; set; }

    public virtual DbSet<PermissionType> PermissionTypes { get; set; }

    public virtual DbSet<Question> Questions { get; set; }

    public virtual DbSet<QuestionDisplayType> QuestionDisplayTypes { get; set; }

    public virtual DbSet<Questionnaire> Questionnaires { get; set; }

    public virtual DbSet<QuestionnaireResponse> QuestionnaireResponses { get; set; }

    public virtual DbSet<QuestionnaireResponseAnswer> QuestionnaireResponseAnswers { get; set; }

    public virtual DbSet<QuestionnaireType> QuestionnaireTypes { get; set; }

    public virtual DbSet<RecentActivity> RecentActivities { get; set; }

    public virtual DbSet<RecentActivity1> RecentActivities1 { get; set; }

    public virtual DbSet<RecruitingAuditLog> RecruitingAuditLogs { get; set; }

    public virtual DbSet<RefactorAssessmentsVendorOrderTableMigration> RefactorAssessmentsVendorOrderTableMigrations { get; set; }

    public virtual DbSet<RefactorVendorOrderVendorOrderDetailMapping> RefactorVendorOrderVendorOrderDetailMappings { get; set; }

    public virtual DbSet<ReferenceAssessmentReference> ReferenceAssessmentReferences { get; set; }

    public virtual DbSet<ReferenceBenchmarkType> ReferenceBenchmarkTypes { get; set; }

    public virtual DbSet<ReferenceCheckApplicationLock> ReferenceCheckApplicationLocks { get; set; }

    public virtual DbSet<Report> Reports { get; set; }

    public virtual DbSet<ReportCategory> ReportCategories { get; set; }

    public virtual DbSet<Requisition> Requisitions { get; set; }

    public virtual DbSet<RequisitionAcl> RequisitionAcls { get; set; }

    public virtual DbSet<RequisitionAdditionalUser> RequisitionAdditionalUsers { get; set; }

    public virtual DbSet<RequisitionApprover> RequisitionApprovers { get; set; }

    public virtual DbSet<RequisitionAuditType> RequisitionAuditTypes { get; set; }

    public virtual DbSet<RequisitionDocument> RequisitionDocuments { get; set; }

    public virtual DbSet<RequisitionFieldValue> RequisitionFieldValues { get; set; }

    public virtual DbSet<RequisitionSequence> RequisitionSequences { get; set; }

    public virtual DbSet<RequisitionStatusType> RequisitionStatusTypes { get; set; }

    public virtual DbSet<RequisitionVendorOrder> RequisitionVendorOrders { get; set; }

    public virtual DbSet<RequisitionView> RequisitionViews { get; set; }

    public virtual DbSet<RequisitionWorkflowAudit> RequisitionWorkflowAudits { get; set; }

    public virtual DbSet<RequisitionWorkflowRestartFailureLog> RequisitionWorkflowRestartFailureLogs { get; set; }

    public virtual DbSet<Role> Roles { get; set; }

    public virtual DbSet<RolePermission> RolePermissions { get; set; }

    public virtual DbSet<RoleType> RoleTypes { get; set; }

    public virtual DbSet<RoleType1> RoleTypes1 { get; set; }

    public virtual DbSet<Search> Searches { get; set; }

    public virtual DbSet<SettingsApplyLimit> SettingsApplyLimits { get; set; }

    public virtual DbSet<SettingsApplyLimitApplicationStatusType> SettingsApplyLimitApplicationStatusTypes { get; set; }

    public virtual DbSet<SettingsClient> SettingsClients { get; set; }

    public virtual DbSet<SettingsClientDocumentType> SettingsClientDocumentTypes { get; set; }

    public virtual DbSet<SettingsClientJobTemplatePropagationField> SettingsClientJobTemplatePropagationFields { get; set; }

    public virtual DbSet<SettingsClientJobTemplatePropagationRequisitionStatusType> SettingsClientJobTemplatePropagationRequisitionStatusTypes { get; set; }

    public virtual DbSet<SettingsInternal> SettingsInternals { get; set; }

    public virtual DbSet<SettingsOnboarding> SettingsOnboardings { get; set; }

    public virtual DbSet<SettingsPasswordSecurity> SettingsPasswordSecurities { get; set; }

    public virtual DbSet<SettingsReport> SettingsReports { get; set; }

    public virtual DbSet<SettingsTimeZone> SettingsTimeZones { get; set; }

    public virtual DbSet<SettingsWorkflow> SettingsWorkflows { get; set; }

    public virtual DbSet<SettingsWorkflowDefaultSequentialStep> SettingsWorkflowDefaultSequentialSteps { get; set; }

    public virtual DbSet<SettingsWorkflowDefinition> SettingsWorkflowDefinitions { get; set; }

    public virtual DbSet<SettingsWorkflowSequentialStep> SettingsWorkflowSequentialSteps { get; set; }

    public virtual DbSet<SettingsWorkflowStep> SettingsWorkflowSteps { get; set; }

    public virtual DbSet<SettingsWorkflowStepAction> SettingsWorkflowStepActions { get; set; }

    public virtual DbSet<SortOrderType> SortOrderTypes { get; set; }

    public virtual DbSet<SystemSearch> SystemSearches { get; set; }

    public virtual DbSet<SystemSearchOnboardingStatusType> SystemSearchOnboardingStatusTypes { get; set; }

    public virtual DbSet<SystemSearchStatusType> SystemSearchStatusTypes { get; set; }

    public virtual DbSet<SystemSearchVendorOrderType> SystemSearchVendorOrderTypes { get; set; }

    public virtual DbSet<TalentAnalyticsConsent> TalentAnalyticsConsents { get; set; }

    public virtual DbSet<TalentAnalyticsConsentTermsCondition> TalentAnalyticsConsentTermsConditions { get; set; }

    public virtual DbSet<TalentPoolContact> TalentPoolContacts { get; set; }

    public virtual DbSet<TalentPoolContactCommunication> TalentPoolContactCommunications { get; set; }

    public virtual DbSet<TalentPoolContactDocument> TalentPoolContactDocuments { get; set; }

    public virtual DbSet<TalentPoolContactStatusType> TalentPoolContactStatusTypes { get; set; }

    public virtual DbSet<TalentPoolContactView> TalentPoolContactViews { get; set; }

    public virtual DbSet<Task> Tasks { get; set; }

    public virtual DbSet<TaskStatusType> TaskStatusTypes { get; set; }

    public virtual DbSet<TaskType> TaskTypes { get; set; }

    public virtual DbSet<Template> Templates { get; set; }

    public virtual DbSet<TemplateAttributeValue> TemplateAttributeValues { get; set; }

    public virtual DbSet<TemplateBusinessEntity> TemplateBusinessEntities { get; set; }

    public virtual DbSet<TemplateDocument> TemplateDocuments { get; set; }

    public virtual DbSet<TemplateRoleType> TemplateRoleTypes { get; set; }

    public virtual DbSet<TemplateType> TemplateTypes { get; set; }

    public virtual DbSet<TemplateTypeAttributeType> TemplateTypeAttributeTypes { get; set; }

    public virtual DbSet<TemplateTypeFieldCategory> TemplateTypeFieldCategories { get; set; }

    public virtual DbSet<TemplateTypeMiscellaneousField> TemplateTypeMiscellaneousFields { get; set; }

    public virtual DbSet<TemplateTypeRoleType> TemplateTypeRoleTypes { get; set; }

    public virtual DbSet<TemplateUser> TemplateUsers { get; set; }

    public virtual DbSet<TextMessage> TextMessages { get; set; }

    public virtual DbSet<TextMessageEventType> TextMessageEventTypes { get; set; }

    public virtual DbSet<TextMessageSnippet> TextMessageSnippets { get; set; }

    public virtual DbSet<TmsdataType> TmsdataTypes { get; set; }

    public virtual DbSet<Tmsuser> Tmsusers { get; set; }

    public virtual DbSet<TmsuserAreaOfResponsibility> TmsuserAreaOfResponsibilities { get; set; }

    public virtual DbSet<TmsuserRole> TmsuserRoles { get; set; }

    public virtual DbSet<UserAccountStateTypeHistory> UserAccountStateTypeHistories { get; set; }

    public virtual DbSet<UserDetailSectionPreference> UserDetailSectionPreferences { get; set; }

    public virtual DbSet<UserGridColumnPreference> UserGridColumnPreferences { get; set; }

    public virtual DbSet<UserHistory> UserHistories { get; set; }

    public virtual DbSet<UserPreference> UserPreferences { get; set; }

    public virtual DbSet<UserProfile> UserProfiles { get; set; }

    public virtual DbSet<UserProfileRoleType> UserProfileRoleTypes { get; set; }

    public virtual DbSet<UserProfileVendorUserAccount> UserProfileVendorUserAccounts { get; set; }

    public virtual DbSet<UserWizardDatum> UserWizardData { get; set; }

    public virtual DbSet<Vendor> Vendors { get; set; }

    public virtual DbSet<VendorAttribute> VendorAttributes { get; set; }

    public virtual DbSet<VendorAttributeType> VendorAttributeTypes { get; set; }

    public virtual DbSet<VendorAuditLog> VendorAuditLogs { get; set; }

    public virtual DbSet<VendorCorporateAccount> VendorCorporateAccounts { get; set; }

    public virtual DbSet<VendorCorporateAccountVendorUserAccount> VendorCorporateAccountVendorUserAccounts { get; set; }

    public virtual DbSet<VendorOrder> VendorOrders { get; set; }

    public virtual DbSet<VendorOrderDetail> VendorOrderDetails { get; set; }

    public virtual DbSet<VendorOrderResult> VendorOrderResults { get; set; }

    public virtual DbSet<VendorOrderStatusType> VendorOrderStatusTypes { get; set; }

    public virtual DbSet<VendorOrderStatusTypeHistory> VendorOrderStatusTypeHistories { get; set; }

    public virtual DbSet<VendorOrderType> VendorOrderTypes { get; set; }

    public virtual DbSet<VendorSsoAccessAudit> VendorSsoAccessAudits { get; set; }

    public virtual DbSet<VendorUserAccount> VendorUserAccounts { get; set; }

    public virtual DbSet<WebMessage> WebMessages { get; set; }

    public virtual DbSet<WorkflowAssociation> WorkflowAssociations { get; set; }

    public virtual DbSet<WorkflowAuditHistory> WorkflowAuditHistories { get; set; }

    public virtual DbSet<WorkflowStepUser> WorkflowStepUsers { get; set; }

    public virtual DbSet<WorkflowSubType> WorkflowSubTypes { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<AccountStateType>(entity =>
        {
            entity.HasKey(e => e.AccountStateTypeId).HasName("PK_AccountStateTypeID");

            entity.ToTable("AccountStateType", "Auth");

            entity.HasIndex(e => e.Name, "UC_AccountStateType_2").IsUnique();

            entity.Property(e => e.AccountStateTypeId).HasColumnName("AccountStateTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<Acknowledgement>(entity =>
        {
            entity.HasKey(e => e.AcknowledgementId).HasName("PK__Acknowle__46F3973802417611");

            entity.ToTable("Acknowledgement", "Admin");

            entity.HasIndex(e => new { e.Name, e.Deleted }, "IDX_Acknowledgement_2").IsUnique();

            entity.Property(e => e.AcknowledgementId).HasColumnName("AcknowledgementID");
            entity.Property(e => e.AcknowledgementTypeId)
                .HasDefaultValue(1)
                .HasColumnName("AcknowledgementTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.AcknowledgementType).WithMany(p => p.Acknowledgements)
                .HasForeignKey(d => d.AcknowledgementTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_AcknowledgementType_Acknowledgement_1");
        });

        modelBuilder.Entity<AcknowledgementCareerSite>(entity =>
        {
            entity.HasKey(e => e.AcknowledgementCareerSiteId).HasName("PK__Acknowle__163F791EB32987D6");

            entity.ToTable("AcknowledgementCareerSite", "Admin");

            entity.HasIndex(e => new { e.CareerSiteId, e.AcknowledgementId, e.Deleted }, "IDX_AcknowledgementCareerSite_2").IsUnique();

            entity.Property(e => e.AcknowledgementCareerSiteId).HasColumnName("AcknowledgementCareerSiteID");
            entity.Property(e => e.AcknowledgementId).HasColumnName("AcknowledgementID");
            entity.Property(e => e.CareerSiteId).HasColumnName("CareerSiteID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ExpirationDate).HasColumnType("datetime");
            entity.Property(e => e.LiveDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.Acknowledgement).WithMany(p => p.AcknowledgementCareerSites)
                .HasForeignKey(d => d.AcknowledgementId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Acknowledgement_AcknowledgementCareerSite_2");

            entity.HasOne(d => d.CareerSite).WithMany(p => p.AcknowledgementCareerSites)
                .HasForeignKey(d => d.CareerSiteId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_CareerSite_AcknowledgementCareerSite_1");
        });

        modelBuilder.Entity<AcknowledgementPublished>(entity =>
        {
            entity.HasKey(e => e.AcknowledgementPublishedId).HasName("PK__Acknowle__3F146C9BB07694D2");

            entity.ToTable("AcknowledgementPublished", "Admin");

            entity.HasIndex(e => new { e.CareerSiteId, e.AcknowledgementTypeId, e.Deleted }, "IDX_AcknowledgementPublished_2").IsUnique();

            entity.Property(e => e.AcknowledgementPublishedId).HasColumnName("AcknowledgementPublishedID");
            entity.Property(e => e.AcknowledgementId).HasColumnName("AcknowledgementID");
            entity.Property(e => e.AcknowledgementTypeId)
                .HasDefaultValue(1)
                .HasColumnName("AcknowledgementTypeID");
            entity.Property(e => e.CareerSiteId).HasColumnName("CareerSiteID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.Acknowledgement).WithMany(p => p.AcknowledgementPublisheds)
                .HasForeignKey(d => d.AcknowledgementId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Acknowledgement_AcknowledgementPublished_1");

            entity.HasOne(d => d.AcknowledgementType).WithMany(p => p.AcknowledgementPublisheds)
                .HasForeignKey(d => d.AcknowledgementTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_AcknowledgementType_AcknowledgementPublished_3");

            entity.HasOne(d => d.CareerSite).WithMany(p => p.AcknowledgementPublisheds)
                .HasForeignKey(d => d.CareerSiteId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_CareerSite_AcknowledgementPublished_2");
        });

        modelBuilder.Entity<AcknowledgementType>(entity =>
        {
            entity.HasKey(e => e.AcknowledgementTypeId).HasName("PK__Acknowle__9D24229C3A73E983");

            entity.ToTable("AcknowledgementType", "Admin");

            entity.HasIndex(e => new { e.Name, e.Deleted }, "IDX_AcknowledgementType_2").IsUnique();

            entity.Property(e => e.AcknowledgementTypeId).HasColumnName("AcknowledgementTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<AnnotationType>(entity =>
        {
            entity.HasKey(e => e.AnnotationTypeId).HasName("PK__Annotati__E933B6D18011F5DF");

            entity.ToTable("AnnotationType", "Admin");

            entity.Property(e => e.AnnotationTypeId).HasColumnName("AnnotationTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(50);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<Announcement>(entity =>
        {
            entity.HasKey(e => e.AnnouncementId).HasName("PK__Announce__9DE44554C14613CA");

            entity.ToTable("Announcement", "Admin");

            entity.HasIndex(e => new { e.Name, e.Deleted }, "IDX_Announcement_Name_Deleted").IsUnique();

            entity.Property(e => e.AnnouncementId).HasColumnName("AnnouncementID");
            entity.Property(e => e.AnnouncementText).HasComment("The html text that is displayed when a PostitionManager user views an Announcement.");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.EndDate)
                .HasComment("Determines the last date at which an Announcement is visible to a PostitionManager user.")
                .HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.StartDate)
                .HasComment("The date when an Announcement becomes visible to a PositionManager user.")
                .HasColumnType("datetime");
            entity.Property(e => e.Subject)
                .HasMaxLength(200)
                .HasComment("The subject text that is displayed when a PostionManager user is presented with a list of Announcements.");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<AnnouncementRoleType>(entity =>
        {
            entity.HasKey(e => e.AnnouncementRoleTypeId).HasName("PK__Announce__E1EAF1970C373D12");

            entity.ToTable("AnnouncementRoleType", "Admin");

            entity.HasIndex(e => new { e.AnnouncementId, e.RoleTypeId, e.Deleted }, "IDX_AnnouncementRoleType_AnnouncementID_RoleTypeID").IsUnique();

            entity.Property(e => e.AnnouncementRoleTypeId).HasColumnName("AnnouncementRoleTypeID");
            entity.Property(e => e.AnnouncementId).HasColumnName("AnnouncementID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.RoleTypeId).HasColumnName("RoleTypeID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.Announcement).WithMany(p => p.AnnouncementRoleTypes)
                .HasForeignKey(d => d.AnnouncementId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Announcement_AnnouncementRoleType_1");

            entity.HasOne(d => d.RoleType).WithMany(p => p.AnnouncementRoleTypes)
                .HasForeignKey(d => d.RoleTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_RoleType_AnnouncementRoleType_2");
        });

        modelBuilder.Entity<Answer>(entity =>
        {
            entity.HasKey(e => e.AnswerId).HasName("PK_AnswerID");

            entity.ToTable("Answer", "Admin");

            entity.Property(e => e.AnswerId).HasColumnName("AnswerID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DisplayText).HasMaxLength(100);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.QuestionId).HasColumnName("QuestionID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.Question).WithMany(p => p.Answers)
                .HasForeignKey(d => d.QuestionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Question_Answer_1");
        });

        modelBuilder.Entity<ApplicantGlobalNoteStaging>(entity =>
        {
            entity.HasKey(e => e.ApplicantGlobalNoteStagingId).HasName("PK_ApplicantGlobalNoteStagingID");

            entity.ToTable("ApplicantGlobalNoteStaging");

            entity.HasIndex(e => new { e.ApplicantId, e.GlobalNoteId, e.GlobalNoteStagingId, e.Deleted }, "IDX_ApplicantGlobalNoteStaging_NaturalKey").IsUnique();

            entity.HasIndex(e => new { e.ApplicantGlobalNoteStagingId, e.Deleted }, "UX_ApplicantGlobalNoteStaging_ApplicantGlobalNoteStaging").IsUnique();

            entity.Property(e => e.ApplicantGlobalNoteStagingId).HasColumnName("ApplicantGlobalNoteStagingID");
            entity.Property(e => e.ApplicantId).HasColumnName("ApplicantID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.GlobalNoteId).HasColumnName("GlobalNoteID");
            entity.Property(e => e.GlobalNoteStagingId).HasColumnName("GlobalNoteStagingID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.GlobalNote).WithMany(p => p.ApplicantGlobalNoteStagings)
                .HasForeignKey(d => d.GlobalNoteId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__ApplicantGlobalNoteStaging_Note");

            entity.HasOne(d => d.GlobalNoteStaging).WithMany(p => p.ApplicantGlobalNoteStagings)
                .HasForeignKey(d => d.GlobalNoteStagingId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__ApplicantGlobalNoteStaging_GlobalNoteStaging");
        });

        modelBuilder.Entity<ApplicantLocalApplicant>(entity =>
        {
            entity.HasKey(e => e.ApplicantLocalApplicantId)
                .HasName("PK__Applican__B094CC05E1FF5F6A")
                .IsClustered(false);

            entity.ToTable("ApplicantLocalApplicant");

            entity.HasIndex(e => new { e.ApplicantId, e.Deleted }, "IDX_ApplicantLocalApplicant_2")
                .IsUnique()
                .IsClustered();

            entity.Property(e => e.ApplicantLocalApplicantId).HasColumnName("ApplicantLocalApplicantID");
            entity.Property(e => e.ApplicantId).HasColumnName("ApplicantID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.LocalApplicantId).HasColumnName("LocalApplicantID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.LocalApplicant).WithMany(p => p.ApplicantLocalApplicants)
                .HasForeignKey(d => d.LocalApplicantId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_LocalApplicant_ApplicantLocalApplicant_1");
        });

        modelBuilder.Entity<Application>(entity =>
        {
            entity.HasKey(e => e.ApplicationId).HasName("PK__Applicat__C93A4F790FFA1F66");

            entity.ToTable("Application", tb =>
                {
                    tb.HasTrigger("ApplicationDeleteTrigger");
                    tb.HasTrigger("ApplicationInsertUpdateTrigger");
                });

            entity.HasIndex(e => e.ApplicantId, "IDX_ApplicantID").HasFillFactor(80);

            entity.HasIndex(e => new { e.IsDraft, e.Deleted, e.ApplicationDate, e.ApplicationStatusTypeId, e.RequisitionId, e.ApplicationId }, "IDX_Application_10");

            entity.HasIndex(e => e.ModifiedDate, "IDX_Application_Dates");

            entity.HasIndex(e => e.ModifiedDate, "IDX_Application_ModifiedDate");

            entity.HasIndex(e => new { e.ApplicationId, e.Deleted }, "IDX_Application_PK_and_Deleted").IsUnique();

            entity.HasIndex(e => new { e.IsDraft, e.Deleted }, "IDX_IsDraft").HasFillFactor(80);

            entity.HasIndex(e => new { e.Deleted, e.IsDraft, e.LocalApplicantId }, "IDX_IsDraft_Deleted_LocalApplicantId").HasFillFactor(80);

            entity.HasIndex(e => new { e.RequisitionId, e.Deleted, e.ApplicationId }, "IDX_RequisitionID").HasFillFactor(80);

            entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");
            entity.Property(e => e.ApplicantFirstName).HasMaxLength(100);
            entity.Property(e => e.ApplicantId).HasColumnName("ApplicantID");
            entity.Property(e => e.ApplicantLastName).HasMaxLength(100);
            entity.Property(e => e.ApplicantMiddleName).HasMaxLength(100);
            entity.Property(e => e.ApplicationDate).HasColumnType("datetime");
            entity.Property(e => e.ApplicationStatusDate).HasColumnType("datetime");
            entity.Property(e => e.ApplicationStatusTypeId).HasColumnName("ApplicationStatusTypeID");
            entity.Property(e => e.ApplicationTypeId).HasColumnName("ApplicationTypeID");
            entity.Property(e => e.City).HasMaxLength(50);
            entity.Property(e => e.ContactMethodMetaValueId).HasColumnName("ContactMethodMetaValueID");
            entity.Property(e => e.CopiedFromApplicationId).HasColumnName("CopiedFromApplicationID");
            entity.Property(e => e.CountryMetaValueId).HasColumnName("CountryMetaValueID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DispositionMetaValueId).HasColumnName("DispositionMetaValueID");
            entity.Property(e => e.Email).HasMaxLength(256);
            entity.Property(e => e.EncryptedSsn)
                .HasMaxLength(256)
                .HasComment("Added for PBI 28987,  Stores the Encrypted value for Social Security Number of Applicant.")
                .HasColumnName("EncryptedSSN");
            entity.Property(e => e.HasApplicationDocument)
                .HasDefaultValue(true)
                .HasComment("Denormalized column to determine if the Application has an associated application document.");
            entity.Property(e => e.HasResumeDocument).HasComment("Denormalized column to determine if the Application has an associated resume document.");
            entity.Property(e => e.InviteBackApplicationDate).HasColumnType("datetime");
            entity.Property(e => e.IsDraft).HasDefaultValue(true);
            entity.Property(e => e.JobApplyWorkflowProcessId)
                .HasComment("(Deprecated)This filed stores the id of the workflow process instance. This value should be replaced by the corresponding workflow serial number that allows faster access to the workflow list items.")
                .HasColumnName("JobApplyWorkflowProcessID");
            entity.Property(e => e.JobCategoryMetaValueId).HasColumnName("JobCategoryMetaValueID");
            entity.Property(e => e.JobPostingId).HasColumnName("JobPostingID");
            entity.Property(e => e.JobseekerApplicationId)
                .HasMaxLength(100)
                .HasColumnName("JobseekerApplicationID");
            entity.Property(e => e.LastFourSsn)
                .HasMaxLength(4)
                .HasComment("Added for PBI 28987,  Stores the Unencrypted value for the last four digits of the Applicant''s Social Security Number.")
                .HasColumnName("LastFourSSN");
            entity.Property(e => e.LegacyAccountId)
                .HasComment("Will hold the ID of the Legacy Account (PM10 Site Manager Account) the application is tied to.  Migration will be the only process that will populate this column.")
                .HasColumnName("LegacyAccountID");
            entity.Property(e => e.LocalApplicantId).HasColumnName("LocalApplicantID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.NewHireFormId).HasColumnName("NewHireFormID");
            entity.Property(e => e.PhoneNumber).HasMaxLength(20);
            entity.Property(e => e.PhoneTypeMetaValueId).HasColumnName("PhoneTypeMetaValueID");
            entity.Property(e => e.ReceivedViaMetaValueId)
                .HasDefaultValue(34)
                .HasComment("Represents the communication channel through which the associated applicant found there way into the system.")
                .HasColumnName("ReceivedViaMetaValueID");
            entity.Property(e => e.RequisitionId).HasColumnName("RequisitionID");
            entity.Property(e => e.SettingsWorkflowId).HasColumnName("SettingsWorkflowID");
            entity.Property(e => e.SourceCategoryMetaValueId).HasColumnName("SourceCategoryMetaValueID");
            entity.Property(e => e.SourceNameMetaValueId).HasColumnName("SourceNameMetaValueID");
            entity.Property(e => e.StartDate).HasColumnType("datetime");
            entity.Property(e => e.StateMetaValueId).HasColumnName("StateMetaValueID");
            entity.Property(e => e.Street1).HasMaxLength(50);
            entity.Property(e => e.Street2).HasMaxLength(50);
            entity.Property(e => e.Suid).HasColumnName("SUID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.ViewedByHiringManager).HasComment("If the application was sent by recruiters to multiple hiring managers for their review, this bit indicates if any of the hiring managers views the application.\r\n\r\nDefinition of viewed:\r\n1. Hiring manager expands the master detail on the Manage applications page.\r\n2. Hiring manager opens up the detail page.");
            entity.Property(e => e.Zipcode).HasMaxLength(12);

            entity.HasOne(d => d.ApplicationStatusType).WithMany(p => p.Applications)
                .HasForeignKey(d => d.ApplicationStatusTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ApplicationStatusType_Application");

            entity.HasOne(d => d.ApplicationType).WithMany(p => p.Applications)
                .HasForeignKey(d => d.ApplicationTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ApplicationType_Application");

            entity.HasOne(d => d.ContactMethodMetaValue).WithMany(p => p.ApplicationContactMethodMetaValues)
                .HasForeignKey(d => d.ContactMethodMetaValueId)
                .HasConstraintName("FK_MetaValue_Application_ContactMethod");

            entity.HasOne(d => d.CountryMetaValue).WithMany(p => p.ApplicationCountryMetaValues)
                .HasForeignKey(d => d.CountryMetaValueId)
                .HasConstraintName("FK_MetaValue_Application_Country");

            entity.HasOne(d => d.DispositionMetaValue).WithMany(p => p.ApplicationDispositionMetaValues)
                .HasForeignKey(d => d.DispositionMetaValueId)
                .HasConstraintName("FK_MetaValue_Application_Disposition");

            entity.HasOne(d => d.JobCategoryMetaValue).WithMany(p => p.ApplicationJobCategoryMetaValues)
                .HasForeignKey(d => d.JobCategoryMetaValueId)
                .HasConstraintName("FK_MetaValue_Application_JobCategory");

            entity.HasOne(d => d.JobPosting).WithMany(p => p.Applications)
                .HasForeignKey(d => d.JobPostingId)
                .HasConstraintName("FK_JobPosting_Application_27");

            entity.HasOne(d => d.LocalApplicant).WithMany(p => p.Applications)
                .HasForeignKey(d => d.LocalApplicantId)
                .HasConstraintName("FK_LocalApplicant_Application_28");

            entity.HasOne(d => d.PhoneTypeMetaValue).WithMany(p => p.ApplicationPhoneTypeMetaValues)
                .HasForeignKey(d => d.PhoneTypeMetaValueId)
                .HasConstraintName("FK_MetaValue_Application_PhoneType");

            entity.HasOne(d => d.ReceivedViaMetaValue).WithMany(p => p.ApplicationReceivedViaMetaValues)
                .HasForeignKey(d => d.ReceivedViaMetaValueId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MetaValue_Application_ReceivedVia");

            entity.HasOne(d => d.Requisition).WithMany(p => p.Applications)
                .HasForeignKey(d => d.RequisitionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Requisition_Application");

            entity.HasOne(d => d.SourceCategoryMetaValue).WithMany(p => p.ApplicationSourceCategoryMetaValues)
                .HasForeignKey(d => d.SourceCategoryMetaValueId)
                .HasConstraintName("FK_MetaValue_Application_SourceCategory");

            entity.HasOne(d => d.SourceNameMetaValue).WithMany(p => p.ApplicationSourceNameMetaValues)
                .HasForeignKey(d => d.SourceNameMetaValueId)
                .HasConstraintName("FK_MetaValue_Application_SourceName");

            entity.HasOne(d => d.StateMetaValue).WithMany(p => p.ApplicationStateMetaValues)
                .HasForeignKey(d => d.StateMetaValueId)
                .HasConstraintName("FK_MetaValue_Application_State");
        });

        modelBuilder.Entity<ApplicationAcknowledgement>(entity =>
        {
            entity.HasKey(e => e.ApplicationAcknowledgementId).HasName("PK__Applicat__CE5DA4EE68C8FC50");

            entity.ToTable("ApplicationAcknowledgement");

            entity.HasIndex(e => new { e.ApplicationId, e.AcknowledgementTypeId, e.Deleted }, "IDX_ApplicationAcknowledgement_2").IsUnique();

            entity.Property(e => e.ApplicationAcknowledgementId).HasColumnName("ApplicationAcknowledgementID");
            entity.Property(e => e.AcceptanceDate).HasColumnType("datetime");
            entity.Property(e => e.AcknowledgementId).HasColumnName("AcknowledgementID");
            entity.Property(e => e.AcknowledgementTypeId)
                .HasDefaultValue(1)
                .HasColumnName("AcknowledgementTypeID");
            entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.IpAddress).HasMaxLength(100);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Signature).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.Acknowledgement).WithMany(p => p.ApplicationAcknowledgements)
                .HasForeignKey(d => d.AcknowledgementId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Acknowledgement_ApplicationAcknowledgement_1");

            entity.HasOne(d => d.AcknowledgementType).WithMany(p => p.ApplicationAcknowledgements)
                .HasForeignKey(d => d.AcknowledgementTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_AcknowledgementType_ApplicationAcknowledgement_3");

            entity.HasOne(d => d.Application).WithMany(p => p.ApplicationAcknowledgements)
                .HasForeignKey(d => d.ApplicationId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Acknowledgement_Application");
        });

        modelBuilder.Entity<ApplicationAcl>(entity =>
        {
            entity.HasKey(e => e.ApplicationAclid).HasName("PK__Applicat__99F20B547C8BF31B");

            entity.ToTable("ApplicationACL");

            entity.HasIndex(e => new { e.RoleTypeId, e.TmsuserId, e.ApplicationId, e.Deleted }, "IDX_ApplicationACL_2").IsUnique();

            entity.HasIndex(e => new { e.ApplicationId, e.TmsuserId, e.Deleted }, "IDX_ApplicationID").HasFillFactor(80);

            entity.Property(e => e.ApplicationAclid).HasColumnName("ApplicationACLID");
            entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.RoleTypeId).HasColumnName("RoleTypeID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");

            entity.HasOne(d => d.Application).WithMany(p => p.ApplicationAcls)
                .HasForeignKey(d => d.ApplicationId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Application_ApplicationACL_3");

            entity.HasOne(d => d.RoleType).WithMany(p => p.ApplicationAcls)
                .HasForeignKey(d => d.RoleTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_RoleType_ApplicationACL_1");

            entity.HasOne(d => d.Tmsuser).WithMany(p => p.ApplicationAcls)
                .HasForeignKey(d => d.TmsuserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_UserProfile_ApplicationACL_2");
        });

        modelBuilder.Entity<ApplicationApplicationForm>(entity =>
        {
            entity.HasKey(e => e.ApplicationApplicationFormId).HasName("PK__Applicat__2B642DDF700C3C41");

            entity.ToTable("ApplicationApplicationForm");

            entity.HasIndex(e => new { e.ApplicationId, e.ApplicationFormId, e.Deleted }, "IDX_ApplicationApplicationForm_2").IsUnique();

            entity.Property(e => e.ApplicationApplicationFormId).HasColumnName("ApplicationApplicationFormID");
            entity.Property(e => e.ApplicationFormId)
                .HasDefaultValue(1)
                .HasColumnName("ApplicationFormID");
            entity.Property(e => e.ApplicationId)
                .HasDefaultValue(1)
                .HasColumnName("ApplicationID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.ApplicationForm).WithMany(p => p.ApplicationApplicationForms)
                .HasForeignKey(d => d.ApplicationFormId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ApplicationForm_ApplicationApplicationForm_1");

            entity.HasOne(d => d.Application).WithMany(p => p.ApplicationApplicationForms)
                .HasForeignKey(d => d.ApplicationId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Application_ApplicationApplicationForm_2");
        });

        modelBuilder.Entity<ApplicationCommunication>(entity =>
        {
            entity.HasKey(e => e.ApplicationCommunicationId).HasName("PK__Applicat__B1E3C7378621E8A8");

            entity.ToTable("ApplicationCommunication");

            entity.HasIndex(e => new { e.ApplicationId, e.ModifiedDate }, "IDX_ApplicationCommunication_App_ModDate").IsDescending(false, true);

            entity.HasIndex(e => new { e.ApplicationId, e.Deleted }, "IDX_ApplicationID").HasFillFactor(80);

            entity.HasIndex(e => e.CommunicationId, "IDX_CommunicationID").HasFillFactor(80);

            entity.HasIndex(e => e.VendorOrderId, "IDX_VendorOrderID").HasFillFactor(80);

            entity.Property(e => e.ApplicationCommunicationId).HasColumnName("ApplicationCommunicationID");
            entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");
            entity.Property(e => e.CommunicationId).HasColumnName("CommunicationID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.VendorOrderId).HasColumnName("VendorOrderID");

            entity.HasOne(d => d.Application).WithMany(p => p.ApplicationCommunications)
                .HasForeignKey(d => d.ApplicationId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Application_ApplicationCommunication_2");

            entity.HasOne(d => d.Communication).WithMany(p => p.ApplicationCommunications)
                .HasForeignKey(d => d.CommunicationId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Communication_ApplicationCommunication_1");

            entity.HasOne(d => d.VendorOrder).WithMany(p => p.ApplicationCommunications)
                .HasForeignKey(d => d.VendorOrderId)
                .HasConstraintName("FK_VendorOrder_ApplicationCommunication_3");
        });

        modelBuilder.Entity<ApplicationDocument>(entity =>
        {
            entity.HasKey(e => e.ApplicationDocumentId).HasName("PK__Applicat__9A4B1C0F9C8B2A56");

            entity.ToTable("ApplicationDocument");

            entity.HasIndex(e => new { e.DocumentId, e.ApplicationId, e.Deleted }, "IDX_ApplicationDocument_DocumentID_ApplicationID_Deleted").IsUnique();

            entity.HasIndex(e => new { e.ApplicationId, e.Deleted }, "IDX_ApplicationID").HasFillFactor(80);

            entity.Property(e => e.ApplicationDocumentId).HasColumnName("ApplicationDocumentID");
            entity.Property(e => e.ApplicationAcknowledgementId).HasColumnName("ApplicationAcknowledgementID");
            entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DocumentId).HasColumnName("DocumentID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.ApplicationAcknowledgement).WithMany(p => p.ApplicationDocuments)
                .HasForeignKey(d => d.ApplicationAcknowledgementId)
                .HasConstraintName("FK_ApplicationAcknowledgement_ApplicationDocument_4");

            entity.HasOne(d => d.Application).WithMany(p => p.ApplicationDocuments)
                .HasForeignKey(d => d.ApplicationId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Application_ApplicationDocument_2");

            entity.HasOne(d => d.Document).WithMany(p => p.ApplicationDocuments)
                .HasForeignKey(d => d.DocumentId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Document_ApplicationDocument_3");
        });

        modelBuilder.Entity<ApplicationDocumentAcl>(entity =>
        {
            entity.HasKey(e => e.ApplicationDocumentAclid).HasName("PK__Applicat__AB77014E25C3B270");

            entity.ToTable("ApplicationDocumentACL");

            entity.HasIndex(e => new { e.ApplicationDocumentId, e.RoleTypeId, e.TmsuserId, e.Deleted }, "IDX_ApplicationDocumentACL_2").IsUnique();

            entity.Property(e => e.ApplicationDocumentAclid).HasColumnName("ApplicationDocumentACLID");
            entity.Property(e => e.ApplicationDocumentId).HasColumnName("ApplicationDocumentID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.RoleTypeId).HasColumnName("RoleTypeID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");

            entity.HasOne(d => d.ApplicationDocument).WithMany(p => p.ApplicationDocumentAcls)
                .HasForeignKey(d => d.ApplicationDocumentId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ApplicationDocument_ApplicationDocumentACL_4");

            entity.HasOne(d => d.RoleType).WithMany(p => p.ApplicationDocumentAcls)
                .HasForeignKey(d => d.RoleTypeId)
                .HasConstraintName("FK_RoleType_ApplicationDocumentACL_5");

            entity.HasOne(d => d.Tmsuser).WithMany(p => p.ApplicationDocumentAcls)
                .HasForeignKey(d => d.TmsuserId)
                .HasConstraintName("FK_UserProfile_ApplicationDocumentACL_3");
        });

        modelBuilder.Entity<ApplicationFieldValue>(entity =>
        {
            entity.HasKey(e => e.ApplicationFieldValueId).HasName("PK__Applicat__448A00FD7AC23767");

            entity.ToTable("ApplicationFieldValue", tb =>
                {
                    tb.HasTrigger("ApplicationFieldValueDeleteTrigger");
                    tb.HasTrigger("ApplicationFieldValueInsertUpdateTrigger");
                });

            entity.HasIndex(e => new { e.ApplicationId, e.SectionId, e.GroupId, e.GroupSequenceId, e.MetaTypeId, e.MetaValueId, e.ValueInstanceId, e.Deleted, e.ApplicationFormTypeId, e.ApplicationFormId }, "IDX_ApplicationFieldValue_2").IsUnique();

            entity.HasIndex(e => new { e.ApplicationId, e.MetaTypeId }, "IDX_ApplicationFieldValue_App_Meta").HasFilter("([MetaTypeID] IN ((80), (82), (83), (24), (225), (39), (298), (299)))");

            entity.HasIndex(e => new { e.Deleted, e.MetaTypeId }, "IDX_ApplicationFieldValue_DW_ETL");

            entity.HasIndex(e => e.ModifiedDate, "IDX_ApplicationFieldValue_ModifiedDate").IsDescending();

            entity.Property(e => e.ApplicationFieldValueId).HasColumnName("ApplicationFieldValueID");
            entity.Property(e => e.ApplicationFormId).HasColumnName("ApplicationFormID");
            entity.Property(e => e.ApplicationFormTypeId)
                .HasDefaultValue(1)
                .HasColumnName("ApplicationFormTypeID");
            entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.GroupId).HasColumnName("GroupID");
            entity.Property(e => e.GroupSequenceId)
                .HasComment("GroupID, GroupSequenceID and ValueInstanceID go hand in hand to define and store Multi Instance Data values with Multiple Values. \r\nGroupID Identifies which group it is.\r\ne.g. 1 is LicenseFields group\r\n2 is EducationGroup\r\n3 is WorkHistory group etc.\r\n\r\nGroupSequenceID identifies the instance of a group.\r\ne.g. if there are 5 licences, first license groupsequenceID is 1, second is 2, third is 3, fourth is 4 and fifth is 5.\r\n\r\nValueInstanceID identifies and stores the multiple values of a metatypeid from the value list. e.g. Skills matrix.. Multiple possible are 1-20, but the selected user values ar 5,11,19 etc.\r\n\r\nThe GroupID and SequenceID are for multiinstance data like the License and its child fields like LicenseState/LicenceName.\r\n\r\nE.g. 3 License details collected will be in GroupIDs 1,2 and 3. Each element values of each Group would have a order collected in Sequence.\r\n\r\n\r\n\r\nMetaTypeID 	GroupId 	SequenceId\r\n1         	                1              	1\r\n1        	                1 		2          \r\n1		1		3\r\n1		2		1\r\n1		2		2\r\n1		2		3\r\n")
                .HasColumnName("GroupSequenceID");
            entity.Property(e => e.MetaTypeId).HasColumnName("MetaTypeID");
            entity.Property(e => e.MetaValueId).HasColumnName("MetaValueID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SectionId).HasColumnName("SectionID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsdataTypeId).HasColumnName("TMSDataTypeID");
            entity.Property(e => e.ValueDate).HasColumnType("datetime");
            entity.Property(e => e.ValueInstanceId)
                .HasComment("GroupID, GroupSequenceID and ValueInstanceID go hand in hand to define and store Multi Instance Data values with Multiple Values. \r\nGroupID Identifies which group it is.\r\ne.g. 1 is LicenseFields group\r\n2 is EducationGroup\r\n3 is WorkHistory group etc.\r\n\r\nGroupSequenceID identifies the instance of a group.\r\ne.g. if there are 5 licences, first license groupsequenceID is 1, second is 2, third is 3, fourth is 4 and fifth is 5.\r\n\r\nValueInstanceID identifies and stores the multiple values of a metatypeid from the value list. e.g. Skills matrix.. Multiple possible are 1-20, but the selected user values ar 5,11,19 etc.\r\n\r\nThe GroupID and SequenceID are for multiinstance data like the License and its child fields like LicenseState/LicenceName.\r\n\r\nE.g. 3 License details collected will be in GroupIDs 1,2 and 3. Each element values of each Group would have a order collected in Sequence.\r\n\r\n\r\n\r\nMetaTypeID 	GroupId 	SequenceId\r\n1         	                1              	1\r\n1        	                1 		2          \r\n1		1		3\r\n1		2		1\r\n1		2		2\r\n1		2		3\r\n")
                .HasColumnName("ValueInstanceID");

            entity.HasOne(d => d.ApplicationForm).WithMany(p => p.ApplicationFieldValues)
                .HasForeignKey(d => d.ApplicationFormId)
                .HasConstraintName("FK_ApplicationForm_ApplicationFieldValue_8");

            entity.HasOne(d => d.ApplicationFormType).WithMany(p => p.ApplicationFieldValues)
                .HasForeignKey(d => d.ApplicationFormTypeId)
                .HasConstraintName("FK_ApplicationFormType_ApplicationFieldValue_7");

            entity.HasOne(d => d.Application).WithMany(p => p.ApplicationFieldValues)
                .HasForeignKey(d => d.ApplicationId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Application_ApplicationFieldValue_1");

            entity.HasOne(d => d.Group).WithMany(p => p.ApplicationFieldValues)
                .HasForeignKey(d => d.GroupId)
                .HasConstraintName("FK_ApplicationGroup_ApplicationFieldValue_6");

            entity.HasOne(d => d.MetaType).WithMany(p => p.ApplicationFieldValues)
                .HasForeignKey(d => d.MetaTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MetaType_ApplicationFieldValue_2");

            entity.HasOne(d => d.MetaValue).WithMany(p => p.ApplicationFieldValues)
                .HasForeignKey(d => d.MetaValueId)
                .HasConstraintName("FK_MetaValue_ApplicationFieldValue_3");

            entity.HasOne(d => d.TmsdataType).WithMany(p => p.ApplicationFieldValues)
                .HasForeignKey(d => d.TmsdataTypeId)
                .HasConstraintName("FK_TMSDataType_ApplicationFieldValue_4");
        });

        modelBuilder.Entity<ApplicationForm>(entity =>
        {
            entity.HasKey(e => e.ApplicationFormId).HasName("PK__Applicat__B229707E8155E090");

            entity.ToTable("ApplicationForm", "Admin");

            entity.Property(e => e.ApplicationFormId).HasColumnName("ApplicationFormID");
            entity.Property(e => e.ApplicationFormTypeId)
                .HasDefaultValue(1)
                .HasColumnName("ApplicationFormTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.ApplicationFormType).WithMany(p => p.ApplicationForms)
                .HasForeignKey(d => d.ApplicationFormTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ApplicationFormType_ApplicationForm_1");
        });

        modelBuilder.Entity<ApplicationFormBinderMetaDatum>(entity =>
        {
            entity.HasKey(e => e.ApplicationFormBinderMetaDataId).HasName("PK__Applicat__6B157F4C0F2A6C72");

            entity.ToTable("ApplicationFormBinderMetaData", "Admin");

            entity.HasIndex(e => new { e.ApplicationFormId, e.SectionId, e.ApplicationGroupId, e.FieldSequence, e.Deleted }, "IDX_ApplicationFormBinderMetaData_2").IsUnique();

            entity.Property(e => e.ApplicationFormBinderMetaDataId).HasColumnName("ApplicationFormBinderMetaDataID");
            entity.Property(e => e.ApplicationFormId).HasColumnName("ApplicationFormID");
            entity.Property(e => e.ApplicationGroupId).HasColumnName("ApplicationGroupID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DataSourceFieldTypeId).HasColumnName("DataSourceFieldTypeID");
            entity.Property(e => e.FieldId).HasColumnName("FieldID");
            entity.Property(e => e.IsUsingStandardDisplayName).HasDefaultValue(true);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SectionId).HasColumnName("SectionID");
            entity.Property(e => e.SectionName).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsdataTypeId).HasColumnName("TMSDataTypeID");

            entity.HasOne(d => d.ApplicationForm).WithMany(p => p.ApplicationFormBinderMetaData)
                .HasForeignKey(d => d.ApplicationFormId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ApplicationForm_ApplicationFormBinderMetaData_5");

            entity.HasOne(d => d.ApplicationGroup).WithMany(p => p.ApplicationFormBinderMetaData)
                .HasForeignKey(d => d.ApplicationGroupId)
                .HasConstraintName("FK_ApplicationGroup_ApplicationFormBinderMetaData_1");

            entity.HasOne(d => d.DataSourceFieldType).WithMany(p => p.ApplicationFormBinderMetaData)
                .HasForeignKey(d => d.DataSourceFieldTypeId)
                .HasConstraintName("FK_DataSourceFieldType_ApplicationFormBinderMetaData_6");

            entity.HasOne(d => d.Field).WithMany(p => p.ApplicationFormBinderMetaData)
                .HasForeignKey(d => d.FieldId)
                .HasConstraintName("FK_MetaType_ApplicationFormBinderMetaData_2");

            entity.HasOne(d => d.TmsdataType).WithMany(p => p.ApplicationFormBinderMetaData)
                .HasForeignKey(d => d.TmsdataTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TMSDataType_ApplicationFormBinderMetaData_3");
        });

        modelBuilder.Entity<ApplicationFormType>(entity =>
        {
            entity.HasKey(e => e.ApplicationFormTypeId).HasName("PK__Applicat__64EE736E26DE2012");

            entity.ToTable("ApplicationFormType", "Admin");

            entity.HasIndex(e => new { e.Deleted, e.Name }, "IDX_ApplicationFormType_2").IsUnique();

            entity.Property(e => e.ApplicationFormTypeId).HasColumnName("ApplicationFormTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<ApplicationGlobalCompare>(entity =>
        {
            entity.HasKey(e => e.ApplicationGlobalCompareId).HasName("PK__Applicat__26FF60DA13406574");

            entity.ToTable("ApplicationGlobalCompare");

            entity.HasIndex(e => new { e.ApplicationId, e.MetaTypeId, e.MetaValueId, e.Deleted }, "IDX_ApplicationGlobalCompare_2").IsUnique();

            entity.Property(e => e.ApplicationGlobalCompareId).HasColumnName("ApplicationGlobalCompareID");
            entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.MetaTypeId).HasColumnName("MetaTypeID");
            entity.Property(e => e.MetaValueId).HasColumnName("MetaValueID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.Application).WithMany(p => p.ApplicationGlobalCompares)
                .HasForeignKey(d => d.ApplicationId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Application_ApplicationGlobalCompare_3");

            entity.HasOne(d => d.MetaType).WithMany(p => p.ApplicationGlobalCompares)
                .HasForeignKey(d => d.MetaTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MetaType_ApplicationGlobalCompare_1");

            entity.HasOne(d => d.MetaValue).WithMany(p => p.ApplicationGlobalCompares)
                .HasForeignKey(d => d.MetaValueId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MetaValue_ApplicationGlobalCompare_2");
        });

        modelBuilder.Entity<ApplicationGlobalNoteView>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("ApplicationGlobalNoteView");

            entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");
        });

        modelBuilder.Entity<ApplicationGroup>(entity =>
        {
            entity.HasKey(e => e.ApplicationGroupId).HasName("PK__Applicat__43AF76104819DE31");

            entity.ToTable("ApplicationGroup", "Admin");

            entity.Property(e => e.ApplicationGroupId).HasColumnName("ApplicationGroupID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<ApplicationInternalNoteView>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("ApplicationInternalNoteView");

            entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");
        });

        modelBuilder.Entity<ApplicationMostRecent>(entity =>
        {
            entity.HasKey(e => e.ApplicationMostRecentId)
                .HasName("PK__Applicat__2736FEE985414C22")
                .IsClustered(false);

            entity.ToTable("ApplicationMostRecent", tb =>
                {
                    tb.HasTrigger("ApplicationMostRecentDeleteTrigger");
                    tb.HasTrigger("ApplicationMostRecentInsertUpdateTrigger");
                });

            entity.HasIndex(e => new { e.ApplicationId, e.Deleted }, "IDX_ApplicationMostRecent_UniqueIndex")
                .IsUnique()
                .IsClustered();

            entity.Property(e => e.ApplicationMostRecentId).HasColumnName("ApplicationMostRecentID");
            entity.Property(e => e.ApplicantAnalyticsStatusTypeId).HasColumnName("ApplicantAnalyticsStatusTypeID");
            entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");
            entity.Property(e => e.BackgroundCheckStatusTypeId)
                .HasComment("Denormalized column to store the latest Background Check Status tied to an application. We need to store the BackgroundCheckStatusTypeID to help reduce the query time and improve performance.")
                .HasColumnName("BackgroundCheckStatusTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.EducationId).HasColumnName("EducationID");
            entity.Property(e => e.ExperienceId).HasColumnName("ExperienceID");
            entity.Property(e => e.HmresponseLatestCommunicationId)
                .HasComment("Denormalized column to store the latest Hiring Manager Response CommunicationID. We need to store the Hiring Manager latest CommunicationID to help reduce the query time and improve performance as getting the latest Hiring Manager Response CommunicationID of the application requires subquery to find the max communicationID of the Hiring Manager.")
                .HasColumnName("HMResponseLatestCommunicationID");
            entity.Property(e => e.Hmscore)
                .HasComment("Denormalized column to store the latest Hiring Manager score")
                .HasColumnType("decimal(18, 0)")
                .HasColumnName("HMScore");
            entity.Property(e => e.Hrscore)
                .HasComment("Denormalized column to store the latest Recruiter score")
                .HasColumnType("decimal(18, 0)")
                .HasColumnName("HRScore");
            entity.Property(e => e.LicensureId).HasColumnName("LicensureID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.RankingQuestionnaireId).HasColumnName("RankingQuestionnaireID");
            entity.Property(e => e.ReferenceCheckStatusTypeId)
                .HasComment("Denormalized column to store the latest Reference Check Status Type  tied to an application. We need to store the ReferenceCheckStatusTypeID to help reduce the query time and improve performance.")
                .HasColumnName("ReferenceCheckStatusTypeID");
            entity.Property(e => e.RespondedToHmlatestCommunication).HasColumnName("RespondedToHMLatestCommunication");
            entity.Property(e => e.ScheduleIds).HasColumnName("ScheduleIDs");
            entity.Property(e => e.Score)
                .HasComment("Denormalized column to store the latest applicant score")
                .HasColumnType("decimal(18, 0)");
            entity.Property(e => e.ShiftIds).HasColumnName("ShiftIDs");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TestAssessmentStatusTypeId)
                .HasComment("Denormalized column to store the latest Test Assessment Status Type  tied to an application. We need to store the TestAssessmentStatusTypeID to help reduce the query time and improve performance.")
                .HasColumnName("TestAssessmentStatusTypeID");

            entity.HasOne(d => d.Application).WithMany(p => p.ApplicationMostRecents)
                .HasForeignKey(d => d.ApplicationId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Application_ApplicationMostRecent");

            entity.HasOne(d => d.BackgroundCheckStatusType).WithMany(p => p.ApplicationMostRecentBackgroundCheckStatusTypes)
                .HasForeignKey(d => d.BackgroundCheckStatusTypeId)
                .HasConstraintName("FK_VendorOrderStatusType_ApplicationMostRecent_4");

            entity.HasOne(d => d.HmresponseLatestCommunication).WithMany(p => p.ApplicationMostRecents)
                .HasForeignKey(d => d.HmresponseLatestCommunicationId)
                .HasConstraintName("FK_Communication_ApplicationMostRecent");

            entity.HasOne(d => d.RankingQuestionnaire).WithMany(p => p.ApplicationMostRecents)
                .HasForeignKey(d => d.RankingQuestionnaireId)
                .HasConstraintName("FK_Questionnaire_ApplicationMostRecent_3");

            entity.HasOne(d => d.ReferenceCheckStatusType).WithMany(p => p.ApplicationMostRecentReferenceCheckStatusTypes)
                .HasForeignKey(d => d.ReferenceCheckStatusTypeId)
                .HasConstraintName("FK_VendorOrderStatusType_ApplicationMostRecent_6");

            entity.HasOne(d => d.TestAssessmentStatusType).WithMany(p => p.ApplicationMostRecentTestAssessmentStatusTypes)
                .HasForeignKey(d => d.TestAssessmentStatusTypeId)
                .HasConstraintName("FK_VendorOrderStatusType_ApplicationMostRecent_5");
        });

        modelBuilder.Entity<ApplicationNoteView>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("ApplicationNoteView");

            entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");
        });

        modelBuilder.Entity<ApplicationRankingQuestionnaireByUserView>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("ApplicationRankingQuestionnaireByUserView");

            entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");
            entity.Property(e => e.Score).HasColumnType("decimal(6, 3)");
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");
        });

        modelBuilder.Entity<ApplicationRequisitionView>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("ApplicationRequisitionView");

            entity.Property(e => e.BusinessEntityId).HasColumnName("BusinessEntityID");
            entity.Property(e => e.Code).HasMaxLength(100);
            entity.Property(e => e.ContactFirst).HasMaxLength(100);
            entity.Property(e => e.ContactLast).HasMaxLength(100);
            entity.Property(e => e.ContactMiddle).HasMaxLength(100);
            entity.Property(e => e.Fte).HasColumnName("FTE");
            entity.Property(e => e.HiringManagerFirst).HasMaxLength(100);
            entity.Property(e => e.HiringManagerLast).HasMaxLength(100);
            entity.Property(e => e.HiringManagerMiddle).HasMaxLength(100);
            entity.Property(e => e.Hrisidentifier)
                .HasMaxLength(64)
                .HasColumnName("HRISIdentifier");
            entity.Property(e => e.PostingDate).HasColumnType("datetime");
            entity.Property(e => e.PrequalificationQuestionnaireId).HasColumnName("PrequalificationQuestionnaireID");
            entity.Property(e => e.RankingQuestionnaireId).HasColumnName("RankingQuestionnaireID");
            entity.Property(e => e.RecruiterFirst).HasMaxLength(100);
            entity.Property(e => e.RecruiterLast).HasMaxLength(100);
            entity.Property(e => e.RecruiterMiddle).HasMaxLength(100);
            entity.Property(e => e.RequisitionId).HasColumnName("RequisitionID");
            entity.Property(e => e.RequisitionNumber).HasMaxLength(30);
            entity.Property(e => e.RequisitionStatusTypeId).HasColumnName("RequisitionStatusTypeID");
            entity.Property(e => e.RequisitionTitle).HasMaxLength(100);
            entity.Property(e => e.Schedule).HasMaxLength(100);
            entity.Property(e => e.Shift).HasMaxLength(100);
        });

        modelBuilder.Entity<ApplicationScheduleView>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("ApplicationScheduleView");

            entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");
        });

        modelBuilder.Entity<ApplicationShiftView>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("ApplicationShiftView");

            entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");
        });

        modelBuilder.Entity<ApplicationSnapshotReportQueue>(entity =>
        {
            entity.HasKey(e => e.ApplicationSnapshotReportQueueId).HasName("PK__Applicat__048C5B4C57719F64");

            entity.ToTable("ApplicationSnapshotReportQueue");

            entity.HasIndex(e => new { e.ApplicationId, e.ApplicationFormId }, "IDX_ApplicationID").HasFillFactor(80);

            entity.Property(e => e.ApplicationSnapshotReportQueueId).HasColumnName("ApplicationSnapshotReportQueueID");
            entity.Property(e => e.ApplicationFormId).HasColumnName("ApplicationFormID");
            entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");
            entity.Property(e => e.FieldId).HasColumnName("FieldID");
            entity.Property(e => e.GroupId).HasColumnName("GroupID");
            entity.Property(e => e.GroupName).HasMaxLength(200);
            entity.Property(e => e.GroupSequenceId).HasColumnName("GroupSequenceID");
            entity.Property(e => e.SectionName).HasMaxLength(200);
            entity.Property(e => e.TmsdataTypeId).HasColumnName("TMSDataTypeID");
        });

        modelBuilder.Entity<ApplicationStatusFullMessage>(entity =>
        {
            entity.HasKey(e => e.ApplicationStatusFullMessageId).HasName("PK__Applicat__451DFFE135CD7E12");

            entity.ToTable("ApplicationStatusFullMessage", "Admin");

            entity.Property(e => e.ApplicationStatusFullMessageId).HasColumnName("ApplicationStatusFullMessageID");
            entity.Property(e => e.ApplicationStatusTypeId).HasColumnName("ApplicationStatusTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Message).HasComment("A column to store the full application status message from PM10.");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.ApplicationStatusType).WithMany(p => p.ApplicationStatusFullMessages)
                .HasForeignKey(d => d.ApplicationStatusTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ApplicationStatusType_ApplicationStatusFullMessage_1");
        });

        modelBuilder.Entity<ApplicationStatusMessage>(entity =>
        {
            entity.HasKey(e => e.ApplicationStatusMessageId).HasName("PK__Applicat__520DB159437E04F1");

            entity.ToTable("ApplicationStatusMessage", "Admin");

            entity.HasIndex(e => new { e.ApplicationStatusTypeId, e.CareerSiteId }, "IDX_ApplicationStatusMessage_2").IsUnique();

            entity.Property(e => e.ApplicationStatusMessageId).HasColumnName("ApplicationStatusMessageID");
            entity.Property(e => e.ApplicationStatusTypeId).HasColumnName("ApplicationStatusTypeID");
            entity.Property(e => e.CareerSiteId).HasColumnName("CareerSiteID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.IsDispositionIncluded).HasComment("A bit to indicate if the user checked off the option to append the disposition to the application status message.");
            entity.Property(e => e.Message)
                .HasMaxLength(500)
                .HasComment("This column contains the status message that is displayed to the applicant.");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.ApplicationStatusType).WithMany(p => p.ApplicationStatusMessages)
                .HasForeignKey(d => d.ApplicationStatusTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ApplicationStatusType_ApplicationStatusMessage_1");

            entity.HasOne(d => d.CareerSite).WithMany(p => p.ApplicationStatusMessages)
                .HasForeignKey(d => d.CareerSiteId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_CareerSite_ApplicationStatusMessage_2");
        });

        modelBuilder.Entity<ApplicationStatusType>(entity =>
        {
            entity.HasKey(e => e.ApplicationStatusTypeId).HasName("PK__Applicat__C420620BC8086784");

            entity.ToTable("ApplicationStatusType", "Admin");

            entity.Property(e => e.ApplicationStatusTypeId).HasColumnName("ApplicationStatusTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DefaultMessage)
                .HasMaxLength(500)
                .HasComment("A column to store the default message displayed to the applicant.");
            entity.Property(e => e.IsDispositionApplicable).HasComment("A column to indicate if a disposition is associated with a given status.");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.ShortName).HasMaxLength(15);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<ApplicationStatusView>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("ApplicationStatusView");

            entity.Property(e => e.LocalApplicantId).HasColumnName("LocalApplicantID");
        });

        modelBuilder.Entity<ApplicationType>(entity =>
        {
            entity.HasKey(e => e.ApplicationTypeId).HasName("PK__Applicat__2821511AB080CF3B");

            entity.ToTable("ApplicationType", "Admin");

            entity.Property(e => e.ApplicationTypeId).HasColumnName("ApplicationTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<ApplicationVendorOrder>(entity =>
        {
            entity.HasKey(e => e.ApplicationVendorOrderId).HasName("PK_ApplicationVendorOrderID");

            entity.ToTable("ApplicationVendorOrder");

            entity.HasIndex(e => new { e.VendorOrderId, e.ApplicationId, e.Deleted }, "IDX_ApplicationVendorOrder_2").IsUnique();

            entity.Property(e => e.ApplicationVendorOrderId).HasColumnName("ApplicationVendorOrderID");
            entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.VendorOrderId).HasColumnName("VendorOrderID");

            entity.HasOne(d => d.Application).WithMany(p => p.ApplicationVendorOrders)
                .HasForeignKey(d => d.ApplicationId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Application_ApplicationVendorOrder_2");

            entity.HasOne(d => d.VendorOrder).WithMany(p => p.ApplicationVendorOrders)
                .HasForeignKey(d => d.VendorOrderId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_VendorOrder_ApplicationVendorOrder_1");
        });

        modelBuilder.Entity<ApplicationView>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("ApplicationView");

            entity.Property(e => e.ApplicantAnalyticsStatusTypeId).HasColumnName("ApplicantAnalyticsStatusTypeID");
            entity.Property(e => e.ApplicantFirstName).HasMaxLength(100);
            entity.Property(e => e.ApplicantId).HasColumnName("ApplicantID");
            entity.Property(e => e.ApplicantLastName).HasMaxLength(100);
            entity.Property(e => e.ApplicantMiddleName).HasMaxLength(100);
            entity.Property(e => e.ApplicantName).HasMaxLength(202);
            entity.Property(e => e.ApplicationDate).HasColumnType("datetime");
            entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");
            entity.Property(e => e.ApplicationStatusTypeId).HasColumnName("ApplicationStatusTypeID");
            entity.Property(e => e.ApplicationType).HasMaxLength(100);
            entity.Property(e => e.ApplicationTypeId).HasColumnName("ApplicationTypeID");
            entity.Property(e => e.BackgroundCheckStatusTypeId).HasColumnName("BackgroundCheckStatusTypeID");
            entity.Property(e => e.BusinessEntityId).HasColumnName("BusinessEntityID");
            entity.Property(e => e.CategoryId).HasColumnName("CategoryID");
            entity.Property(e => e.City).HasMaxLength(50);
            entity.Property(e => e.Country).HasMaxLength(100);
            entity.Property(e => e.CurrentStatus).HasMaxLength(15);
            entity.Property(e => e.CurrentStatusFullName).HasMaxLength(100);
            entity.Property(e => e.DispositionMetaValueId).HasColumnName("DispositionMetaValueID");
            entity.Property(e => e.DispositionText).HasMaxLength(100);
            entity.Property(e => e.Education).HasMaxLength(100);
            entity.Property(e => e.EducationFullName)
                .HasMaxLength(1)
                .IsUnicode(false);
            entity.Property(e => e.Email).HasMaxLength(256);
            entity.Property(e => e.Experience).HasMaxLength(100);
            entity.Property(e => e.ExperienceFullName)
                .HasMaxLength(1)
                .IsUnicode(false);
            entity.Property(e => e.HiringManagerId).HasColumnName("HiringManagerID");
            entity.Property(e => e.Hmbody).HasColumnName("HMBody");
            entity.Property(e => e.HmcreateDate)
                .HasColumnType("datetime")
                .HasColumnName("HMCreateDate");
            entity.Property(e => e.HmresponseLatestCommunicationId).HasColumnName("HMResponseLatestCommunicationID");
            entity.Property(e => e.HmresponseMetaValueId).HasColumnName("HMResponseMetaValueID");
            entity.Property(e => e.Hmscore)
                .HasColumnType("decimal(18, 0)")
                .HasColumnName("HMScore");
            entity.Property(e => e.HmsenderName)
                .HasMaxLength(201)
                .HasColumnName("HMSenderName");
            entity.Property(e => e.Hmsubject)
                .HasMaxLength(1024)
                .HasColumnName("HMSubject");
            entity.Property(e => e.HmsubjectColor)
                .HasMaxLength(7)
                .IsFixedLength()
                .HasColumnName("HMSubjectColor");
            entity.Property(e => e.Hrisidentifier)
                .HasMaxLength(64)
                .HasColumnName("HRISIdentifier");
            entity.Property(e => e.Hrscore)
                .HasColumnType("decimal(18, 0)")
                .HasColumnName("HRScore");
            entity.Property(e => e.IncludeHmcommunication).HasColumnName("IncludeHMCommunication");
            entity.Property(e => e.JobCode).HasMaxLength(100);
            entity.Property(e => e.JobFamilyId).HasColumnName("JobFamilyID");
            entity.Property(e => e.JobTemplateId).HasColumnName("JobTemplateID");
            entity.Property(e => e.LcoalCountry).HasMaxLength(100);
            entity.Property(e => e.License).HasMaxLength(100);
            entity.Property(e => e.LicenseFullName)
                .HasMaxLength(1)
                .IsUnicode(false);
            entity.Property(e => e.LocalApplicantFirstName).HasMaxLength(100);
            entity.Property(e => e.LocalApplicantId).HasColumnName("LocalApplicantID");
            entity.Property(e => e.LocalApplicantLastName).HasMaxLength(100);
            entity.Property(e => e.LocalApplicantMiddleName).HasMaxLength(100);
            entity.Property(e => e.LocalApplicantName).HasMaxLength(202);
            entity.Property(e => e.LocalCity).HasMaxLength(50);
            entity.Property(e => e.LocalEmail).HasMaxLength(256);
            entity.Property(e => e.LocalPhoneNumber).HasMaxLength(20);
            entity.Property(e => e.LocalPhoneType).HasMaxLength(100);
            entity.Property(e => e.LocalState).HasMaxLength(100);
            entity.Property(e => e.LocalStreet1).HasMaxLength(50);
            entity.Property(e => e.LocalStreet2).HasMaxLength(50);
            entity.Property(e => e.LocalZipcode).HasMaxLength(12);
            entity.Property(e => e.PhoneNumber).HasMaxLength(20);
            entity.Property(e => e.PhoneType).HasMaxLength(100);
            entity.Property(e => e.RankingQuestionnaireId).HasColumnName("RankingQuestionnaireID");
            entity.Property(e => e.ReceivedVia).HasMaxLength(100);
            entity.Property(e => e.RecruiterId).HasColumnName("RecruiterID");
            entity.Property(e => e.ReferenceCheckStatusTypeId).HasColumnName("ReferenceCheckStatusTypeID");
            entity.Property(e => e.RequisitionId).HasColumnName("RequisitionID");
            entity.Property(e => e.RequisitionNumber).HasMaxLength(30);
            entity.Property(e => e.RequisitionStatusTypeId).HasColumnName("RequisitionStatusTypeID");
            entity.Property(e => e.RequisitionStatusTypeName).HasMaxLength(100);
            entity.Property(e => e.RequisitionTitle).HasMaxLength(100);
            entity.Property(e => e.RespondedToHmlatestCommunication).HasColumnName("RespondedToHMLatestCommunication");
            entity.Property(e => e.ScheduleFullName)
                .HasMaxLength(1)
                .IsUnicode(false);
            entity.Property(e => e.Score).HasColumnType("decimal(18, 0)");
            entity.Property(e => e.ShiftFullName)
                .HasMaxLength(1)
                .IsUnicode(false);
            entity.Property(e => e.ShiftId).HasColumnName("ShiftID");
            entity.Property(e => e.State).HasMaxLength(100);
            entity.Property(e => e.StatusDate).HasColumnType("datetime");
            entity.Property(e => e.Street1).HasMaxLength(50);
            entity.Property(e => e.Street2).HasMaxLength(50);
            entity.Property(e => e.TestAssessmentStatusTypeId).HasColumnName("TestAssessmentStatusTypeID");
            entity.Property(e => e.Zipcode).HasMaxLength(12);
        });

        modelBuilder.Entity<ApplicationWorkflowRestartFailureLog>(entity =>
        {
            entity.HasKey(e => e.ApplicationWorkflowRestartFailureLogId).HasName("PK__Applicat__F072CDBD5C424EB9");

            entity.ToTable("ApplicationWorkflowRestartFailureLog");

            entity.Property(e => e.ApplicationWorkflowRestartFailureLogId).HasColumnName("ApplicationWorkflowRestartFailureLogID");
            entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.WorkflowProcessId).HasColumnName("WorkflowProcessID");
        });

        modelBuilder.Entity<AssessmentPackage>(entity =>
        {
            entity.HasKey(e => e.AssessmentPackageId).HasName("PK_AssessmentPackageID");

            entity.ToTable("AssessmentPackage", "Admin");

            entity.Property(e => e.AssessmentPackageId).HasColumnName("AssessmentPackageID");
            entity.Property(e => e.AssessmentTypeIdentifier).HasMaxLength(50);
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.JobFamilyIdentifier).HasMaxLength(50);
            entity.Property(e => e.JobFamilyName).HasMaxLength(100);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.PackageDescription).HasMaxLength(255);
            entity.Property(e => e.PackageIdentifier).HasMaxLength(50);
            entity.Property(e => e.PackageName).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<AssessmentVendorOrder>(entity =>
        {
            entity.HasKey(e => e.AssessmentVendorOrderId).HasName("PK_AssessmentVendorOrderID");

            entity.ToTable("AssessmentVendorOrder");

            entity.Property(e => e.AssessmentVendorOrderId).HasColumnName("AssessmentVendorOrderID");
            entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.LocalApplicantId).HasColumnName("LocalApplicantID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.VendorOrderId).HasColumnName("VendorOrderID");

            entity.HasOne(d => d.Application).WithMany(p => p.AssessmentVendorOrders)
                .HasForeignKey(d => d.ApplicationId)
                .HasConstraintName("FK__AssessmentVendorOrder_Application");

            entity.HasOne(d => d.LocalApplicant).WithMany(p => p.AssessmentVendorOrders)
                .HasForeignKey(d => d.LocalApplicantId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__AssessmentVendorOrder_LocalApplicant");

            entity.HasOne(d => d.VendorOrder).WithMany(p => p.AssessmentVendorOrders)
                .HasForeignKey(d => d.VendorOrderId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__AssessmentVendorOrder_VendorOrder");
        });

        modelBuilder.Entity<AssessmentVendorOrderDetail>(entity =>
        {
            entity.HasKey(e => e.AssessmentVendorOrderDetailId).HasName("PK_AssessmentVendorOrderDetailID");

            entity.ToTable("AssessmentVendorOrderDetail");

            entity.Property(e => e.AssessmentVendorOrderDetailId).HasColumnName("AssessmentVendorOrderDetailID");
            entity.Property(e => e.AssessmentVendorOrderId).HasColumnName("AssessmentVendorOrderID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.JobFamilyId).HasColumnName("JobFamilyID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.ResultLink).HasMaxLength(2000);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.VendorOrderResultId).HasColumnName("VendorOrderResultID");

            entity.HasOne(d => d.AssessmentVendorOrder).WithMany(p => p.AssessmentVendorOrderDetails)
                .HasForeignKey(d => d.AssessmentVendorOrderId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__AssessmentVendorOrderDetail_AssessmentVendorOrder");

            entity.HasOne(d => d.JobFamily).WithMany(p => p.AssessmentVendorOrderDetails)
                .HasForeignKey(d => d.JobFamilyId)
                .HasConstraintName("FK__AssessmentVendorOrderDetail_JobFamily");

            entity.HasOne(d => d.VendorOrderResult).WithMany(p => p.AssessmentVendorOrderDetails)
                .HasForeignKey(d => d.VendorOrderResultId)
                .HasConstraintName("FK__AssessmentVendorOrderDetail_VendorOrderDetail");
        });

        modelBuilder.Entity<AssessmentView>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("AssessmentView");

            entity.Property(e => e.AssessmentVendorOrderDetailId).HasColumnName("AssessmentVendorOrderDetailID");
            entity.Property(e => e.AssessmentVendorOrderId).HasColumnName("AssessmentVendorOrderID");
            entity.Property(e => e.CompletionDate).HasColumnType("datetime");
            entity.Property(e => e.Description).HasMaxLength(255);
            entity.Property(e => e.JobFamilyId).HasColumnName("JobFamilyID");
            entity.Property(e => e.JobFamilyName).HasMaxLength(100);
            entity.Property(e => e.LocalApplicantId).HasColumnName("LocalApplicantID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.OrderIdentifier).HasMaxLength(64);
            entity.Property(e => e.ResultLink).HasMaxLength(2000);
            entity.Property(e => e.StatusName).HasMaxLength(100);
            entity.Property(e => e.VendorId).HasColumnName("VendorID");
            entity.Property(e => e.VendorName).HasMaxLength(100);
            entity.Property(e => e.VendorOrderId).HasColumnName("VendorOrderID");
            entity.Property(e => e.VendorOrderStatusTypeId).HasColumnName("VendorOrderStatusTypeID");
            entity.Property(e => e.VendorTypeId).HasColumnName("VendorTypeID");
        });

        modelBuilder.Entity<AttributeType>(entity =>
        {
            entity.HasKey(e => e.AttributeTypeId).HasName("PK_AttributeTypeID");

            entity.ToTable("AttributeType", "Admin");

            entity.HasIndex(e => new { e.Deleted, e.Name }, "IDX_AttributeType_2").IsUnique();

            entity.Property(e => e.AttributeTypeId).HasColumnName("AttributeTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Description).HasMaxLength(255);
            entity.Property(e => e.IsSystem).HasDefaultValue(true);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsdataTypeId).HasColumnName("TMSDataTypeID");

            entity.HasOne(d => d.TmsdataType).WithMany(p => p.AttributeTypes)
                .HasForeignKey(d => d.TmsdataTypeId)
                .HasConstraintName("FK_TMSDataType_AttributeType_1");
        });

        modelBuilder.Entity<AttributeValue>(entity =>
        {
            entity.HasKey(e => e.AttributeValueId).HasName("PK_AttributeValueID");

            entity.ToTable("AttributeValue", "Admin");

            entity.Property(e => e.AttributeValueId).HasColumnName("AttributeValueID");
            entity.Property(e => e.AttributeTypeId).HasColumnName("AttributeTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.AttributeType).WithMany(p => p.AttributeValues)
                .HasForeignKey(d => d.AttributeTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_AttributeType_AttributeValue_1");
        });

        modelBuilder.Entity<Audit>(entity =>
        {
            entity.HasKey(e => e.AuditId).HasName("PK_AuditID");

            entity.ToTable("Audit", "Auth");

            entity.Property(e => e.AuditId).HasColumnName("AuditID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ImpersonatingUserId).HasColumnName("ImpersonatingUserID");
            entity.Property(e => e.Ipaddress)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("IPAddress");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Operation)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.OperationTime).HasColumnType("datetime");
            entity.Property(e => e.Reason)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.Result)
                .HasMaxLength(4)
                .IsUnicode(false);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserId");
            entity.Property(e => e.UserName).HasMaxLength(100);

            entity.HasOne(d => d.Tmsuser).WithMany(p => p.Audits)
                .HasForeignKey(d => d.TmsuserId)
                .HasConstraintName("FK_Audit_TMSUserID");
        });

        modelBuilder.Entity<BehavioralAssessmentInterimView>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("BehavioralAssessmentInterimView");

            entity.Property(e => e.Countbig).HasColumnName("_countbig");
            entity.Property(e => e.VendorOrderCreateDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<BehavioralAssessmentView>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("BehavioralAssessmentView");
        });

        modelBuilder.Entity<BulkIndexLog>(entity =>
        {
            entity.HasKey(e => e.BulkIndexLogId).HasName("PK_BulkIndexLogID");

            entity.ToTable("BulkIndexLog");

            entity.Property(e => e.BulkIndexLogId).HasColumnName("BulkIndexLogID");
            entity.Property(e => e.ContextId).HasColumnName("ContextID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.IndexEnd).HasColumnType("datetime");
            entity.Property(e => e.IndexStart).HasColumnType("datetime");
            entity.Property(e => e.IndexTypeId).HasColumnName("IndexTypeID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.IndexType).WithMany(p => p.BulkIndexLogs)
                .HasForeignKey(d => d.IndexTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_IndexType_BulkIndexLog_1");
        });

        modelBuilder.Entity<BusinessEntity>(entity =>
        {
            entity.HasKey(e => e.BusinessEntityId).HasName("PK_BusinessEntityID");

            entity.ToTable("BusinessEntity", "Admin", tb =>
                {
                    tb.HasTrigger("BusinessEntityDeleteTrigger");
                    tb.HasTrigger("BusinessEntityInsertUpdateTrigger");
                });

            entity.HasIndex(e => new { e.BusinessEntityTypeId, e.Deleted }, "IDX_BusinessEntityWithParent");

            entity.HasIndex(e => new { e.Hrisidentifier, e.BusinessEntityTypeId, e.Deleted }, "IDX_BusinessEntity_3")
                .IsUnique()
                .HasFilter("([HRISIdentifier] IS NOT NULL)");

            entity.Property(e => e.BusinessEntityId).HasColumnName("BusinessEntityID");
            entity.Property(e => e.BusinessEntityTypeId).HasColumnName("BusinessEntityTypeID");
            entity.Property(e => e.City)
                .HasMaxLength(255)
                .HasComment("Added City to this table to help with search performance. The value in this field can also be retrieved by joining to BusinessEntityAttrivuteValue and then the AttributeValue table.");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Description).HasMaxLength(255);
            entity.Property(e => e.DisplayName).HasMaxLength(100);
            entity.Property(e => e.Hrisidentifier)
                .HasMaxLength(64)
                .HasColumnName("HRISIdentifier");
            entity.Property(e => e.LogoFileLocation).HasMaxLength(2000);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.ParentId).HasColumnName("ParentID");
            entity.Property(e => e.State)
                .HasMaxLength(255)
                .HasComment("Added State to this table to help with search performance. The value in this field can also be retrieved by joining to BusinessEntityAttrivuteValue and then the AttributeValue table.");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.BusinessEntityType).WithMany(p => p.BusinessEntities)
                .HasForeignKey(d => d.BusinessEntityTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessEntityType_BusinessEntity_2");

            entity.HasOne(d => d.Parent).WithMany(p => p.InverseParent)
                .HasForeignKey(d => d.ParentId)
                .HasConstraintName("FK_BusinessEntity_BusinessEntity_1");
        });

        modelBuilder.Entity<BusinessEntityAttributeValue>(entity =>
        {
            entity.HasKey(e => e.BusinessEntityAttributeValueId).HasName("PK_BusinessEntityAttributeValueID");

            entity.ToTable("BusinessEntityAttributeValue", "Admin");

            entity.HasIndex(e => new { e.BusinessEntityId, e.AttributeValueId, e.Deleted }, "IDX_BusinessEntityAttributeValue_2").IsUnique();

            entity.Property(e => e.BusinessEntityAttributeValueId).HasColumnName("BusinessEntityAttributeValueID");
            entity.Property(e => e.AttributeValueId).HasColumnName("AttributeValueID");
            entity.Property(e => e.BusinessEntityId).HasColumnName("BusinessEntityID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.AttributeValue).WithMany(p => p.BusinessEntityAttributeValues)
                .HasForeignKey(d => d.AttributeValueId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_AttributeValue_BusinessEntityAttributeValue_1");

            entity.HasOne(d => d.BusinessEntity).WithMany(p => p.BusinessEntityAttributeValues)
                .HasForeignKey(d => d.BusinessEntityId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessEntity_BusinessEntityAttributeValue_2");
        });

        modelBuilder.Entity<BusinessEntityType>(entity =>
        {
            entity.HasKey(e => e.BusinessEntityTypeId).HasName("PK_BusinessEntityTypeID");

            entity.ToTable("BusinessEntityType", "Admin");

            entity.HasIndex(e => new { e.Deleted, e.HierarchyLevel }, "IDX_BusinessEntityType_2").IsUnique();

            entity.HasIndex(e => new { e.Deleted, e.Name }, "IDX_BusinessEntityType_3").IsUnique();

            entity.HasIndex(e => new { e.ParentId, e.Deleted }, "IDX_BusinessEntityType_4").IsUnique();

            entity.HasIndex(e => new { e.Hrisidentifier, e.Deleted }, "IDX_BusinessEntityType_5")
                .IsUnique()
                .HasFilter("([HRISIdentifier] IS NOT NULL)");

            entity.Property(e => e.BusinessEntityTypeId).HasColumnName("BusinessEntityTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Description).HasMaxLength(255);
            entity.Property(e => e.Hrisidentifier)
                .HasMaxLength(64)
                .HasColumnName("HRISIdentifier");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.ParentId).HasColumnName("ParentID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.Parent).WithMany(p => p.InverseParent)
                .HasForeignKey(d => d.ParentId)
                .HasConstraintName("FK_BusinessEntityType_BusinessEntityType_1");
        });

        modelBuilder.Entity<BusinessEntityTypeAttributeType>(entity =>
        {
            entity.HasKey(e => e.BusinessEntityTypeAttributeTypeId).HasName("PK_BusinessEntityTypeAttributeTypeID");

            entity.ToTable("BusinessEntityTypeAttributeType", "Admin");

            entity.HasIndex(e => new { e.BusinessEntityTypeId, e.Deleted, e.AttributeTypeId }, "IDX_BusinessEntityTypeAttributeType_2").IsUnique();

            entity.Property(e => e.BusinessEntityTypeAttributeTypeId).HasColumnName("BusinessEntityTypeAttributeTypeID");
            entity.Property(e => e.AttributeTypeId).HasColumnName("AttributeTypeID");
            entity.Property(e => e.BusinessEntityTypeId).HasColumnName("BusinessEntityTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.AttributeType).WithMany(p => p.BusinessEntityTypeAttributeTypes)
                .HasForeignKey(d => d.AttributeTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_AttributeType_BusinessEntityTypeAttributeType_1");

            entity.HasOne(d => d.BusinessEntityType).WithMany(p => p.BusinessEntityTypeAttributeTypes)
                .HasForeignKey(d => d.BusinessEntityTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessEntityType_BusinessEntityTypeAttributeType_2");
        });

        modelBuilder.Entity<CareerSite>(entity =>
        {
            entity.HasKey(e => e.CareerSiteId)
                .HasName("PK__CareerSi__B697702B315C075E")
                .IsClustered(false);

            entity.ToTable("CareerSite", "Admin");

            entity.HasIndex(e => new { e.SiteId, e.Deleted }, "IDX_CareerSite_SiteID").IsUnique();

            entity.HasIndex(e => new { e.Name, e.Deleted }, "UC_CareerSite_Name").IsUnique();

            entity.Property(e => e.CareerSiteId).HasColumnName("CareerSiteID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DisplayApplicationStatusToJobSeeker)
                .HasDefaultValue(true)
                .HasComment("This Column Value decides whether the 'Application Status' grid column in SubmittedApplicationHistory View in Career site gets displays or not.");
            entity.Property(e => e.EndingBusinessEntityTypeId).HasColumnName("EndingBusinessEntityTypeID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SiteId).HasColumnName("SiteID");
            entity.Property(e => e.StartingBusinessEntityTypeId).HasColumnName("StartingBusinessEntityTypeID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.EndingBusinessEntityType).WithMany(p => p.CareerSiteEndingBusinessEntityTypes)
                .HasForeignKey(d => d.EndingBusinessEntityTypeId)
                .HasConstraintName("FK_BusinessEntityType_CareerSite_3");

            entity.HasOne(d => d.StartingBusinessEntityType).WithMany(p => p.CareerSiteStartingBusinessEntityTypes)
                .HasForeignKey(d => d.StartingBusinessEntityTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessEntityType_CareerSite_2");
        });

        modelBuilder.Entity<ClientSetting>(entity =>
        {
            entity.HasKey(e => e.ClientSettingId).HasName("PK_ClientSettingID");

            entity.ToTable("ClientSetting", "Auth");

            entity.HasIndex(e => e.ClientSettingTypeId, "IDX_ClientSetting_2");

            entity.Property(e => e.ClientSettingId).HasColumnName("ClientSettingID");
            entity.Property(e => e.ClientSettingTypeId).HasColumnName("ClientSettingTypeID");
            entity.Property(e => e.ControlTypeId).HasColumnName("ControlTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.CurrentValue).HasMaxLength(1024);
            entity.Property(e => e.DefaultValue).HasMaxLength(255);
            entity.Property(e => e.Description).HasMaxLength(255);
            entity.Property(e => e.DisplayOrder).HasDefaultValue(0);
            entity.Property(e => e.MetaTypeId).HasColumnName("MetaTypeID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(255);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.UserPreferenceOverridable).HasDefaultValue(false);

            entity.HasOne(d => d.ClientSettingType).WithMany(p => p.ClientSettings)
                .HasForeignKey(d => d.ClientSettingTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ClientSettingType_ClientSetting_1");

            entity.HasOne(d => d.ControlType).WithMany(p => p.ClientSettings)
                .HasForeignKey(d => d.ControlTypeId)
                .HasConstraintName("FK_ControlType_ClientSetting_2");

            entity.HasOne(d => d.MetaType).WithMany(p => p.ClientSettings)
                .HasForeignKey(d => d.MetaTypeId)
                .HasConstraintName("FK_MetaType_ClientSetting_3");
        });

        modelBuilder.Entity<ClientSettingDefaultListValue>(entity =>
        {
            entity.HasKey(e => e.ClientSettingDefaultListValuesId).HasName("PK_ClientSettingDefaultListValuesID");

            entity.ToTable("ClientSettingDefaultListValues", "Auth");

            entity.HasIndex(e => new { e.ClientSettingId, e.MetaValueId, e.Deleted }, "UC_ClientSettingDefaultListValues_Unique").IsUnique();

            entity.Property(e => e.ClientSettingDefaultListValuesId).HasColumnName("ClientSettingDefaultListValuesID");
            entity.Property(e => e.ClientSettingId).HasColumnName("ClientSettingID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.MetaValueId).HasColumnName("MetaValueID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.ClientSetting).WithMany(p => p.ClientSettingDefaultListValues)
                .HasForeignKey(d => d.ClientSettingId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ClientSetting_ClientSettingDefaultListValues_1");

            entity.HasOne(d => d.MetaValue).WithMany(p => p.ClientSettingDefaultListValues)
                .HasForeignKey(d => d.MetaValueId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MetaValue_ClientSettingDefaultListValues_1");
        });

        modelBuilder.Entity<ClientSettingType>(entity =>
        {
            entity.HasKey(e => e.ClientSettingTypeId).HasName("PK_ClientSettingTypeID");

            entity.ToTable("ClientSettingType", "Auth");

            entity.Property(e => e.ClientSettingTypeId).HasColumnName("ClientSettingTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<Communication>(entity =>
        {
            entity.HasKey(e => e.CommunicationId).HasName("PK__Communic__53E5658FF2C792C1");

            entity.ToTable("Communication");

            entity.HasIndex(e => e.ThreadId, "IDX_ThreadID").HasFillFactor(80);

            entity.Property(e => e.CommunicationId).HasColumnName("CommunicationID");
            entity.Property(e => e.Bccemail)
                .HasMaxLength(2048)
                .HasColumnName("BCCEmail");
            entity.Property(e => e.Ccemail)
                .HasMaxLength(2048)
                .HasColumnName("CCEmail");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.GroupSendDate)
                .HasComment("GroupSendDate links the communications that were sent as one group. For example when an applicaiton is sent to a manager, a number of additional communications may be created at the same time for tasks to fill custom forms, etc. CreatedDate may be different for them depending on how EntityFramework or other tool saved the groupped communications. The use of date allows the groups to be sortable and the groups defined uniquely enough for each communication thread.\r\n")
                .HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.RecipientEmail).HasMaxLength(2048);
            entity.Property(e => e.RecipientUserId).HasColumnName("RecipientUserID");
            entity.Property(e => e.RecipientUserRoleTypeId)
                .HasComment("This column is required to record the recipient user role type that participated in the communication at the time the communication was sent. ")
                .HasColumnName("RecipientUserRoleTypeID");
            entity.Property(e => e.ReplyToCommunicationId).HasColumnName("ReplyToCommunicationID");
            entity.Property(e => e.SavedAsDocumentId).HasColumnName("SavedAsDocumentID");
            entity.Property(e => e.SenderEmail).HasMaxLength(256);
            entity.Property(e => e.SenderUserId).HasColumnName("SenderUserID");
            entity.Property(e => e.SenderUserRoleTypeId)
                .HasDefaultValue(2)
                .HasComment("This column is required to record the sender user role type that participated in the communication at the time the communication was sent.")
                .HasColumnName("SenderUserRoleTypeID");
            entity.Property(e => e.Subject).HasMaxLength(1024);
            entity.Property(e => e.SubjectMetaValueId)
                .HasComment("SubjectMetaValueID is the selected meta value ID in case communications subject is chosen from a set defied as a meta type. This vlue defines some other aspects of the communication, such as color of the flag in UI, etc. ")
                .HasColumnName("SubjectMetaValueID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TaskId).HasColumnName("TaskID");
            entity.Property(e => e.TemplateTypeId).HasColumnName("TemplateTypeID");
            entity.Property(e => e.ThreadId).HasColumnName("ThreadID");

            entity.HasOne(d => d.RecipientUser).WithMany(p => p.CommunicationRecipientUsers)
                .HasForeignKey(d => d.RecipientUserId)
                .HasConstraintName("FK_UserProfile_Communication_8");

            entity.HasOne(d => d.RecipientUserRoleType).WithMany(p => p.CommunicationRecipientUserRoleTypes)
                .HasForeignKey(d => d.RecipientUserRoleTypeId)
                .HasConstraintName("FK_RoleType_Communication_11");

            entity.HasOne(d => d.ReplyToCommunication).WithMany(p => p.InverseReplyToCommunication)
                .HasForeignKey(d => d.ReplyToCommunicationId)
                .HasConstraintName("FK_Communication_Communication_9");

            entity.HasOne(d => d.SavedAsDocument).WithMany(p => p.Communications)
                .HasForeignKey(d => d.SavedAsDocumentId)
                .HasConstraintName("FK_Document_Communication_5");

            entity.HasOne(d => d.SenderUser).WithMany(p => p.CommunicationSenderUsers)
                .HasForeignKey(d => d.SenderUserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_UserProfile_Communication_7");

            entity.HasOne(d => d.SenderUserRoleType).WithMany(p => p.CommunicationSenderUserRoleTypes)
                .HasForeignKey(d => d.SenderUserRoleTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_RoleType_Communication_10");

            entity.HasOne(d => d.SubjectMetaValue).WithMany(p => p.Communications)
                .HasForeignKey(d => d.SubjectMetaValueId)
                .HasConstraintName("FK_MetaValue_Communication_4");

            entity.HasOne(d => d.Task).WithMany(p => p.Communications)
                .HasForeignKey(d => d.TaskId)
                .HasConstraintName("FK_Task_Communication_6");

            entity.HasOne(d => d.TemplateType).WithMany(p => p.Communications)
                .HasForeignKey(d => d.TemplateTypeId)
                .HasConstraintName("FK_TemplateType_Communication_2");
        });

        modelBuilder.Entity<CommunicationCcBccUserProfile>(entity =>
        {
            entity.HasKey(e => e.CommunicationCcBccUserProfileId).HasName("PK__Communic__BED47963F7C8EBF5");

            entity.ToTable("CommunicationCcBccUserProfile");

            entity.HasIndex(e => new { e.TmsuserId, e.CommunicationId, e.Deleted }, "IDX_CommunicationCcBccUserProfile_2").IsUnique();

            entity.Property(e => e.CommunicationCcBccUserProfileId).HasColumnName("CommunicationCcBccUserProfileID");
            entity.Property(e => e.CommunicationId).HasColumnName("CommunicationID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");

            entity.HasOne(d => d.Communication).WithMany(p => p.CommunicationCcBccUserProfiles)
                .HasForeignKey(d => d.CommunicationId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Communication_CommunicationCcBccUserProfile_1");

            entity.HasOne(d => d.Tmsuser).WithMany(p => p.CommunicationCcBccUserProfiles)
                .HasForeignKey(d => d.TmsuserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_UserProfile_CommunicationCcBccUserProfile_2");
        });

        modelBuilder.Entity<CommunicationDocument>(entity =>
        {
            entity.HasKey(e => e.CommunicationDocumentId).HasName("PK__Communic__31F3C0D1A59CF2EA");

            entity.ToTable("CommunicationDocument");

            entity.HasIndex(e => new { e.CommunicationId, e.DocumentId, e.Deleted }, "IDX_CommunicationDocument_CommunicationID_DocumentID_Deleted").IsUnique();

            entity.Property(e => e.CommunicationDocumentId).HasColumnName("CommunicationDocumentID");
            entity.Property(e => e.CommunicationId).HasColumnName("CommunicationID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DocumentId).HasColumnName("DocumentID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.Communication).WithMany(p => p.CommunicationDocuments)
                .HasForeignKey(d => d.CommunicationId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Communication_CommunicationDocument");

            entity.HasOne(d => d.Document).WithMany(p => p.CommunicationDocuments)
                .HasForeignKey(d => d.DocumentId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Document_CommunicationDocument");
        });

        modelBuilder.Entity<ContactInformation>(entity =>
        {
            entity.HasKey(e => e.ContactInformationId).HasName("PK__ContactI__4F7441B28841165E");

            entity.ToTable("ContactInformation", "Auth");

            entity.Property(e => e.ContactInformationId).HasColumnName("ContactInformationID");
            entity.Property(e => e.Address).HasMaxLength(50);
            entity.Property(e => e.City).HasMaxLength(50);
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.FaxNumber).HasMaxLength(24);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.State).HasMaxLength(50);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.WorkPhone).HasMaxLength(24);
            entity.Property(e => e.ZipCode).HasMaxLength(10);
        });

        modelBuilder.Entity<ContactInformation1>(entity =>
        {
            entity.HasKey(e => e.ContactInformationId).HasName("PK__ContactI__4F7441B20DE6F769");

            entity.ToTable("ContactInformation");

            entity.Property(e => e.ContactInformationId)
                .ValueGeneratedNever()
                .HasComment("ContactInformationID is not an identity column as the ID is generated from the SecurityDB ContactInformation table.\r\n")
                .HasColumnName("ContactInformationID");
            entity.Property(e => e.Address).HasMaxLength(50);
            entity.Property(e => e.City).HasMaxLength(50);
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.FaxNumber).HasMaxLength(24);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.State).HasMaxLength(50);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.WorkPhone).HasMaxLength(24);
            entity.Property(e => e.ZipCode).HasMaxLength(10);
        });

        modelBuilder.Entity<ControlType>(entity =>
        {
            entity.HasKey(e => e.ControlTypeId).HasName("PK__ControlT__3399DDCB8466D372");

            entity.ToTable("ControlType", "Admin");

            entity.HasIndex(e => new { e.Name, e.Deleted }, "IDX_ControlType_2").IsUnique();

            entity.Property(e => e.ControlTypeId).HasColumnName("ControlTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Description).HasMaxLength(255);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsdataTypeId).HasColumnName("TMSDataTypeID");

            entity.HasOne(d => d.TmsdataType).WithMany(p => p.ControlTypes)
                .HasForeignKey(d => d.TmsdataTypeId)
                .HasConstraintName("FK_TMSDataType_ControlType_1");
        });

        modelBuilder.Entity<DataSourceFieldType>(entity =>
        {
            entity.HasKey(e => e.DataSourceFieldTypeId).HasName("PK_DataSourceFieldTypeID");

            entity.ToTable("DataSourceFieldType", "Admin");

            entity.HasIndex(e => new { e.DataSourceTypeId, e.ColumnName, e.ColumnResourceLookupKey }, "IDX_DataSourceFieldType_2").IsUnique();

            entity.Property(e => e.DataSourceFieldTypeId).HasColumnName("DataSourceFieldTypeID");
            entity.Property(e => e.ColumnName).HasMaxLength(100);
            entity.Property(e => e.ColumnResourceLookupKey).HasMaxLength(100);
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DataSourceTypeId).HasColumnName("DataSourceTypeID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.ResourceManagerKeyId).HasColumnName("ResourceManagerKeyID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsdataTypeId).HasColumnName("TMSDataTypeID");

            entity.HasOne(d => d.DataSourceType).WithMany(p => p.DataSourceFieldTypes)
                .HasForeignKey(d => d.DataSourceTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DataSourceType_DataSourceFieldType_1");

            entity.HasOne(d => d.TmsdataType).WithMany(p => p.DataSourceFieldTypes)
                .HasForeignKey(d => d.TmsdataTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TMSDataType_DataSourceFieldType_2");
        });

        modelBuilder.Entity<DataSourceType>(entity =>
        {
            entity.HasKey(e => e.DataSourceTypeId).HasName("PK_DataSourceTypeID");

            entity.ToTable("DataSourceType", "Admin");

            entity.HasIndex(e => new { e.TableName, e.Deleted }, "IDX_DataSourceType_2").IsUnique();

            entity.Property(e => e.DataSourceTypeId).HasColumnName("DataSourceTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DatabaseConfigurationId).HasColumnName("DatabaseConfigurationID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.ResourceManagerKeyId).HasColumnName("ResourceManagerKeyID");
            entity.Property(e => e.ScopeLevelId).HasColumnName("ScopeLevelID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TableName).HasMaxLength(100);
            entity.Property(e => e.TableResourceLookUpKey).HasMaxLength(100);
        });

        modelBuilder.Entity<DatabaseVersionHistory>(entity =>
        {
            entity.HasKey(e => e.DatabaseVersionHistoryId).HasName("PK__Database__6D67F0E325605212");

            entity.ToTable("DatabaseVersionHistory", "Admin");

            entity.Property(e => e.DatabaseVersionHistoryId).HasColumnName("DatabaseVersionHistoryID");
            entity.Property(e => e.NewVersionNumber)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PreviousVersionNumber)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ScriptName)
                .HasMaxLength(1000)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Department>(entity =>
        {
            entity.HasKey(e => e.DepartmentId).HasName("PK_DepartmentID");

            entity.ToTable("Department", "Admin");

            entity.Property(e => e.DepartmentId).HasColumnName("DepartmentID");
            entity.Property(e => e.Active).HasDefaultValue(true);
            entity.Property(e => e.BudgetedFtes)
                .HasMaxLength(30)
                .HasColumnName("BudgetedFTEs");
            entity.Property(e => e.Code).HasMaxLength(255);
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.FacilityId).HasColumnName("FacilityID");
            entity.Property(e => e.Hrisidentifier)
                .HasMaxLength(64)
                .HasColumnName("HRISIdentifier");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.NumberPositions).HasMaxLength(30);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.Facility).WithMany(p => p.Departments)
                .HasForeignKey(d => d.FacilityId)
                .HasConstraintName("FK_Facility_Department_1");
        });

        modelBuilder.Entity<DepartmentBusinessEntity>(entity =>
        {
            entity.HasKey(e => e.DepartmentBusinessEntityId).HasName("PK_DepartmentBusinessEntityID");

            entity.ToTable("DepartmentBusinessEntity", "Admin");

            entity.Property(e => e.DepartmentBusinessEntityId).HasColumnName("DepartmentBusinessEntityID");
            entity.Property(e => e.BusinessEntityId).HasColumnName("BusinessEntityID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DepartmentId).HasColumnName("DepartmentID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.BusinessEntity).WithMany(p => p.DepartmentBusinessEntities)
                .HasForeignKey(d => d.BusinessEntityId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessEntity_DepartmentBusinessEntity_1");

            entity.HasOne(d => d.Department).WithMany(p => p.DepartmentBusinessEntities)
                .HasForeignKey(d => d.DepartmentId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Department_DepartmentBusinessEntity_2");
        });

        modelBuilder.Entity<DetailSectionType>(entity =>
        {
            entity.HasKey(e => e.DetailSectionTypeId).HasName("PK_DetailSectionTypeID");

            entity.ToTable("DetailSectionType", "Admin");

            entity.Property(e => e.DetailSectionTypeId).HasColumnName("DetailSectionTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(256);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<DispositionSettingsType>(entity =>
        {
            entity.HasKey(e => e.DispositionSettingsTypeId).HasName("PK__Disposit__32745529ECD60E76");

            entity.ToTable("DispositionSettingsType", "Admin");

            entity.HasIndex(e => new { e.Name, e.Deleted }, "IDX_DispositionSettingsType_2").IsUnique();

            entity.Property(e => e.DispositionSettingsTypeId).HasColumnName("DispositionSettingsTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<Document>(entity =>
        {
            entity.HasKey(e => e.DocumentId).HasName("PK__Document__1ABEEF6FBCAC2058");

            entity.ToTable("Document");

            entity.HasIndex(e => e.DocumentMediaTypeId, "IDX_DocumentMediaTypeID").HasFillFactor(80);

            entity.Property(e => e.DocumentId).HasColumnName("DocumentID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DocumentMediaTypeId)
                .HasDefaultValue(1)
                .HasComment("Provides information on how the Document source should be accessed for display based on the lookup of the DocumentSourceType.")
                .HasColumnName("DocumentMediaTypeID");
            entity.Property(e => e.DocumentText).HasComment("If the Document is not stored on a FileServer the complete content of the document is stored in this Column DocumentText.\r\n");
            entity.Property(e => e.DocumentTypeId).HasColumnName("DocumentTypeID");
            entity.Property(e => e.FileLocation)
                .HasMaxLength(1000)
                .HasComment("FileLocation will be populated with the full path of the document which is stored on a file server. e.g.\r\n\\\\fileserver1\\Dir\\Year\\Month\\FileName.xyz\r\n");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(200);
            entity.Property(e => e.QuestionnaireResponseId)
                .HasComment("For document of Questionnaire type this field points to the specific QuestionaireResponse (set of answers) for which the document is created.")
                .HasColumnName("QuestionnaireResponseID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.DocumentMediaType).WithMany(p => p.Documents)
                .HasForeignKey(d => d.DocumentMediaTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DocumentMediaType_Document_5");

            entity.HasOne(d => d.DocumentType).WithMany(p => p.Documents)
                .HasForeignKey(d => d.DocumentTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DocumentType_Document_3");

            entity.HasOne(d => d.QuestionnaireResponse).WithMany(p => p.Documents)
                .HasForeignKey(d => d.QuestionnaireResponseId)
                .HasConstraintName("FK_QuestionnaireResponse_Document_6");
        });

        modelBuilder.Entity<DocumentGroup>(entity =>
        {
            entity.HasKey(e => e.DocumentGroupId).HasName("PK__Document__DB8B5AFAFC804B86");

            entity.ToTable("DocumentGroup", "Admin");

            entity.Property(e => e.DocumentGroupId).HasColumnName("DocumentGroupID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Description).HasMaxLength(255);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<DocumentGroupBusinessEntity>(entity =>
        {
            entity.HasKey(e => e.DocumentGroupBusinessEntityId).HasName("PK_DocumentGroupBusinessEntityID");

            entity.ToTable("DocumentGroupBusinessEntity", "Admin");

            entity.HasIndex(e => new { e.DocumentGroupId, e.BusinessEntityId, e.Deleted }, "IDX_DocumentGroupBusinessEntity_Unique").IsUnique();

            entity.Property(e => e.DocumentGroupBusinessEntityId).HasColumnName("DocumentGroupBusinessEntityID");
            entity.Property(e => e.BusinessEntityId).HasColumnName("BusinessEntityID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DocumentGroupId).HasColumnName("DocumentGroupID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.BusinessEntity).WithMany(p => p.DocumentGroupBusinessEntities)
                .HasForeignKey(d => d.BusinessEntityId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessEntity_DocumentGroupBusinessEntity_1");

            entity.HasOne(d => d.DocumentGroup).WithMany(p => p.DocumentGroupBusinessEntities)
                .HasForeignKey(d => d.DocumentGroupId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Template_DocumentGroupBusinessEntity_2");
        });

        modelBuilder.Entity<DocumentGroupJobTemplate>(entity =>
        {
            entity.HasKey(e => e.DocumentGroupJobTemplateId).HasName("PK_DocumentGroupJobTemplateID");

            entity.ToTable("DocumentGroupJobTemplate", "Admin");

            entity.HasIndex(e => new { e.Deleted, e.DocumentGroupId, e.JobTemplateId }, "IDX_DocumentGroupJobTemplate_Unique").IsUnique();

            entity.Property(e => e.DocumentGroupJobTemplateId).HasColumnName("DocumentGroupJobTemplateID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DocumentGroupId).HasColumnName("DocumentGroupID");
            entity.Property(e => e.JobTemplateId).HasColumnName("JobTemplateID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.DocumentGroup).WithMany(p => p.DocumentGroupJobTemplates)
                .HasForeignKey(d => d.DocumentGroupId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Template_DocumentGroupJobTemplate_2");

            entity.HasOne(d => d.JobTemplate).WithMany(p => p.DocumentGroupJobTemplates)
                .HasForeignKey(d => d.JobTemplateId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessEntity_DocumentGroupJobTemplate_1");
        });

        modelBuilder.Entity<DocumentGroupOnBoardingDocument>(entity =>
        {
            entity.HasKey(e => e.DocumentGroupOnBoardingDocumentId).HasName("PK_DocumentGroupOnBoardingDocumentID");

            entity.ToTable("DocumentGroupOnBoardingDocument", "Admin");

            entity.HasIndex(e => new { e.DocumentGroupId, e.OnBoardingDocumentId, e.Deleted }, "IDX_DocumentGroupOnBoardingDocument_Unique").IsUnique();

            entity.Property(e => e.DocumentGroupOnBoardingDocumentId).HasColumnName("DocumentGroupOnBoardingDocumentID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DocumentGroupId).HasColumnName("DocumentGroupID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.OnBoardingDocumentId).HasColumnName("OnBoardingDocumentID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.DocumentGroup).WithMany(p => p.DocumentGroupOnBoardingDocuments)
                .HasForeignKey(d => d.DocumentGroupId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DocumentGroup_DocumentGroupOnBoardingDocument_1");

            entity.HasOne(d => d.OnBoardingDocument).WithMany(p => p.DocumentGroupOnBoardingDocuments)
                .HasForeignKey(d => d.OnBoardingDocumentId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_OnBoardingDocument_DocumentGroupOnBoardingDocument_2");
        });

        modelBuilder.Entity<DocumentMediaType>(entity =>
        {
            entity.HasKey(e => e.DocumentMediaTypeId).HasName("PK__Document__989B1CD24F878161");

            entity.ToTable("DocumentMediaType", "Admin");

            entity.HasIndex(e => new { e.Name, e.Deleted }, "IDX_DocumentMediaType_2").IsUnique();

            entity.Property(e => e.DocumentMediaTypeId).HasColumnName("DocumentMediaTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<DocumentType>(entity =>
        {
            entity.HasKey(e => e.DocumentTypeId).HasName("PK__Document__DBA390C1EF817B93");

            entity.ToTable("DocumentType", "Admin");

            entity.HasIndex(e => new { e.Name, e.Deleted }, "IDX_DocumentType_2").IsUnique();

            entity.Property(e => e.DocumentTypeId).HasColumnName("DocumentTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<DraftObjectStore>(entity =>
        {
            entity.HasKey(e => e.DraftObjectStoreId).HasName("PK_DraftObjectStoreID");

            entity.ToTable("DraftObjectStore");

            entity.Property(e => e.DraftObjectStoreId).HasColumnName("DraftObjectStoreID");
            entity.Property(e => e.ContextObjectId).HasColumnName("ContextObjectID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.ObjectTypeId).HasColumnName("ObjectTypeID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");
        });

        modelBuilder.Entity<EsignatureDocument>(entity =>
        {
            entity.HasKey(e => e.EsignatureDocumentId).HasName("PK__Esignatu__55B849B9B3D9749F");

            entity.ToTable("EsignatureDocument");

            entity.HasIndex(e => new { e.ApplicationId, e.DocumentId, e.Deleted }, "IDX_EsignatureDocument_unique").IsUnique();

            entity.Property(e => e.EsignatureDocumentId).HasColumnName("EsignatureDocumentID");
            entity.Property(e => e.ApplicantSignatureTemplateId).HasColumnName("ApplicantSignatureTemplateID");
            entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");
            entity.Property(e => e.CommunicationId).HasColumnName("CommunicationID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DateSent).HasColumnType("datetime");
            entity.Property(e => e.DateSigned).HasColumnType("datetime");
            entity.Property(e => e.DocumentId).HasColumnName("DocumentID");
            entity.Property(e => e.EmailNotificationTemplateId).HasColumnName("EmailNotificationTemplateID");
            entity.Property(e => e.Ipaddress)
                .HasMaxLength(20)
                .HasColumnName("IPAddress");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SendForAdditionalHm).HasColumnName("SendForAdditionalHM");
            entity.Property(e => e.SendForHm).HasColumnName("SendForHM");
            entity.Property(e => e.StatusDate).HasColumnType("datetime");
            entity.Property(e => e.SubjectText).HasMaxLength(255);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.Application).WithMany(p => p.EsignatureDocuments)
                .HasForeignKey(d => d.ApplicationId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Application_EsignatureDocument_1");

            entity.HasOne(d => d.Document).WithMany(p => p.EsignatureDocuments)
                .HasForeignKey(d => d.DocumentId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Document_EsignatureDocument_1");
        });

        modelBuilder.Entity<EsignatureDocumentCustomEmailAddress>(entity =>
        {
            entity.HasKey(e => e.EsignatureDocumentCustomEmailAddressId).HasName("PK__Esignatu__41A6A2AD70EDF88C");

            entity.ToTable("EsignatureDocumentCustomEmailAddress");

            entity.Property(e => e.EsignatureDocumentCustomEmailAddressId).HasColumnName("EsignatureDocumentCustomEmailAddressID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.EsignatureDocumentId).HasColumnName("EsignatureDocumentID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.EsignatureDocument).WithMany(p => p.EsignatureDocumentCustomEmailAddresses)
                .HasForeignKey(d => d.EsignatureDocumentId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_EsignatureDocument_EsignatureDocumentCustomEmailAddress_1");
        });

        modelBuilder.Entity<EstablishedHierarchy>(entity =>
        {
            entity.HasKey(e => e.EstablishedHierarchyId).HasName("PK_EstablishedHierarchyID");

            entity.ToTable("EstablishedHierarchy", "Admin");

            entity.Property(e => e.EstablishedHierarchyId).HasColumnName("EstablishedHierarchyID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.HierarchyChangesXml)
                .HasColumnType("xml")
                .HasColumnName("HierarchyChangesXML");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<EstablishedHierarchyChangeType>(entity =>
        {
            entity.HasKey(e => e.EstablishedHierarchyChangeTypeId).HasName("PK_EstablishedHierarchyChangeTypeID");

            entity.ToTable("EstablishedHierarchyChangeType", "Admin");

            entity.Property(e => e.EstablishedHierarchyChangeTypeId).HasColumnName("EstablishedHierarchyChangeTypeID");
            entity.Property(e => e.ChangeType).HasMaxLength(100);
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<EventError>(entity =>
        {
            entity.HasKey(e => e.EventErrorId).HasName("PK_EventErrorID");

            entity.ToTable("EventError");

            entity.Property(e => e.EventErrorId).HasColumnName("EventErrorID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Data).HasColumnType("xml");
            entity.Property(e => e.ErrorDate).HasColumnType("datetime");
            entity.Property(e => e.ErrorMessage).HasMaxLength(4000);
            entity.Property(e => e.ErrorProcedure).HasMaxLength(126);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<Facility>(entity =>
        {
            entity.HasKey(e => e.FacilityId).HasName("PK_FacilityID");

            entity.ToTable("Facility", "Admin");

            entity.Property(e => e.FacilityId).HasColumnName("FacilityID");
            entity.Property(e => e.Active).HasDefaultValue(true);
            entity.Property(e => e.Address1).HasMaxLength(255);
            entity.Property(e => e.Address2).HasMaxLength(255);
            entity.Property(e => e.City).HasMaxLength(128);
            entity.Property(e => e.Code).HasMaxLength(255);
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Hrisidentifier)
                .HasMaxLength(64)
                .HasColumnName("HRISIdentifier");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.State).HasMaxLength(50);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.Url).HasMaxLength(255);
            entity.Property(e => e.Zip).HasMaxLength(20);
        });

        modelBuilder.Entity<FacilityBusinessEntity>(entity =>
        {
            entity.HasKey(e => e.FacilityBusinessEntityId).HasName("PK_FacilityBusinessEntityID");

            entity.ToTable("FacilityBusinessEntity", "Admin");

            entity.Property(e => e.FacilityBusinessEntityId).HasColumnName("FacilityBusinessEntityID");
            entity.Property(e => e.BusinessEntityId).HasColumnName("BusinessEntityID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.FacilityId).HasColumnName("FacilityID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.BusinessEntity).WithMany(p => p.FacilityBusinessEntities)
                .HasForeignKey(d => d.BusinessEntityId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessEntity_FacilityBusinessEntity_1");

            entity.HasOne(d => d.Facility).WithMany(p => p.FacilityBusinessEntities)
                .HasForeignKey(d => d.FacilityId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Facility_FacilityBusinessEntity_2");
        });

        modelBuilder.Entity<FailedDispositionSyncApplication>(entity =>
        {
            entity.ToTable("FailedDispositionSyncApplication");

            entity.HasIndex(e => e.IndeedApplicationId, "IDX_FailedDispositionSyncApplication_IndeedAppID");

            entity.Property(e => e.FailedDispositionSyncApplicationId).HasColumnName("FailedDispositionSyncApplicationID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.IndeedApplicationId)
                .HasMaxLength(400)
                .HasColumnName("IndeedApplicationID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.ScheduledDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<FailedProviderNewHireApplication>(entity =>
        {
            entity.HasKey(e => e.FailedProviderNewHireApplicationId).HasName("PK_FailedProviderNewHireApplicationID");

            entity.ToTable("FailedProviderNewHireApplication");

            entity.Property(e => e.FailedProviderNewHireApplicationId).HasColumnName("FailedProviderNewHireApplicationID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.NewHireId).HasColumnName("NewHireID");
            entity.Property(e => e.ScheduledDate).HasColumnType("datetime");
            entity.Property(e => e.Suid).HasColumnName("SUID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.NewHire).WithMany(p => p.FailedProviderNewHireApplications)
                .HasForeignKey(d => d.NewHireId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_NewHire_FailedProviderNewHireApplication");
        });

        modelBuilder.Entity<FieldCategory>(entity =>
        {
            entity.HasKey(e => e.FieldCategoryId).HasName("PK__FieldCat__CAC73B1239EB3CD0");

            entity.ToTable("FieldCategory", "Admin");

            entity.HasIndex(e => new { e.Name, e.Deleted }, "IDX_FieldCategory_2").IsUnique();

            entity.Property(e => e.FieldCategoryId).HasColumnName("FieldCategoryID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.ResourceLookupKey).HasMaxLength(100);
            entity.Property(e => e.ResourceManagerKeyId).HasColumnName("ResourceManagerKeyID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<FieldTag>(entity =>
        {
            entity.HasKey(e => e.FieldTagId).HasName("PK__FieldTag__1156B6309B6434D6");

            entity.ToTable("FieldTag", "Admin");

            entity.HasIndex(e => new { e.Deleted, e.Tag }, "IDX_FieldTag_2").IsUnique();

            entity.Property(e => e.FieldTagId).HasColumnName("FieldTagID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DataSourceFieldTypeId).HasColumnName("DataSourceFieldTypeID");
            entity.Property(e => e.FieldCategoryId).HasColumnName("FieldCategoryID");
            entity.Property(e => e.GroupId).HasColumnName("GroupID");
            entity.Property(e => e.IdlookupValueDataSourceFieldTypeId)
                .HasComment("If the tag maps to a related table (see IsDataSourceIDValueLookup) and this fierld is not null, it defines what property/column of the related object is the value and how to lookup the display name. It overrides the default property/column defined by NavPropertyBinding. E.g. For the Requisition field HiringMangerID the related object is of UserProfile type and this field allows defining separate tags for FirstName, LastName and Email. If this field is null, then the value is defined by NavPropertyBinding and display name is defined by MetaTypeID or DataSourceFieldType (see MetaTypeID ).")
                .HasColumnName("IDLookupValueDataSourceFieldTypeID");
            entity.Property(e => e.IsDataSourceIdvalueLookup).HasColumnName("IsDataSourceIDValueLookup");
            entity.Property(e => e.IsGroupTag).HasComment("This bit indicates whethere the tag references a grouped multi-instance  value or single instance value.");
            entity.Property(e => e.ListDataSourceFieldTypeId).HasColumnName("ListDataSourceFieldTypeID");
            entity.Property(e => e.ListLookupValue).HasMaxLength(100);
            entity.Property(e => e.MetaTypeId).HasColumnName("MetaTypeID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.ResourceLookupKey)
                .HasMaxLength(100)
                .HasComment("Lookup key into the resource file that allows to customize the display name of the tag. If not null, this value is checked first. If null, the system will try to take IDLookupValueDataSourceFieldTypeID, etc. \r\n");
            entity.Property(e => e.ResourceManagerKeyId)
                .HasComment("Resource manager key ID for ResourceLookupKey.\r\n")
                .HasColumnName("ResourceManagerKeyID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.Tag).HasMaxLength(150);

            entity.HasOne(d => d.DataSourceFieldType).WithMany(p => p.FieldTagDataSourceFieldTypes)
                .HasForeignKey(d => d.DataSourceFieldTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DataSourceFieldType_FieldTag_3");

            entity.HasOne(d => d.FieldCategory).WithMany(p => p.FieldTags)
                .HasForeignKey(d => d.FieldCategoryId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_FieldCategory_FieldTag_4");

            entity.HasOne(d => d.Group).WithMany(p => p.FieldTags)
                .HasForeignKey(d => d.GroupId)
                .HasConstraintName("FK_ApplicationGroup_FieldTag_7");

            entity.HasOne(d => d.IdlookupValueDataSourceFieldType).WithMany(p => p.FieldTagIdlookupValueDataSourceFieldTypes)
                .HasForeignKey(d => d.IdlookupValueDataSourceFieldTypeId)
                .HasConstraintName("FK_DataSourceFieldType_FieldTag_6");

            entity.HasOne(d => d.ListDataSourceFieldType).WithMany(p => p.FieldTagListDataSourceFieldTypes)
                .HasForeignKey(d => d.ListDataSourceFieldTypeId)
                .HasConstraintName("FK_DataSourceFieldType_FieldTag_1");

            entity.HasOne(d => d.MetaType).WithMany(p => p.FieldTags)
                .HasForeignKey(d => d.MetaTypeId)
                .HasConstraintName("FK_MetaType_FieldTag_5");
        });

        modelBuilder.Entity<Form>(entity =>
        {
            entity.HasKey(e => e.FormId).HasName("PK__Form__FB05B7BD73A4F51E");

            entity.ToTable("Form", "Admin");

            entity.HasIndex(e => new { e.Name, e.FormTypeId, e.Deleted }, "IDX_Form_Name_FormTypeID_Deleted").IsUnique();

            entity.Property(e => e.FormId).HasColumnName("FormID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.FileName).HasMaxLength(255);
            entity.Property(e => e.FormLayoutXml).HasColumnType("xml");
            entity.Property(e => e.FormTypeId).HasColumnName("FormTypeID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.Path).HasMaxLength(255);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.FormType).WithMany(p => p.Forms)
                .HasForeignKey(d => d.FormTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_FormType_Form_1");
        });

        modelBuilder.Entity<FormBusinessEntity>(entity =>
        {
            entity.HasKey(e => e.FormBusinessEntityId).HasName("PK__FormBusi__7457EC8EF32765C3");

            entity.ToTable("FormBusinessEntity", "Admin");

            entity.HasIndex(e => new { e.FormId, e.BusinessEntityId, e.Deleted }, "IDX_FormBusinessEntity_FormID_BusinessEntityID_Deleted").IsUnique();

            entity.Property(e => e.FormBusinessEntityId).HasColumnName("FormBusinessEntityID");
            entity.Property(e => e.BusinessEntityId).HasColumnName("BusinessEntityID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ExpirationDate).HasColumnType("datetime");
            entity.Property(e => e.FormId).HasColumnName("FormID");
            entity.Property(e => e.LiveDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.BusinessEntity).WithMany(p => p.FormBusinessEntities)
                .HasForeignKey(d => d.BusinessEntityId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessEntity_FormBusinessEntity_2");

            entity.HasOne(d => d.Form).WithMany(p => p.FormBusinessEntities)
                .HasForeignKey(d => d.FormId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Form_FormBusinessEntity_1");
        });

        modelBuilder.Entity<FormMetaType>(entity =>
        {
            entity.HasKey(e => e.FormMetaTypeId).HasName("PK__FormMeta__58A86B34C44330AD");

            entity.ToTable("FormMetaType", "Admin");

            entity.HasIndex(e => new { e.FormId, e.MetaTypeId, e.GroupId, e.GroupSequenceId, e.Deleted }, "IDX_FormMetaType_2").IsUnique();

            entity.Property(e => e.FormMetaTypeId).HasColumnName("FormMetaTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.FormId).HasColumnName("FormID");
            entity.Property(e => e.FormatId).HasColumnName("FormatID");
            entity.Property(e => e.GroupId).HasColumnName("GroupID");
            entity.Property(e => e.GroupSequenceId).HasColumnName("GroupSequenceID");
            entity.Property(e => e.InternalNameId).HasColumnName("InternalNameID");
            entity.Property(e => e.LinkFieldTagId).HasColumnName("LinkFieldTagID");
            entity.Property(e => e.MetaTypeId).HasColumnName("MetaTypeID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.Form).WithMany(p => p.FormMetaTypes)
                .HasForeignKey(d => d.FormId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Form_FormMetaType_1");

            entity.HasOne(d => d.Format).WithMany(p => p.FormMetaTypes)
                .HasForeignKey(d => d.FormatId)
                .HasConstraintName("FK_Format_FormMetaType_3");

            entity.HasOne(d => d.MetaType).WithMany(p => p.FormMetaTypes)
                .HasForeignKey(d => d.MetaTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MetaType_FormMetaType_2");
        });

        modelBuilder.Entity<FormMetaTypeAnnotation>(entity =>
        {
            entity.HasKey(e => e.FormMetaTypeAnnotationId).HasName("PK__FormMeta__E63514A7FC2053BE");

            entity.ToTable("FormMetaTypeAnnotation", "Admin");

            entity.HasIndex(e => new { e.FormMetaTypeId, e.AnnotationTypeId }, "IDX_FormMetaTypeAnnotation_2").IsUnique();

            entity.Property(e => e.FormMetaTypeAnnotationId).HasColumnName("FormMetaTypeAnnotationID");
            entity.Property(e => e.AnnotationFormat).HasMaxLength(100);
            entity.Property(e => e.AnnotationTypeId).HasColumnName("AnnotationTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.FormMetaTypeId).HasColumnName("FormMetaTypeID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.AnnotationType).WithMany(p => p.FormMetaTypeAnnotations)
                .HasForeignKey(d => d.AnnotationTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_AnnotationType_FormMetaTypeAnnotation_2");

            entity.HasOne(d => d.FormMetaType).WithMany(p => p.FormMetaTypeAnnotations)
                .HasForeignKey(d => d.FormMetaTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_FormMetaType_FormMetaTypeAnnotation_1");
        });

        modelBuilder.Entity<FormPublished>(entity =>
        {
            entity.HasKey(e => e.FormPublishedId).HasName("PK__FormPubl__46C92573C3A4B645");

            entity.ToTable("FormPublished", "Admin", tb => tb.HasComment("This table FormPublished is higly transacstional and\r\ntherefore it is denormalized from the Form table.\r\nThe Path and FileName fields exist in both this table and the Form table if the Form is published.."));

            entity.HasIndex(e => new { e.FormTypeId, e.BusinessEntityId }, "IDX_FormPublished_BusinessEntityID_FormTypeID").IsUnique();

            entity.Property(e => e.FormPublishedId).HasColumnName("FormPublishedID");
            entity.Property(e => e.BusinessEntityId).HasColumnName("BusinessEntityID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.FileName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.FormId).HasColumnName("FormID");
            entity.Property(e => e.FormTypeId).HasColumnName("FormTypeID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Path).HasMaxLength(255);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.BusinessEntity).WithMany(p => p.FormPublisheds)
                .HasForeignKey(d => d.BusinessEntityId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessEntity_FormPublished_2");

            entity.HasOne(d => d.Form).WithMany(p => p.FormPublisheds)
                .HasForeignKey(d => d.FormId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Form_FormPublished_1");

            entity.HasOne(d => d.FormType).WithMany(p => p.FormPublisheds)
                .HasForeignKey(d => d.FormTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_FormType_FormPublished_3");
        });

        modelBuilder.Entity<FormType>(entity =>
        {
            entity.HasKey(e => e.FormTypeId).HasName("PK__FormType__3177BBA3E678D8AE");

            entity.ToTable("FormType", "Admin");

            entity.Property(e => e.FormTypeId).HasColumnName("FormTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DataSourceFieldTypeId).HasColumnName("DataSourceFieldTypeID");
            entity.Property(e => e.DataSourceTypeId).HasColumnName("DataSourceTypeID");
            entity.Property(e => e.FieldCategoryId).HasColumnName("FieldCategoryID");
            entity.Property(e => e.FormTypeViewModelName)
                .HasMaxLength(100)
                .HasComment("Column FormTypeViewModelName stores the actual ViewModel name of the form to be used in the View.");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.DataSourceFieldType).WithMany(p => p.FormTypes)
                .HasForeignKey(d => d.DataSourceFieldTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DataSourceFieldType_FormType_2");

            entity.HasOne(d => d.DataSourceType).WithMany(p => p.FormTypes)
                .HasForeignKey(d => d.DataSourceTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DataSourceType_FormType_1");

            entity.HasOne(d => d.FieldCategory).WithMany(p => p.FormTypes)
                .HasForeignKey(d => d.FieldCategoryId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_FieldCategory_FormType_3");
        });

        modelBuilder.Entity<FormTypeFieldCategory>(entity =>
        {
            entity.HasKey(e => e.FormTypeFieldCategoryId).HasName("PK__FormType__D8C21BA66C14716F");

            entity.ToTable("FormTypeFieldCategory", "Admin");

            entity.HasIndex(e => new { e.FieldCategoryId, e.FormTypeId, e.Deleted }, "IDX_FormTypeFieldCategory_2").IsUnique();

            entity.Property(e => e.FormTypeFieldCategoryId).HasColumnName("FormTypeFieldCategoryID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.FieldCategoryId).HasColumnName("FieldCategoryID");
            entity.Property(e => e.FormTypeId).HasColumnName("FormTypeID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.FieldCategory).WithMany(p => p.FormTypeFieldCategories)
                .HasForeignKey(d => d.FieldCategoryId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_FieldCategory_FormTypeFieldCategory_1");

            entity.HasOne(d => d.FormType).WithMany(p => p.FormTypeFieldCategories)
                .HasForeignKey(d => d.FormTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_FormType_FormTypeFieldCategory_2");
        });

        modelBuilder.Entity<FormTypeMetaTypeFieldTag>(entity =>
        {
            entity.HasKey(e => e.FormTypeMetaTypeFieldTagId).HasName("PK_FormFieldDataSourceID");

            entity.ToTable("FormTypeMetaTypeFieldTag", "Admin");

            entity.HasIndex(e => new { e.FormTypeId, e.MetaTypeId, e.Deleted, e.FieldTagId }, "IDX_FormTypeMetaTypeFieldTag_2").IsUnique();

            entity.Property(e => e.FormTypeMetaTypeFieldTagId).HasColumnName("FormTypeMetaTypeFieldTagID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.FieldTagId).HasColumnName("FieldTagID");
            entity.Property(e => e.FormTypeId).HasColumnName("FormTypeID");
            entity.Property(e => e.MetaTypeId).HasColumnName("MetaTypeID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.FieldTag).WithMany(p => p.FormTypeMetaTypeFieldTags)
                .HasForeignKey(d => d.FieldTagId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_FieldTag_FormTypeMetaTypeFieldTag_3");

            entity.HasOne(d => d.FormType).WithMany(p => p.FormTypeMetaTypeFieldTags)
                .HasForeignKey(d => d.FormTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_FormType_FormTypeMetaTypeFieldTag_1");

            entity.HasOne(d => d.MetaType).WithMany(p => p.FormTypeMetaTypeFieldTags)
                .HasForeignKey(d => d.MetaTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MetaType_FormTypeMetaTypeFieldTag_2");
        });

        modelBuilder.Entity<Format>(entity =>
        {
            entity.HasKey(e => e.FormatId).HasName("PK__Format__5D3DCB7937AB1C05");

            entity.ToTable("Format", "Admin");

            entity.HasIndex(e => new { e.ControlTypeId, e.Name, e.Deleted }, "IDX_Format_2").IsUnique();

            entity.Property(e => e.FormatId).HasColumnName("FormatID");
            entity.Property(e => e.ControlTypeId).HasColumnName("ControlTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Description).HasMaxLength(255);
            entity.Property(e => e.Mask).HasMaxLength(200);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.ValidationExpression).HasMaxLength(200);

            entity.HasOne(d => d.ControlType).WithMany(p => p.Formats)
                .HasForeignKey(d => d.ControlTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ControlType_Format_1");
        });

        modelBuilder.Entity<GlobalNoteStaging>(entity =>
        {
            entity.HasKey(e => e.GlobalNoteStagingId).HasName("PK_GlobalNoteStagingID");

            entity.ToTable("GlobalNoteStaging");

            entity.HasIndex(e => new { e.GlobalNoteStagingId, e.Deleted }, "IDX__GlobalNoteConverterID").HasFillFactor(80);

            entity.HasIndex(e => new { e.EncryptedSsn, e.TextHashBytes, e.Deleted }, "UX__GlobalNoteConverter__EncryptedSSN__TextHashBytes").IsUnique();

            entity.Property(e => e.GlobalNoteStagingId).HasColumnName("GlobalNoteStagingID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.EncryptedSsn)
                .HasMaxLength(16)
                .IsFixedLength()
                .HasColumnName("EncryptedSSN");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.Text).HasMaxLength(2000);
            entity.Property(e => e.TextHashBytes)
                .HasMaxLength(32)
                .IsFixedLength();
        });

        modelBuilder.Entity<GridColumnDefinition>(entity =>
        {
            entity.HasKey(e => e.GridColumnDefinitionId).HasName("PK_GridColumnDefinitionID");

            entity.ToTable("GridColumnDefinition", "Admin");

            entity.Property(e => e.GridColumnDefinitionId).HasColumnName("GridColumnDefinitionID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.GridColumnDefinitionKey).HasMaxLength(256);
            entity.Property(e => e.GridTypeId).HasColumnName("GridTypeID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.GridType).WithMany(p => p.GridColumnDefinitions)
                .HasForeignKey(d => d.GridTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_GridType_GridColumnDefinition");
        });

        modelBuilder.Entity<GridType>(entity =>
        {
            entity.HasKey(e => e.GridTypeId).HasName("PK_GridTypeID");

            entity.ToTable("GridType", "Admin");

            entity.HasIndex(e => new { e.Name, e.Deleted }, "IDX_DetailSectionType_Name_Deleted").IsUnique();

            entity.HasIndex(e => new { e.Name, e.Deleted }, "IDX_GridType_Name_Deleted").IsUnique();

            entity.Property(e => e.GridTypeId).HasColumnName("GridTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(256);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<HierarchySetting>(entity =>
        {
            entity.HasKey(e => e.HierarchySettingId).HasName("PK_HierarchySettingID");

            entity.ToTable("HierarchySetting", "Admin");

            entity.Property(e => e.HierarchySettingId).HasColumnName("HierarchySettingID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.Value).HasMaxLength(255);
        });

        modelBuilder.Entity<HrXmlMap>(entity =>
        {
            entity.HasKey(e => e.HrXmlMapId).HasName("PK__HrXmlMap__D48BEA4BB147CF35");

            entity.ToTable("HrXmlMap", "Admin");

            entity.HasIndex(e => new { e.Deleted, e.ElementName, e.HrXmlTypeId, e.DataSourceFieldTypeId, e.MetaTypeId, e.SchemaVersion, e.LookupDataSourceFieldTypeId, e.AttributeValue, e.ElementPath }, "IDX_HrXmlMap_2").IsUnique();

            entity.HasIndex(e => new { e.ApplicationGroupId, e.HrXmlTypeId }, "IDX_HrXmlMap_3")
                .IsUnique()
                .HasFilter("([IsGroup]=(1))");

            entity.Property(e => e.HrXmlMapId).HasColumnName("HrXmlMapID");
            entity.Property(e => e.ApplicationGroupId).HasColumnName("ApplicationGroupID");
            entity.Property(e => e.AttributeName).HasMaxLength(128);
            entity.Property(e => e.AttributeValue).HasMaxLength(100);
            entity.Property(e => e.ConditionalElementDataSourceFieldTypeId).HasColumnName("ConditionalElementDataSourceFieldTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DataSourceFieldTypeId).HasColumnName("DataSourceFieldTypeID");
            entity.Property(e => e.ElementName).HasMaxLength(128);
            entity.Property(e => e.ElementPath).HasMaxLength(512);
            entity.Property(e => e.GroupNewParentPath).HasMaxLength(512);
            entity.Property(e => e.HrXmlTypeId).HasColumnName("HrXmlTypeID");
            entity.Property(e => e.IsLookupId).HasColumnName("IsLookupID");
            entity.Property(e => e.LookupDataSourceFieldTypeId).HasColumnName("LookupDataSourceFieldTypeID");
            entity.Property(e => e.MetaTypeId).HasColumnName("MetaTypeID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.MultiElementDataSourceFieldTypeId).HasColumnName("MultiElementDataSourceFieldTypeID");
            entity.Property(e => e.MultiElementLookupValue).HasMaxLength(100);
            entity.Property(e => e.SchemaVersion).HasMaxLength(10);
            entity.Property(e => e.SectionId).HasColumnName("SectionID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.ApplicationGroup).WithMany(p => p.HrXmlMaps)
                .HasForeignKey(d => d.ApplicationGroupId)
                .HasConstraintName("FK_ApplicationGroup_HrXmlMap_3");

            entity.HasOne(d => d.ConditionalElementDataSourceFieldType).WithMany(p => p.HrXmlMapConditionalElementDataSourceFieldTypes)
                .HasForeignKey(d => d.ConditionalElementDataSourceFieldTypeId)
                .HasConstraintName("FK_DataSourceFieldType_HrXmlMap_7");

            entity.HasOne(d => d.DataSourceFieldType).WithMany(p => p.HrXmlMapDataSourceFieldTypes)
                .HasForeignKey(d => d.DataSourceFieldTypeId)
                .HasConstraintName("FK_DataSourceFieldType_HrXmlMap_4");

            entity.HasOne(d => d.HrXmlType).WithMany(p => p.HrXmlMaps)
                .HasForeignKey(d => d.HrXmlTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_HrXmlType_HrXmlMap_2");

            entity.HasOne(d => d.LookupDataSourceFieldType).WithMany(p => p.HrXmlMapLookupDataSourceFieldTypes)
                .HasForeignKey(d => d.LookupDataSourceFieldTypeId)
                .HasConstraintName("FK_DataSourceFieldType_HrXmlMap_8");

            entity.HasOne(d => d.MetaType).WithMany(p => p.HrXmlMaps)
                .HasForeignKey(d => d.MetaTypeId)
                .HasConstraintName("FK_MetaType_HrXmlMap_5");

            entity.HasOne(d => d.MultiElementDataSourceFieldType).WithMany(p => p.HrXmlMapMultiElementDataSourceFieldTypes)
                .HasForeignKey(d => d.MultiElementDataSourceFieldTypeId)
                .HasConstraintName("FK_DataSourceFieldType_HrXmlMap_6");
        });

        modelBuilder.Entity<HrXmlType>(entity =>
        {
            entity.HasKey(e => e.HrXmlTypeId).HasName("PK__HrXmlTyp__A0D24425F31FD364");

            entity.ToTable("HrXmlType", "Admin", tb => tb.HasComment("The HR-XML schema supports many different schema types for Resume, Position, Background Check, Employee Data, etc.  Fields (MetaTypes) in the TMS system can be mapped to 1 or all of these types."));

            entity.HasIndex(e => new { e.Name, e.Deleted }, "IDX_HrXmlType_2").IsUnique();

            entity.Property(e => e.HrXmlTypeId).HasColumnName("HrXmlTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<HrarequisitionLock>(entity =>
        {
            entity.HasKey(e => e.HrarequisitionLockId).HasName("PK_HRARequisitionLockID");

            entity.ToTable("HRARequisitionLock");

            entity.HasIndex(e => new { e.RequisitionId, e.Deleted }, "IDX_HRARequisitionLock_1").IsUnique();

            entity.Property(e => e.HrarequisitionLockId).HasColumnName("HRARequisitionLockID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.RequisitionId).HasColumnName("RequisitionID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.Requisition).WithMany(p => p.HrarequisitionLocks)
                .HasForeignKey(d => d.RequisitionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Requisition_HRARequisitionLock_1");
        });

        modelBuilder.Entity<HrisimportProtectedRecord>(entity =>
        {
            entity.HasKey(e => e.HrisimportProtectedRecordsId).HasName("PK__HRISImpo__760A33BD6AB6F101");

            entity.ToTable("HRISImportProtectedRecords");

            entity.HasIndex(e => new { e.HrisfileTypeId, e.BusinessObjectId, e.Deleted }, "IDX_HRISImportProtectedRecords_Unique").IsUnique();

            entity.Property(e => e.HrisimportProtectedRecordsId).HasColumnName("HRISImportProtectedRecordsId");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.HrisfileTypeId).HasColumnName("HRISFileTypeId");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<IdentityBusinessEntityMapping>(entity =>
        {
            entity.HasKey(e => e.IdentityBusinessEntityMappingId).HasName("PK_IdentityBusinessEntityMappingID");

            entity.ToTable("IdentityBusinessEntityMapping", "Admin");

            entity.HasIndex(e => new { e.Identifier, e.Deleted }, "IDX_IdentityBusinessEntityMapping_2").IsUnique();

            entity.Property(e => e.IdentityBusinessEntityMappingId).HasColumnName("IdentityBusinessEntityMappingID");
            entity.Property(e => e.BusinessEntityId).HasColumnName("BusinessEntityID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Identifier).HasMaxLength(100);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.BusinessEntity).WithMany(p => p.IdentityBusinessEntityMappings)
                .HasForeignKey(d => d.BusinessEntityId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessEntity_IdentityBusinessEntityMapping_1");
        });

        modelBuilder.Entity<ImpersonationAudit>(entity =>
        {
            entity.HasKey(e => e.ImpersonationAuditId).HasName("PK_ImpersonationAuditID");

            entity.ToTable("ImpersonationAudit", "Auth");

            entity.Property(e => e.ImpersonationAuditId).HasColumnName("ImpersonationAuditID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ImpersonatedAsUserId).HasColumnName("ImpersonatedAsUserID");
            entity.Property(e => e.ImpersonationUserId).HasColumnName("ImpersonationUserID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.ImpersonatedAsUser).WithMany(p => p.ImpersonationAuditImpersonatedAsUsers)
                .HasForeignKey(d => d.ImpersonatedAsUserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TMSUser_ImpersonatedAsUserID");

            entity.HasOne(d => d.ImpersonationUser).WithMany(p => p.ImpersonationAuditImpersonationUsers)
                .HasForeignKey(d => d.ImpersonationUserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TMSUser_ImpersonationUserID");
        });

        modelBuilder.Entity<IndexLog>(entity =>
        {
            entity.HasKey(e => e.IndexLogId).HasName("PK_IndexLogID");

            entity.ToTable("IndexLog");

            entity.Property(e => e.IndexLogId).HasColumnName("IndexLogID");
            entity.Property(e => e.ContextId).HasColumnName("ContextID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.IndexEnd).HasColumnType("datetime");
            entity.Property(e => e.IndexStart).HasColumnType("datetime");
            entity.Property(e => e.IndexTypeId).HasColumnName("IndexTypeID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.IndexType).WithMany(p => p.IndexLogs)
                .HasForeignKey(d => d.IndexTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_IndexType_IndexLog_1");
        });

        modelBuilder.Entity<IndexType>(entity =>
        {
            entity.ToTable("IndexType");

            entity.Property(e => e.IndexTypeId).HasColumnName("IndexTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Description).HasMaxLength(100);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(50);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<Interview>(entity =>
        {
            entity.HasKey(e => e.InterviewId).HasName("PK__Intervie__C97C5832294DC9F2");

            entity.ToTable("Interview");

            entity.HasIndex(e => new { e.InterviewId, e.Deleted }, "IDX_Interview_unique").IsUnique();

            entity.Property(e => e.InterviewId).HasColumnName("InterviewID");
            entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");
            entity.Property(e => e.ConfirmedDate).HasColumnType("datetime");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.MeetingId)
                .HasMaxLength(200)
                .HasColumnName("MeetingID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.OrganizerId).HasColumnName("OrganizerID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.Application).WithMany(p => p.Interviews)
                .HasForeignKey(d => d.ApplicationId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Application_Interview_1");

            entity.HasOne(d => d.Organizer).WithMany(p => p.Interviews)
                .HasForeignKey(d => d.OrganizerId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TMSUser_Interview_1");
        });

        modelBuilder.Entity<InterviewParticipant>(entity =>
        {
            entity.HasKey(e => e.InterviewParticipantId).HasName("PK__Intervie__DB9AD5E75CB200C6");

            entity.ToTable("InterviewParticipant");

            entity.HasIndex(e => new { e.InterviewParticipantId, e.Deleted }, "IDX_InterviewParticipant_unique").IsUnique();

            entity.Property(e => e.InterviewParticipantId).HasColumnName("InterviewParticipantID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.InterviewId).HasColumnName("InterviewID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");

            entity.HasOne(d => d.Interview).WithMany(p => p.InterviewParticipants)
                .HasForeignKey(d => d.InterviewId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Interview_InterviewParticipant_1");

            entity.HasOne(d => d.Tmsuser).WithMany(p => p.InterviewParticipants)
                .HasForeignKey(d => d.TmsuserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TMSUser_InterviewParticipant_1");
        });

        modelBuilder.Entity<InterviewUser>(entity =>
        {
            entity.HasKey(e => e.InterviewUserId).HasName("PK__Intervie__963FD02CA4DCAEFC");

            entity.ToTable("InterviewUser");

            entity.HasIndex(e => new { e.TmsuserId, e.Deleted }, "IDX_InterviewUser").IsUnique();

            entity.Property(e => e.InterviewUserId).HasColumnName("InterviewUserID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.CronofyId)
                .HasMaxLength(100)
                .HasColumnName("CronofyID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");

            entity.HasOne(d => d.Tmsuser).WithMany(p => p.InterviewUsers)
                .HasForeignKey(d => d.TmsuserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TMSUser_InterviewUser");
        });

        modelBuilder.Entity<JobDistributionJobInfo>(entity =>
        {
            entity.HasKey(e => e.JobDistributionJobInfoId).HasName("PK__JobDistr__FE712C89C040242E");

            entity.ToTable("JobDistributionJobInfo");

            entity.Property(e => e.JobDistributionJobInfoId).HasColumnName("JobDistributionJobInfoID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.JobDistributionJobId).HasColumnName("JobDistributionJobID");
            entity.Property(e => e.JobPostingId).HasColumnName("JobPostingID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.VendorId).HasColumnName("VendorID");

            entity.HasOne(d => d.InitiatedUserNavigation).WithMany(p => p.JobDistributionJobInfos)
                .HasForeignKey(d => d.InitiatedUser)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TMSUser_JobDistributionJobInfo");

            entity.HasOne(d => d.JobPosting).WithMany(p => p.JobDistributionJobInfos)
                .HasForeignKey(d => d.JobPostingId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobPosting_JobDistributionJobInfo");

            entity.HasOne(d => d.Vendor).WithMany(p => p.JobDistributionJobInfos)
                .HasForeignKey(d => d.VendorId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Vendor_JobDistributionJobInfo");
        });

        modelBuilder.Entity<JobDistributionJobSync>(entity =>
        {
            entity.HasKey(e => e.JobDistributionJobSyncId).HasName("PK__JobDistr__0885387BDA424C02");

            entity.ToTable("JobDistributionJobSync");

            entity.Property(e => e.JobDistributionJobSyncId).HasColumnName("JobDistributionJobSyncID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.LastSyncDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.VendorId).HasColumnName("VendorID");

            entity.HasOne(d => d.Vendor).WithMany(p => p.JobDistributionJobSyncs)
                .HasForeignKey(d => d.VendorId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Vendor_JobDistributionJobSync");
        });

        modelBuilder.Entity<JobDistributionPostingInfo>(entity =>
        {
            entity.HasKey(e => e.JobDistributionPostingInfoId).HasName("PK__JobDistr__02789EA5FC363E8A");

            entity.ToTable("JobDistributionPostingInfo");

            entity.Property(e => e.JobDistributionPostingInfoId).HasColumnName("JobDistributionPostingInfoID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ExpirationDate).HasColumnType("datetime");
            entity.Property(e => e.Incomplete).HasDefaultValue(false);
            entity.Property(e => e.JobBoardStatus).HasMaxLength(100);
            entity.Property(e => e.JobDistributionJobInfoId).HasColumnName("JobDistributionJobInfoID");
            entity.Property(e => e.JobDistributionPostingId).HasColumnName("JobDistributionPostingID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.OrderDate).HasColumnType("datetime");
            entity.Property(e => e.SiteName).HasMaxLength(200);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TotalCost).HasMaxLength(200);

            entity.HasOne(d => d.JobDistributionJobInfo).WithMany(p => p.JobDistributionPostingInfos)
                .HasForeignKey(d => d.JobDistributionJobInfoId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobDistrbutionJobInfo_JobDistributionPostingInfo");
        });

        modelBuilder.Entity<JobDistributionVendorApplication>(entity =>
        {
            entity.HasKey(e => e.JobDistributionVendorApplicationId).HasName("PK__JobDistr__23C5A5D59AC101B9");

            entity.ToTable("JobDistributionVendorApplication");

            entity.Property(e => e.JobDistributionVendorApplicationId).HasColumnName("JobDistributionVendorApplicationID");
            entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.VendorApplicationTrackingId)
                .HasMaxLength(200)
                .HasColumnName("VendorApplicationTrackingID");
            entity.Property(e => e.VendorId).HasColumnName("VendorID");

            entity.HasOne(d => d.Application).WithMany(p => p.JobDistributionVendorApplications)
                .HasForeignKey(d => d.ApplicationId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Application_JobDistributionVendorApplication");

            entity.HasOne(d => d.Vendor).WithMany(p => p.JobDistributionVendorApplications)
                .HasForeignKey(d => d.VendorId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Vendor_JobDistributionVendorApplication");
        });

        modelBuilder.Entity<JobFamily>(entity =>
        {
            entity.HasKey(e => e.JobFamilyId).HasName("PK_JobFamilyID");

            entity.ToTable("JobFamily", "Admin");

            entity.HasIndex(e => new { e.JobFamilyIdentifier, e.JobFamilyAttribute, e.Deleted }, "IDX_JobFamily_JobFamilyIdentifierAttributeDeleted").IsUnique();

            entity.HasIndex(e => new { e.Name, e.Deleted }, "IDX_JobFamily_NameDeleted").IsUnique();

            entity.Property(e => e.JobFamilyId).HasColumnName("JobFamilyID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.JobFamilyAttribute).HasMaxLength(2);
            entity.Property(e => e.JobFamilyIdentifier).HasMaxLength(50);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.NoExpJobFamilyId)
                .HasDefaultValueSql("(NULL)")
                .HasColumnName("NoExpJobFamilyID");
            entity.Property(e => e.ParentId).HasColumnName("ParentID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.VendorId).HasColumnName("VendorID");

            entity.HasOne(d => d.Vendor).WithMany(p => p.JobFamilies)
                .HasForeignKey(d => d.VendorId)
                .HasConstraintName("FK__JobFamily_Vendor");
        });

        modelBuilder.Entity<JobPosting>(entity =>
        {
            entity.HasKey(e => e.JobPostingId).HasName("PK_JobPostingID");

            entity.ToTable("JobPosting");

            entity.HasIndex(e => new { e.Active, e.Deleted }, "IDX_Active").HasFillFactor(80);

            entity.HasIndex(e => e.JobPostingId, "IDX_JobPosting_Cover");

            entity.HasIndex(e => new { e.RequisitionId, e.Deleted }, "IDX_JobPosting_Requisition_Deleted").IsUnique();

            entity.Property(e => e.JobPostingId).HasColumnName("JobPostingID");
            entity.Property(e => e.BusinessEntityId).HasColumnName("BusinessEntityID");
            entity.Property(e => e.ContactUserId).HasColumnName("ContactUserID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.EndDate).HasColumnType("datetime");
            entity.Property(e => e.EndInternalOnlyDate).HasColumnType("datetime");
            entity.Property(e => e.FormId).HasColumnName("FormID");
            entity.Property(e => e.JobCategoryId)
                .HasComment("Maps to MetaValue.MetaValueID")
                .HasColumnName("JobCategoryID");
            entity.Property(e => e.JobPostingLocationId).HasColumnName("JobPostingLocationID");
            entity.Property(e => e.JobSummary).HasComment("JobSummary stores the summary of the job description to be displayed on a job board (CareerSite). This field is initialized from the JobSummary field of the JobTemplateInstance of the Requisition and allows customizing the summary for this posting without affecting the Requisition or other JobPosting records.");
            entity.Property(e => e.JobTargetJobId).HasColumnName("JobTargetJobID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.NationalJobCategoryId)
                .HasComment("Implied foreign key to TMSSecurity.dbo.NationalJobCategory.NationalJobCategoryID.\r\n\r\nA populated value on a JobPosting record indicates what Nation Job Category a given JobPosting should appear under.")
                .HasColumnName("NationalJobCategoryID");
            entity.Property(e => e.PostToHcsjobBoard).HasColumnName("PostToHCSJobBoard");
            entity.Property(e => e.RecruiterAlertOnApplicationSubmission).HasComment("RecruiterAlertOnApplicationSubmission. Checkbox when turned on sends 'Send Applicant Apply Email Alert'\r\n\r\n");
            entity.Property(e => e.RequisitionId).HasColumnName("RequisitionID");
            entity.Property(e => e.StartDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.Title).HasMaxLength(100);

            entity.HasOne(d => d.BusinessEntity).WithMany(p => p.JobPostings)
                .HasForeignKey(d => d.BusinessEntityId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessEntity_JobPosting_9");

            entity.HasOne(d => d.ContactUser).WithMany(p => p.JobPostingContactUsers)
                .HasForeignKey(d => d.ContactUserId)
                .HasConstraintName("FK_UserProfile_JobPosting_11");

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.JobPostingCreatedByNavigations)
                .HasForeignKey(d => d.CreatedBy)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_UserProfile_JobPosting_CreatedBy");

            entity.HasOne(d => d.Form).WithMany(p => p.JobPostings)
                .HasForeignKey(d => d.FormId)
                .HasConstraintName("FK_Form_JobPosting_6");

            entity.HasOne(d => d.JobCategory).WithMany(p => p.JobPostings)
                .HasForeignKey(d => d.JobCategoryId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MetaValue_JobPosting_10");

            entity.HasOne(d => d.JobPostingLocation).WithMany(p => p.JobPostings)
                .HasForeignKey(d => d.JobPostingLocationId)
                .HasConstraintName("FK__JobPostingLocation");

            entity.HasOne(d => d.Requisition).WithMany(p => p.JobPostings)
                .HasForeignKey(d => d.RequisitionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Requisition_JobPosting_2");
        });

        modelBuilder.Entity<JobPostingBusinessEntity>(entity =>
        {
            entity.HasKey(e => e.JobPostingBusinessEntityId).HasName("PK_JobPostingBusinessEntityID");

            entity.ToTable("JobPostingBusinessEntity");

            entity.HasIndex(e => new { e.JobPostingId, e.BusinessEntityId, e.BusinessEntityTypeId, e.Deleted }, "IDX_JobPostingBusinessEntity").HasFillFactor(80);

            entity.Property(e => e.JobPostingBusinessEntityId).HasColumnName("JobPostingBusinessEntityID");
            entity.Property(e => e.BusinessEntityId).HasColumnName("BusinessEntityID");
            entity.Property(e => e.BusinessEntityTypeId).HasColumnName("BusinessEntityTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DisplayName).HasMaxLength(100);
            entity.Property(e => e.JobPostingId).HasColumnName("JobPostingID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.BusinessEntity).WithMany(p => p.JobPostingBusinessEntities)
                .HasForeignKey(d => d.BusinessEntityId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessEntity_JobPostingBusinessEntity_2");

            entity.HasOne(d => d.BusinessEntityType).WithMany(p => p.JobPostingBusinessEntities)
                .HasForeignKey(d => d.BusinessEntityTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessEntityType_JobPostingBusinessEntity_3");

            entity.HasOne(d => d.JobPosting).WithMany(p => p.JobPostingBusinessEntities)
                .HasForeignKey(d => d.JobPostingId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobPosting_JobPostingBusinessEntity_1");
        });

        modelBuilder.Entity<JobPostingFieldValue>(entity =>
        {
            entity.HasKey(e => e.JobPostingFieldValueId).HasName("PK__JobPosti__3AF167599773D822");

            entity.ToTable("JobPostingFieldValue");

            entity.HasIndex(e => new { e.JobPostingId, e.MetaTypeId, e.MetaValueId, e.GroupId, e.GroupSequenceId, e.ValueInstanceId, e.Deleted }, "IDX_JobPostingFieldValue_2").IsUnique();

            entity.Property(e => e.JobPostingFieldValueId).HasColumnName("JobPostingFieldValueID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.GroupId)
                .HasComment("GroupID, GroupSequenceID and ValueInstanceID go hand in hand to define and store Multi Instance Data values with Multiple Values. \r\nGroupID Identifies which group it is.\r\ne.g. 1 is LicenseFields group\r\n2 is EducationGroup\r\n3 is WorkHistory group etc.\r\n\r\nGroupSequenceID identifies the instance of a group.\r\ne.g. if there are 5 licences, first license groupsequenceID is 1, second is 2, third is 3, fourth is 4 and fifth is 5.\r\n\r\nValueInstanceID identifies and stores the multiple values of a metatypeid from the value list. e.g. Skills matrix.. Multiple possible are 1-20, but the selected user values ar 5,11,19 etc.\r\n\r\nThe GroupID and SequenceID are for multiinstance data like the License and its child fields like LicenseState/LicenceName.\r\n\r\nE.g. 3 License details collected will be in GroupIDs 1,2 and 3. Each element values of each Group would have a order collected in Sequence.\r\n\r\n\r\n\r\nMetaTypeID 	GroupId 	SequenceId\r\n1         	                1              	1\r\n1        	                1 		2          \r\n1		1		3\r\n1		2		1\r\n1		2		2\r\n1		2		3\r\n")
                .HasColumnName("GroupID");
            entity.Property(e => e.GroupSequenceId)
                .HasComment("GroupID, GroupSequenceID and ValueInstanceID go hand in hand to define and store Multi Instance Data values with Multiple Values. \r\nGroupID Identifies which group it is.\r\ne.g. 1 is LicenseFields group\r\n2 is EducationGroup\r\n3 is WorkHistory group etc.\r\n\r\nGroupSequenceID identifies the instance of a group.\r\ne.g. if there are 5 licences, first license groupsequenceID is 1, second is 2, third is 3, fourth is 4 and fifth is 5.\r\n\r\nValueInstanceID identifies and stores the multiple values of a metatypeid from the value list. e.g. Skills matrix.. Multiple possible are 1-20, but the selected user values ar 5,11,19 etc.\r\n\r\nThe GroupID and SequenceID are for multiinstance data like the License and its child fields like LicenseState/LicenceName.\r\n\r\nE.g. 3 License details collected will be in GroupIDs 1,2 and 3. Each element values of each Group would have a order collected in Sequence.\r\n\r\n\r\n\r\nMetaTypeID 	GroupId 	SequenceId\r\n1         	                1              	1\r\n1        	                1 		2          \r\n1		1		3\r\n1		2		1\r\n1		2		2\r\n1		2		3\r\n")
                .HasColumnName("GroupSequenceID");
            entity.Property(e => e.JobPostingId).HasColumnName("JobPostingID");
            entity.Property(e => e.MetaTypeId).HasColumnName("MetaTypeID");
            entity.Property(e => e.MetaValueId).HasColumnName("MetaValueID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsdataTypeId).HasColumnName("TMSDataTypeID");
            entity.Property(e => e.ValueDate).HasColumnType("datetime");
            entity.Property(e => e.ValueInstanceId)
                .HasComment("GroupID, GroupSequenceID and ValueInstanceID go hand in hand to define and store Multi Instance Data values with Multiple Values. \r\nGroupID Identifies which group it is.\r\ne.g. 1 is LicenseFields group\r\n2 is EducationGroup\r\n3 is WorkHistory group etc.\r\n\r\nGroupSequenceID identifies the instance of a group.\r\ne.g. if there are 5 licences, first license groupsequenceID is 1, second is 2, third is 3, fourth is 4 and fifth is 5.\r\n\r\nValueInstanceID identifies and stores the multiple values of a metatypeid from the value list. e.g. Skills matrix.. Multiple possible are 1-20, but the selected user values ar 5,11,19 etc.\r\n\r\nThe GroupID and SequenceID are for multiinstance data like the License and its child fields like LicenseState/LicenceName.\r\n\r\nE.g. 3 License details collected will be in GroupIDs 1,2 and 3. Each element values of each Group would have a order collected in Sequence.\r\n\r\n\r\n\r\nMetaTypeID 	GroupId 	SequenceId\r\n1         	                1              	1\r\n1        	                1 		2          \r\n1		1		3\r\n1		2		1\r\n1		2		2\r\n1		2		3\r\n")
                .HasColumnName("ValueInstanceID");
            entity.Property(e => e.ValueText).IsUnicode(false);

            entity.HasOne(d => d.JobPosting).WithMany(p => p.JobPostingFieldValues)
                .HasForeignKey(d => d.JobPostingId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobPosting_JobPostingFieldValue_1");

            entity.HasOne(d => d.MetaType).WithMany(p => p.JobPostingFieldValues)
                .HasForeignKey(d => d.MetaTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MetaType_JobPostingFieldValue_2");

            entity.HasOne(d => d.MetaValue).WithMany(p => p.JobPostingFieldValues)
                .HasForeignKey(d => d.MetaValueId)
                .HasConstraintName("FK_MetaValue_JobPostingFieldValue_3");

            entity.HasOne(d => d.TmsdataType).WithMany(p => p.JobPostingFieldValues)
                .HasForeignKey(d => d.TmsdataTypeId)
                .HasConstraintName("FK_TMSDataType_JobPostingFieldValue_4");
        });

        modelBuilder.Entity<JobPostingLocation>(entity =>
        {
            entity.HasKey(e => e.JobPostingLocationId).HasName("PK_JobPostingLocationID");

            entity.ToTable("JobPostingLocation");

            entity.Property(e => e.JobPostingLocationId).HasColumnName("JobPostingLocationID");
            entity.Property(e => e.Address1)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Address2)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.City)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Latitude).HasColumnType("decimal(9, 6)");
            entity.Property(e => e.Longitude).HasColumnType("decimal(9, 6)");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.State)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.ZipCode)
                .HasMaxLength(10)
                .IsUnicode(false);
        });

        modelBuilder.Entity<JobPostingVendor>(entity =>
        {
            entity.HasKey(e => e.JobPostingVendorId).HasName("PK_JobPostingVendorID");

            entity.ToTable("JobPostingVendor");

            entity.HasIndex(e => new { e.JobPostingId, e.Deleted }, "IDX_JobPostingVendor_JobPostingID_Deleted");

            entity.Property(e => e.JobPostingVendorId).HasColumnName("JobPostingVendorID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.JobPostingId).HasColumnName("JobPostingID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.VendorId).HasColumnName("VendorID");

            entity.HasOne(d => d.JobPosting).WithMany(p => p.JobPostingVendors)
                .HasForeignKey(d => d.JobPostingId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobPosting_JobPostingVendor_1");

            entity.HasOne(d => d.Vendor).WithMany(p => p.JobPostingVendors)
                .HasForeignKey(d => d.VendorId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Vendor_JobPostingVendor_2");
        });

        modelBuilder.Entity<JobPostingView>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("JobPostingView");

            entity.Property(e => e.Address).HasMaxLength(50);
            entity.Property(e => e.BusinessEntityId).HasColumnName("BusinessEntityID");
            entity.Property(e => e.CategoryMetaTypeId).HasColumnName("CategoryMetaTypeID");
            entity.Property(e => e.CategoryMetaValueId).HasColumnName("CategoryMetaValueID");
            entity.Property(e => e.CategoryName).HasMaxLength(100);
            entity.Property(e => e.City).HasMaxLength(50);
            entity.Property(e => e.Code).HasMaxLength(100);
            entity.Property(e => e.ContactFirstName).HasMaxLength(100);
            entity.Property(e => e.ContactLastName).HasMaxLength(100);
            entity.Property(e => e.EducationMetaTypeId).HasColumnName("EducationMetaTypeID");
            entity.Property(e => e.EducationMetaValueId).HasColumnName("EducationMetaValueID");
            entity.Property(e => e.EducationName).HasMaxLength(100);
            entity.Property(e => e.EmailAddress).HasMaxLength(256);
            entity.Property(e => e.EndDate).HasColumnType("datetime");
            entity.Property(e => e.EndInternalOnlyDate).HasColumnType("datetime");
            entity.Property(e => e.FaxNumber).HasMaxLength(24);
            entity.Property(e => e.FormId).HasColumnName("FormID");
            entity.Property(e => e.Fte).HasColumnName("FTE");
            entity.Property(e => e.Hours).HasMaxLength(100);
            entity.Property(e => e.JobCategoryId).HasColumnName("JobCategoryID");
            entity.Property(e => e.JobPostingId).HasColumnName("JobPostingID");
            entity.Property(e => e.JobTemplateInstanceId).HasColumnName("JobTemplateInstanceID");
            entity.Property(e => e.LocationAddress1)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.LocationAddress2)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.LocationCity)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.LocationLatitude).HasColumnType("decimal(9, 6)");
            entity.Property(e => e.LocationLongitude).HasColumnType("decimal(9, 6)");
            entity.Property(e => e.LocationState)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.LocationZipCode)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.PayGrade).HasMaxLength(100);
            entity.Property(e => e.PhoneNumber).HasMaxLength(24);
            entity.Property(e => e.RequisitionId).HasColumnName("RequisitionID");
            entity.Property(e => e.RequisitionNumber).HasMaxLength(30);
            entity.Property(e => e.SalaryRange).HasMaxLength(100);
            entity.Property(e => e.ScheduleId).HasColumnName("ScheduleID");
            entity.Property(e => e.ScheduleMetaTypeId).HasColumnName("ScheduleMetaTypeID");
            entity.Property(e => e.ScheduleMetaValueId).HasColumnName("ScheduleMetaValueID");
            entity.Property(e => e.ScheduleName).HasMaxLength(100);
            entity.Property(e => e.ShiftId).HasColumnName("ShiftID");
            entity.Property(e => e.ShiftMetaTypeId).HasColumnName("ShiftMetaTypeID");
            entity.Property(e => e.ShiftMetaValueId).HasColumnName("ShiftMetaValueID");
            entity.Property(e => e.ShiftName).HasMaxLength(100);
            entity.Property(e => e.StartDate).HasColumnType("datetime");
            entity.Property(e => e.State).HasMaxLength(50);
            entity.Property(e => e.Title).HasMaxLength(100);
            entity.Property(e => e.Zipcode).HasMaxLength(10);
        });

        modelBuilder.Entity<JobTemplate>(entity =>
        {
            entity.HasKey(e => e.JobTemplateId).HasName("PK_JobTemplateID");

            entity.ToTable("JobTemplate", "Admin");

            entity.HasIndex(e => new { e.Hrisidentifier, e.Deleted }, "IDX_JobTemplate_2")
                .IsUnique()
                .HasFilter("([HRISIdentifier] IS NOT NULL)");

            entity.Property(e => e.JobTemplateId).HasColumnName("JobTemplateID");
            entity.Property(e => e.AssessmentPackageId).HasColumnName("AssessmentPackageID");
            entity.Property(e => e.AutoInviteBackTemplateId).HasColumnName("AutoInviteBackTemplateID");
            entity.Property(e => e.BehavioralAssessmentVendorId).HasColumnName("BehavioralAssessmentVendorID");
            entity.Property(e => e.BehavioralAssessmentVendorOfferingId).HasColumnName("BehavioralAssessmentVendorOfferingID");
            entity.Property(e => e.CategoryId).HasColumnName("CategoryID");
            entity.Property(e => e.Code).HasMaxLength(100);
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.EducationId).HasColumnName("EducationID");
            entity.Property(e => e.EeojobGroupId).HasColumnName("EEOJobGroupID");
            entity.Property(e => e.ExternalEmailReplyTemplateId).HasColumnName("ExternalEmailReplyTemplateID");
            entity.Property(e => e.FormId).HasColumnName("FormID");
            entity.Property(e => e.Hours).HasMaxLength(100);
            entity.Property(e => e.Hrisidentifier)
                .HasMaxLength(64)
                .HasComment("HRIS ID for data migration to tie back to source of datafeed")
                .HasColumnName("HRISIdentifier");
            entity.Property(e => e.InternalEmailReplyTemplateId).HasColumnName("InternalEmailReplyTemplateID");
            entity.Property(e => e.JobFamilyId).HasColumnName("JobFamilyID");
            entity.Property(e => e.JobPostingTitle).HasMaxLength(100);
            entity.Property(e => e.JobStatusId).HasColumnName("JobStatusID");
            entity.Property(e => e.KnowledgeSkillsAbilities).HasMaxLength(1000);
            entity.Property(e => e.LeanCapitalJobFamilyTypeId).HasColumnName("LeanCapitalJobFamilyTypeID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.NationalJobCategoryId)
                .HasComment("Implied foreign key to TMSSecurity.dbo.NationalJobCategory.NationalJobCategoryID.\r\n\r\nA populated value on a JobTemplate record indicates what Nation Job Category a given JobTemplate should appear under.")
                .HasColumnName("NationalJobCategoryID");
            entity.Property(e => e.PayGradeId).HasColumnName("PayGradeID");
            entity.Property(e => e.PostingBrandingHierarchyLevelId)
                .HasDefaultValue(-1)
                .HasColumnName("PostingBrandingHierarchyLevelID");
            entity.Property(e => e.PreQualMessageTemplateId).HasColumnName("PreQualMessageTemplateID");
            entity.Property(e => e.PreQualificationQuestionnaireId).HasColumnName("PreQualificationQuestionnaireID");
            entity.Property(e => e.RankingQuestionnaireId).HasColumnName("RankingQuestionnaireID");
            entity.Property(e => e.ReferenceAssessmentDivisionId).HasColumnName("ReferenceAssessmentDivisionID");
            entity.Property(e => e.ReferenceAssessmentVendorOfferingId).HasColumnName("ReferenceAssessmentVendorOfferingID");
            entity.Property(e => e.ReferenceAssessmentWorkforceSegmentId).HasColumnName("ReferenceAssessmentWorkforceSegmentID");
            entity.Property(e => e.ReferenceBenchmarkTypeId).HasColumnName("ReferenceBenchmarkTypeID");
            entity.Property(e => e.SalaryRangeId).HasColumnName("SalaryRangeID");
            entity.Property(e => e.ScheduleId).HasColumnName("ScheduleID");
            entity.Property(e => e.ShiftId).HasColumnName("ShiftID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.UseDefaultShortApplyEmailReplyTemplate).HasDefaultValue(true);

            entity.HasOne(d => d.AssessmentPackage).WithMany(p => p.JobTemplates)
                .HasForeignKey(d => d.AssessmentPackageId)
                .HasConstraintName("FK_AssessmentPackage_JobTemplate_17");

            entity.HasOne(d => d.AutoInviteBackTemplate).WithMany(p => p.JobTemplateAutoInviteBackTemplates)
                .HasForeignKey(d => d.AutoInviteBackTemplateId)
                .HasConstraintName("FK_Template_JobTemplate_18");

            entity.HasOne(d => d.BehavioralAssessmentVendor).WithMany(p => p.JobTemplates)
                .HasForeignKey(d => d.BehavioralAssessmentVendorId)
                .HasConstraintName("FK_Vendor_JobTemplate_19");

            entity.HasOne(d => d.Category).WithMany(p => p.JobTemplateCategories)
                .HasForeignKey(d => d.CategoryId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MetaValue_JobTemplate_1");

            entity.HasOne(d => d.Education).WithMany(p => p.JobTemplateEducations)
                .HasForeignKey(d => d.EducationId)
                .HasConstraintName("FK_MetaValue_JobTemplate_2");

            entity.HasOne(d => d.EeojobGroup).WithMany(p => p.JobTemplateEeojobGroups)
                .HasForeignKey(d => d.EeojobGroupId)
                .HasConstraintName("FK_MetaValue_JobTemplate_4");

            entity.HasOne(d => d.ExternalEmailReplyTemplate).WithMany(p => p.JobTemplateExternalEmailReplyTemplates)
                .HasForeignKey(d => d.ExternalEmailReplyTemplateId)
                .HasConstraintName("FK_Template_JobTemplate_16");

            entity.HasOne(d => d.Form).WithMany(p => p.JobTemplates)
                .HasForeignKey(d => d.FormId)
                .HasConstraintName("FK_Form_JobTemplate_20");

            entity.HasOne(d => d.InternalEmailReplyTemplate).WithMany(p => p.JobTemplateInternalEmailReplyTemplates)
                .HasForeignKey(d => d.InternalEmailReplyTemplateId)
                .HasConstraintName("FK_Template_JobTemplate_15");

            entity.HasOne(d => d.JobFamily).WithMany(p => p.JobTemplates)
                .HasForeignKey(d => d.JobFamilyId)
                .HasConstraintName("FK_JobFamily_JobTemplate_18");

            entity.HasOne(d => d.JobStatus).WithMany(p => p.JobTemplateJobStatuses)
                .HasForeignKey(d => d.JobStatusId)
                .HasConstraintName("FK_MetaValue_JobTemplate_13");

            entity.HasOne(d => d.LeanCapitalJobFamilyType).WithMany(p => p.JobTemplates)
                .HasForeignKey(d => d.LeanCapitalJobFamilyTypeId)
                .HasConstraintName("FK_LeanCapitalJobFamilyTypeID_JobTemplate");

            entity.HasOne(d => d.PayGrade).WithMany(p => p.JobTemplatePayGrades)
                .HasForeignKey(d => d.PayGradeId)
                .HasConstraintName("FK_MetaValue_JobTemplate_6");

            entity.HasOne(d => d.PostingBrandingHierarchyLevel).WithMany(p => p.JobTemplates)
                .HasForeignKey(d => d.PostingBrandingHierarchyLevelId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessEntityType_JobTemplate_19");

            entity.HasOne(d => d.PreQualMessageTemplate).WithMany(p => p.JobTemplatePreQualMessageTemplates)
                .HasForeignKey(d => d.PreQualMessageTemplateId)
                .HasConstraintName("FK_Template_JobTemplate_14");

            entity.HasOne(d => d.PreQualificationQuestionnaire).WithMany(p => p.JobTemplatePreQualificationQuestionnaires)
                .HasForeignKey(d => d.PreQualificationQuestionnaireId)
                .HasConstraintName("FK_Questionnaire_JobTemplate_10");

            entity.HasOne(d => d.RankingQuestionnaire).WithMany(p => p.JobTemplateRankingQuestionnaires)
                .HasForeignKey(d => d.RankingQuestionnaireId)
                .HasConstraintName("FK_Questionnaire_JobTemplate_11");

            entity.HasOne(d => d.ReferenceBenchmarkType).WithMany(p => p.JobTemplates)
                .HasForeignKey(d => d.ReferenceBenchmarkTypeId)
                .HasConstraintName("FK_ReferenceBenchmark_JobTemplate_20");

            entity.HasOne(d => d.SalaryRange).WithMany(p => p.JobTemplateSalaryRanges)
                .HasForeignKey(d => d.SalaryRangeId)
                .HasConstraintName("FK_MetaValue_JobTemplate_7");

            entity.HasOne(d => d.Schedule).WithMany(p => p.JobTemplateSchedules)
                .HasForeignKey(d => d.ScheduleId)
                .HasConstraintName("FK_MetaValue_JobTemplate_8");

            entity.HasOne(d => d.Shift).WithMany(p => p.JobTemplateShifts)
                .HasForeignKey(d => d.ShiftId)
                .HasConstraintName("FK_MetaValue_JobTemplate_9");
        });

        modelBuilder.Entity<JobTemplateBusinessEntity>(entity =>
        {
            entity.HasKey(e => e.JobTemplateBusinessEntityId).HasName("PK_JobTemplateBusinessEntityID");

            entity.ToTable("JobTemplateBusinessEntity", "Admin");

            entity.HasIndex(e => new { e.Deleted, e.JobTemplateId, e.BusinessEntityId }, "IDX_JobTemplateBusinessEntity_2").IsUnique();

            entity.Property(e => e.JobTemplateBusinessEntityId).HasColumnName("JobTemplateBusinessEntityID");
            entity.Property(e => e.BusinessEntityId).HasColumnName("BusinessEntityID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.JobTemplateId).HasColumnName("JobTemplateID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.BusinessEntity).WithMany(p => p.JobTemplateBusinessEntities)
                .HasForeignKey(d => d.BusinessEntityId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessEntity_JobTemplateBusinessEntity_1");

            entity.HasOne(d => d.JobTemplate).WithMany(p => p.JobTemplateBusinessEntities)
                .HasForeignKey(d => d.JobTemplateId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobTemplate_JobTemplateBusinessEntity_2");
        });

        modelBuilder.Entity<JobTemplateFieldValue>(entity =>
        {
            entity.HasKey(e => e.JobTemplateFieldValueId).HasName("PK__JobTempl__A5DB07D546CD52C5");

            entity.ToTable("JobTemplateFieldValue");

            entity.HasIndex(e => new { e.JobTemplateId, e.GroupId, e.GroupSequenceId, e.ValueInstanceId, e.MetaTypeId, e.MetaValueId, e.Deleted }, "IDX_JobTemplateFieldValue_2").IsUnique();

            entity.Property(e => e.JobTemplateFieldValueId).HasColumnName("JobTemplateFieldValueID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.GroupId)
                .HasComment("GroupID, GroupSequenceID and ValueInstanceID go hand in hand to define and store Multi Instance Data values with Multiple Values. \r\nGroupID Identifies which group it is.\r\ne.g. 1 is LicenseFields group\r\n2 is EducationGroup\r\n3 is WorkHistory group etc.\r\n\r\nGroupSequenceID identifies the instance of a group.\r\ne.g. if there are 5 licences, first license groupsequenceID is 1, second is 2, third is 3, fourth is 4 and fifth is 5.\r\n\r\nValueInstanceID identifies and stores the multiple values of a metatypeid from the value list. e.g. Skills matrix.. Multiple possible are 1-20, but the selected user values ar 5,11,19 etc.\r\n\r\nThe GroupID and SequenceID are for multiinstance data like the License and its child fields like LicenseState/LicenceName.\r\n\r\nE.g. 3 License details collected will be in GroupIDs 1,2 and 3. Each element values of each Group would have a order collected in Sequence.\r\n\r\n\r\n\r\nMetaTypeID 	GroupId 	SequenceId\r\n1         	                1              	1\r\n1        	                1 		2          \r\n1		1		3\r\n1		2		1\r\n1		2		2\r\n1		2		3\r\n")
                .HasColumnName("GroupID");
            entity.Property(e => e.GroupSequenceId)
                .HasComment("GroupID, GroupSequenceID and ValueInstanceID go hand in hand to define and store Multi Instance Data values with Multiple Values. \r\nGroupID Identifies which group it is.\r\ne.g. 1 is LicenseFields group\r\n2 is EducationGroup\r\n3 is WorkHistory group etc.\r\n\r\nGroupSequenceID identifies the instance of a group.\r\ne.g. if there are 5 licences, first license groupsequenceID is 1, second is 2, third is 3, fourth is 4 and fifth is 5.\r\n\r\nValueInstanceID identifies and stores the multiple values of a metatypeid from the value list. e.g. Skills matrix.. Multiple possible are 1-20, but the selected user values ar 5,11,19 etc.\r\n\r\nThe GroupID and SequenceID are for multiinstance data like the License and its child fields like LicenseState/LicenceName.\r\n\r\nE.g. 3 License details collected will be in GroupIDs 1,2 and 3. Each element values of each Group would have a order collected in Sequence.\r\n\r\n\r\n\r\nMetaTypeID 	GroupId 	SequenceId\r\n1         	                1              	1\r\n1        	                1 		2          \r\n1		1		3\r\n1		2		1\r\n1		2		2\r\n1		2		3\r\n")
                .HasColumnName("GroupSequenceID");
            entity.Property(e => e.JobTemplateId).HasColumnName("JobTemplateID");
            entity.Property(e => e.MetaTypeId).HasColumnName("MetaTypeID");
            entity.Property(e => e.MetaValueId).HasColumnName("MetaValueID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsdataTypeId).HasColumnName("TMSDataTypeID");
            entity.Property(e => e.ValueDate).HasColumnType("datetime");
            entity.Property(e => e.ValueInstanceId)
                .HasComment("GroupID, GroupSequenceID and ValueInstanceID go hand in hand to define and store Multi Instance Data values with Multiple Values. \r\nGroupID Identifies which group it is.\r\ne.g. 1 is LicenseFields group\r\n2 is EducationGroup\r\n3 is WorkHistory group etc.\r\n\r\nGroupSequenceID identifies the instance of a group.\r\ne.g. if there are 5 licences, first license groupsequenceID is 1, second is 2, third is 3, fourth is 4 and fifth is 5.\r\n\r\nValueInstanceID identifies and stores the multiple values of a metatypeid from the value list. e.g. Skills matrix.. Multiple possible are 1-20, but the selected user values ar 5,11,19 etc.\r\n\r\nThe GroupID and SequenceID are for multiinstance data like the License and its child fields like LicenseState/LicenceName.\r\n\r\nE.g. 3 License details collected will be in GroupIDs 1,2 and 3. Each element values of each Group would have a order collected in Sequence.\r\n\r\n\r\n\r\nMetaTypeID 	GroupId 	SequenceId\r\n1         	                1              	1\r\n1        	                1 		2          \r\n1		1		3\r\n1		2		1\r\n1		2		2\r\n1		2		3\r\n")
                .HasColumnName("ValueInstanceID");

            entity.HasOne(d => d.JobTemplate).WithMany(p => p.JobTemplateFieldValues)
                .HasForeignKey(d => d.JobTemplateId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobTemplate_JobTemplateFieldValue_1");

            entity.HasOne(d => d.MetaType).WithMany(p => p.JobTemplateFieldValues)
                .HasForeignKey(d => d.MetaTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MetaType_JobTemplateFieldValue");

            entity.HasOne(d => d.MetaValue).WithMany(p => p.JobTemplateFieldValues)
                .HasForeignKey(d => d.MetaValueId)
                .HasConstraintName("FK_MetaValue_JobTemplateFieldValue_5");

            entity.HasOne(d => d.TmsdataType).WithMany(p => p.JobTemplateFieldValues)
                .HasForeignKey(d => d.TmsdataTypeId)
                .HasConstraintName("FK_TMSDataType_JobTemplateFieldValue_6");
        });

        modelBuilder.Entity<JobTemplateInstance>(entity =>
        {
            entity.HasKey(e => e.JobTemplateInstanceId).HasName("PK__JobTempl__64A52505CC25846F");

            entity.ToTable("JobTemplateInstance", tb =>
                {
                    tb.HasTrigger("JobTemplateInstanceDeleteTrigger");
                    tb.HasTrigger("JobTemplateInstanceInsertUpdateTrigger");
                    tb.HasTrigger("JobTemplateInstance_AuditTriggerAudit");
                });

            entity.HasIndex(e => e.BehavioralAssessmentVendorOfferingId, "IDX_BehavioralAssessmentVendorOfferingID").HasFillFactor(80);

            entity.HasIndex(e => e.JobTemplateInstanceId, "IDX_JTI_Cover");

            entity.HasIndex(e => new { e.JobTemplateId, e.ScheduleId, e.ShiftId, e.CategoryId, e.JobTemplateInstanceId, e.Name, e.Code, e.ModifiedDate, e.Hours }, "IDX_JobTemplateInstance_10");

            entity.Property(e => e.JobTemplateInstanceId).HasColumnName("JobTemplateInstanceID");
            entity.Property(e => e.AssessmentPackageId).HasColumnName("AssessmentPackageID");
            entity.Property(e => e.BehavioralAssessmentVendorId).HasColumnName("BehavioralAssessmentVendorID");
            entity.Property(e => e.BehavioralAssessmentVendorOfferingId).HasColumnName("BehavioralAssessmentVendorOfferingID");
            entity.Property(e => e.CategoryId).HasColumnName("CategoryID");
            entity.Property(e => e.Code).HasMaxLength(100);
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.EducationId).HasColumnName("EducationID");
            entity.Property(e => e.EeojobGroupId).HasColumnName("EEOJobGroupID");
            entity.Property(e => e.Hours).HasMaxLength(100);
            entity.Property(e => e.JobFamilyId).HasColumnName("JobFamilyID");
            entity.Property(e => e.JobPostingTitle)
                .HasMaxLength(100)
                .HasComment("Default title for job postings created for requisition referencint this job template instance.");
            entity.Property(e => e.JobStatusId).HasColumnName("JobStatusID");
            entity.Property(e => e.JobTemplateId).HasColumnName("JobTemplateID");
            entity.Property(e => e.KnowledgeSkillsAbilities).HasMaxLength(1000);
            entity.Property(e => e.LeanCapitalJobFamilyTypeId).HasColumnName("LeanCapitalJobFamilyTypeID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.NationalJobCategoryId)
                .HasComment("Implied foreign key to TMSSecurity.dbo.NationalJobCategory.NationalJobCategoryID.\r\n\r\nA populated value on a JobTemplateInstance record indicates what Nation Job Category a given JobTemplateInstance should appear under.")
                .HasColumnName("NationalJobCategoryID");
            entity.Property(e => e.PayGradeId).HasColumnName("PayGradeID");
            entity.Property(e => e.PostingBrandingHierarchyLevelId)
                .HasDefaultValue(-1)
                .HasColumnName("PostingBrandingHierarchyLevelID");
            entity.Property(e => e.PreQualMessageTemplateId).HasColumnName("PreQualMessageTemplateID");
            entity.Property(e => e.PreQualificationQuestionnaireId).HasColumnName("PreQualificationQuestionnaireID");
            entity.Property(e => e.RankingQuestionnaireId).HasColumnName("RankingQuestionnaireID");
            entity.Property(e => e.ReferenceAssessmentDivisionId).HasColumnName("ReferenceAssessmentDivisionID");
            entity.Property(e => e.ReferenceAssessmentVendorOfferingId).HasColumnName("ReferenceAssessmentVendorOfferingID");
            entity.Property(e => e.ReferenceAssessmentWorkforceSegmentId).HasColumnName("ReferenceAssessmentWorkforceSegmentID");
            entity.Property(e => e.ReferenceBenchmarkTypeId).HasColumnName("ReferenceBenchmarkTypeID");
            entity.Property(e => e.SalaryRangeId).HasColumnName("SalaryRangeID");
            entity.Property(e => e.ScheduleId).HasColumnName("ScheduleID");
            entity.Property(e => e.ShiftId).HasColumnName("ShiftID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.AssessmentPackage).WithMany(p => p.JobTemplateInstances)
                .HasForeignKey(d => d.AssessmentPackageId)
                .HasConstraintName("FK_AssessmentPackage_JobTemplateInstance_16");

            entity.HasOne(d => d.BehavioralAssessmentVendor).WithMany(p => p.JobTemplateInstances)
                .HasForeignKey(d => d.BehavioralAssessmentVendorId)
                .HasConstraintName("FK_Vendor_JobTemplateInstance_18");

            entity.HasOne(d => d.Category).WithMany(p => p.JobTemplateInstanceCategories)
                .HasForeignKey(d => d.CategoryId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MetaValue_JobTemplateInstance_Category");

            entity.HasOne(d => d.Education).WithMany(p => p.JobTemplateInstanceEducations)
                .HasForeignKey(d => d.EducationId)
                .HasConstraintName("FK_MetaValue_JobTemplateInstance_Education");

            entity.HasOne(d => d.EeojobGroup).WithMany(p => p.JobTemplateInstanceEeojobGroups)
                .HasForeignKey(d => d.EeojobGroupId)
                .HasConstraintName("FK_MetaValue_JobTemplateInstance_EEOJobGroup");

            entity.HasOne(d => d.JobFamily).WithMany(p => p.JobTemplateInstances)
                .HasForeignKey(d => d.JobFamilyId)
                .HasConstraintName("FK_JobFamily_JobTemplateInstance_17");

            entity.HasOne(d => d.JobStatus).WithMany(p => p.JobTemplateInstanceJobStatuses)
                .HasForeignKey(d => d.JobStatusId)
                .HasConstraintName("FK_MetaValue_JobTemplateInstance_JobStatus");

            entity.HasOne(d => d.JobTemplate).WithMany(p => p.JobTemplateInstances)
                .HasForeignKey(d => d.JobTemplateId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobTemplate_JobTemplateInstance_2");

            entity.HasOne(d => d.LeanCapitalJobFamilyType).WithMany(p => p.JobTemplateInstances)
                .HasForeignKey(d => d.LeanCapitalJobFamilyTypeId)
                .HasConstraintName("FK_LeanCapitalJobFamilyType_JobTemplateInstance");

            entity.HasOne(d => d.PayGrade).WithMany(p => p.JobTemplateInstancePayGrades)
                .HasForeignKey(d => d.PayGradeId)
                .HasConstraintName("FK_MetaValue_JobTemplateInstance_PayGrade");

            entity.HasOne(d => d.PostingBrandingHierarchyLevel).WithMany(p => p.JobTemplateInstances)
                .HasForeignKey(d => d.PostingBrandingHierarchyLevelId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessEntityType_JobTemplateInstance_19");

            entity.HasOne(d => d.PreQualMessageTemplate).WithMany(p => p.JobTemplateInstances)
                .HasForeignKey(d => d.PreQualMessageTemplateId)
                .HasConstraintName("FK_Template_JobTemplateInstance_13");

            entity.HasOne(d => d.PreQualificationQuestionnaire).WithMany(p => p.JobTemplateInstancePreQualificationQuestionnaires)
                .HasForeignKey(d => d.PreQualificationQuestionnaireId)
                .HasConstraintName("FK_Questionnaire_JobTemplateInstance_16");

            entity.HasOne(d => d.RankingQuestionnaire).WithMany(p => p.JobTemplateInstanceRankingQuestionnaires)
                .HasForeignKey(d => d.RankingQuestionnaireId)
                .HasConstraintName("FK_Questionnaire_JobTemplateInstance_14");

            entity.HasOne(d => d.ReferenceBenchmarkType).WithMany(p => p.JobTemplateInstances)
                .HasForeignKey(d => d.ReferenceBenchmarkTypeId)
                .HasConstraintName("FK_ReferenceBenchmarkType_JobTemplateInstance_20");

            entity.HasOne(d => d.SalaryRange).WithMany(p => p.JobTemplateInstanceSalaryRanges)
                .HasForeignKey(d => d.SalaryRangeId)
                .HasConstraintName("FK_MetaValue_JobTemplateInstance_SalaryRange");

            entity.HasOne(d => d.Schedule).WithMany(p => p.JobTemplateInstanceSchedules)
                .HasForeignKey(d => d.ScheduleId)
                .HasConstraintName("FK_MetaValue_JobTemplateInstance_Schedule");

            entity.HasOne(d => d.Shift).WithMany(p => p.JobTemplateInstanceShifts)
                .HasForeignKey(d => d.ShiftId)
                .HasConstraintName("FK_MetaValue_JobTemplateInstance_Shift");
        });

        modelBuilder.Entity<JobTemplateInstanceLeanCapitalJobFamilyType>(entity =>
        {
            entity.HasKey(e => e.JobTemplateInstanceLeanCapitalJobFamilyTypeId).HasName("PK__JobTempl__9D7873D4EB7413A5");

            entity.ToTable("JobTemplateInstanceLeanCapitalJobFamilyType");

            entity.HasIndex(e => new { e.JobTemplateInstanceId, e.LeanCapitalJobFamilyTypeId, e.Deleted }, "IDX_JobTemplateInstanceLeanCapitalJobFamilyType_JobTemplateInstanceID_LeanCapitalJobFamilyTypeID_Deleted").IsUnique();

            entity.Property(e => e.JobTemplateInstanceLeanCapitalJobFamilyTypeId).HasColumnName("JobTemplateInstanceLeanCapitalJobFamilyTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.JobTemplateInstanceId).HasColumnName("JobTemplateInstanceID");
            entity.Property(e => e.LeanCapitalJobFamilyTypeId).HasColumnName("LeanCapitalJobFamilyTypeID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.JobTemplateInstance).WithMany(p => p.JobTemplateInstanceLeanCapitalJobFamilyTypes)
                .HasForeignKey(d => d.JobTemplateInstanceId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobTemplateInstance_JobTemplateInstanceLeanCapitalJobFamilyType");

            entity.HasOne(d => d.LeanCapitalJobFamilyType).WithMany(p => p.JobTemplateInstanceLeanCapitalJobFamilyTypes)
                .HasForeignKey(d => d.LeanCapitalJobFamilyTypeId)
                .HasConstraintName("FK_LeanCapitalJobFamilyType_JobTemplateInstanceLeanCapitalJobFamilyType");
        });

        modelBuilder.Entity<JobTemplateInstanceMetaValue>(entity =>
        {
            entity.HasKey(e => e.JobTemplateInstanceMetaValueId).HasName("PK__JobTempl__F4C091D823CA3E3E");

            entity.ToTable("JobTemplateInstanceMetaValue", tb => tb.HasTrigger("JobTemplateInstanceMetaValue_AuditTriggerAudit"));

            entity.HasIndex(e => new { e.JobTemplateInstanceId, e.MetaValueId, e.Deleted, e.MetaTypeId }, "IDX_JobTemplateInstanceMetaValue_2").IsUnique();

            entity.Property(e => e.JobTemplateInstanceMetaValueId).HasColumnName("JobTemplateInstanceMetaValueID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.JobTemplateInstanceId).HasColumnName("JobTemplateInstanceID");
            entity.Property(e => e.MetaTypeId).HasColumnName("MetaTypeID");
            entity.Property(e => e.MetaValueId).HasColumnName("MetaValueID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.JobTemplateInstance).WithMany(p => p.JobTemplateInstanceMetaValues)
                .HasForeignKey(d => d.JobTemplateInstanceId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobTemplateInstance_JobTemplateInstanceMetaValue_4");

            entity.HasOne(d => d.MetaType).WithMany(p => p.JobTemplateInstanceMetaValues)
                .HasForeignKey(d => d.MetaTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__JobTemplateInstanceMetaType");

            entity.HasOne(d => d.MetaValue).WithMany(p => p.JobTemplateInstanceMetaValues)
                .HasForeignKey(d => d.MetaValueId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MetaValue_JobTemplateInstanceMetaValue_3");
        });

        modelBuilder.Entity<JobTemplateLeanCapitalJobFamilyType>(entity =>
        {
            entity.HasKey(e => e.JobTemplateLeanCapitalJobFamilyTypeId).HasName("PK__JobTempl__08FCE56146851D2C");

            entity.ToTable("JobTemplateLeanCapitalJobFamilyType", "Admin");

            entity.HasIndex(e => new { e.JobTemplateId, e.LeanCapitalJobFamilyTypeId, e.Deleted }, "IDX_JobTemplateLeanCapitalJobFamilyType_JobTemplateID_LeanCapitalJobFamilyTypeID_Deleted").IsUnique();

            entity.Property(e => e.JobTemplateLeanCapitalJobFamilyTypeId).HasColumnName("JobTemplateLeanCapitalJobFamilyTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.JobTemplateId).HasColumnName("JobTemplateID");
            entity.Property(e => e.LeanCapitalJobFamilyTypeId).HasColumnName("LeanCapitalJobFamilyTypeID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.JobTemplate).WithMany(p => p.JobTemplateLeanCapitalJobFamilyTypes)
                .HasForeignKey(d => d.JobTemplateId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobTemplate_JobTemplateLeanCapitalJobFamilyType");

            entity.HasOne(d => d.LeanCapitalJobFamilyType).WithMany(p => p.JobTemplateLeanCapitalJobFamilyTypes)
                .HasForeignKey(d => d.LeanCapitalJobFamilyTypeId)
                .HasConstraintName("FK_LeanCapitalJobFamilyType_JobTemplateLeanCapitalJobFamilyType");
        });

        modelBuilder.Entity<JobTemplateMetaValue>(entity =>
        {
            entity.HasKey(e => e.JobTemplateMetaValueId).HasName("PK__JobTempl__BB6F73ED6B53041E");

            entity.ToTable("JobTemplateMetaValue", "Admin");

            entity.HasIndex(e => new { e.JobTemplateId, e.MetaValueId, e.Deleted, e.MetaTypeId }, "IDX_JobTemplateMetaValue_2").IsUnique();

            entity.Property(e => e.JobTemplateMetaValueId).HasColumnName("JobTemplateMetaValueID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.JobTemplateId).HasColumnName("JobTemplateID");
            entity.Property(e => e.MetaTypeId).HasColumnName("MetaTypeID");
            entity.Property(e => e.MetaValueId).HasColumnName("MetaValueID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.JobTemplate).WithMany(p => p.JobTemplateMetaValues)
                .HasForeignKey(d => d.JobTemplateId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobTemplate_JobTemplateMetaValue_1");

            entity.HasOne(d => d.MetaType).WithMany(p => p.JobTemplateMetaValues)
                .HasForeignKey(d => d.MetaTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MetaType_JobTemplateMetaValue_3");

            entity.HasOne(d => d.MetaValue).WithMany(p => p.JobTemplateMetaValues)
                .HasForeignKey(d => d.MetaValueId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MetaValue_JobTemplateMetaValue_2");
        });

        modelBuilder.Entity<JobTemplatePropagationField>(entity =>
        {
            entity.ToTable("JobTemplatePropagationField", "Admin");

            entity.Property(e => e.JobTemplatePropagationFieldId).HasColumnName("JobTemplatePropagationFieldID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DisplayName).HasMaxLength(200);
            entity.Property(e => e.MetaTypeId).HasColumnName("MetaTypeID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.MetaType).WithMany(p => p.JobTemplatePropagationFields)
                .HasForeignKey(d => d.MetaTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobTemplatePropagationField_MetaTypeID");
        });

        modelBuilder.Entity<JobTemplatePropagationFieldInstance>(entity =>
        {
            entity.ToTable("JobTemplatePropagationFieldInstance");

            entity.Property(e => e.JobTemplatePropagationFieldInstanceId).HasColumnName("JobTemplatePropagationFieldInstanceID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.JobTemplatePropagationFieldId).HasColumnName("JobTemplatePropagationFieldID");
            entity.Property(e => e.JobTemplatePropagationJobId).HasColumnName("JobTemplatePropagationJobID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.JobTemplatePropagationField).WithMany(p => p.JobTemplatePropagationFieldInstances)
                .HasForeignKey(d => d.JobTemplatePropagationFieldId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobTemplatePropagationFieldInstance_JobTemplatePropagationFieldID");

            entity.HasOne(d => d.JobTemplatePropagationJob).WithMany(p => p.JobTemplatePropagationFieldInstances)
                .HasForeignKey(d => d.JobTemplatePropagationJobId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobTemplatePropagationFieldInstance_JobTemplatePropagationJobID");
        });

        modelBuilder.Entity<JobTemplatePropagationHri>(entity =>
        {
            entity.HasKey(e => e.JobTemplatePropagationHrisid);

            entity.ToTable("JobTemplatePropagationHRIS");

            entity.Property(e => e.JobTemplatePropagationHrisid).HasColumnName("JobTemplatePropagationHRISID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.JobCreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserId");

            entity.HasOne(d => d.Tmsuser).WithMany(p => p.JobTemplatePropagationHris)
                .HasForeignKey(d => d.TmsuserId)
                .HasConstraintName("FK_JobTemplatePropagationHRIS_TMSUserID");
        });

        modelBuilder.Entity<JobTemplatePropagationHrisjobTemplate>(entity =>
        {
            entity.ToTable("JobTemplatePropagationHRISJobTemplate");

            entity.Property(e => e.JobTemplatePropagationHrisjobTemplateId).HasColumnName("JobTemplatePropagationHRISJobTemplateID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.JobTemplateId).HasColumnName("JobTemplateID");
            entity.Property(e => e.JobTemplatePropagationHrisid).HasColumnName("JobTemplatePropagationHRISID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.JobTemplate).WithMany(p => p.JobTemplatePropagationHrisjobTemplates)
                .HasForeignKey(d => d.JobTemplateId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobTemplatePropagationHRISJobTemplate_JobTemplateID");

            entity.HasOne(d => d.JobTemplatePropagationHris).WithMany(p => p.JobTemplatePropagationHrisjobTemplates)
                .HasForeignKey(d => d.JobTemplatePropagationHrisid)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobTemplatePropagationHRISJobTemplate_JobTemplatePropagationHRISID");
        });

        modelBuilder.Entity<JobTemplatePropagationJob>(entity =>
        {
            entity.ToTable("JobTemplatePropagationJob");

            entity.Property(e => e.JobTemplatePropagationJobId).HasColumnName("JobTemplatePropagationJobID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.JobCreateDate).HasColumnType("datetime");
            entity.Property(e => e.JobEndDate).HasColumnType("datetime");
            entity.Property(e => e.JobTemplateId).HasColumnName("JobTemplateID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserId");

            entity.HasOne(d => d.JobTemplate).WithMany(p => p.JobTemplatePropagationJobs)
                .HasForeignKey(d => d.JobTemplateId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobTemplatePropagationJob_JobTemplateID");

            entity.HasOne(d => d.Tmsuser).WithMany(p => p.JobTemplatePropagationJobs)
                .HasForeignKey(d => d.TmsuserId)
                .HasConstraintName("FK_JobTemplatePropagationJob_TMSUserID");
        });

        modelBuilder.Entity<JobTemplatePropagationJobInstance>(entity =>
        {
            entity.ToTable("JobTemplatePropagationJobInstance");

            entity.Property(e => e.JobTemplatePropagationJobInstanceId).HasColumnName("JobTemplatePropagationJobInstanceID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.EndDate).HasColumnType("datetime");
            entity.Property(e => e.JobTemplatePropagationJobId).HasColumnName("JobTemplatePropagationJobID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.StartDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.JobTemplatePropagationJob).WithMany(p => p.JobTemplatePropagationJobInstances)
                .HasForeignKey(d => d.JobTemplatePropagationJobId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobTemplatePropagationJobInstance_JobTemplatePropagationJobID");
        });

        modelBuilder.Entity<JobTemplatePropagationJobSummary>(entity =>
        {
            entity.ToTable("JobTemplatePropagationJobSummary");

            entity.Property(e => e.JobTemplatePropagationJobSummaryId).HasColumnName("JobTemplatePropagationJobSummaryID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.EndDate).HasColumnType("datetime");
            entity.Property(e => e.JobTemplatePropagationJobInstanceId).HasColumnName("JobTemplatePropagationJobInstanceID");
            entity.Property(e => e.JobTemplatePropagationTargetId).HasColumnName("JobTemplatePropagationTargetID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.ProcessingDate).HasColumnType("datetime");
            entity.Property(e => e.QueuedDate).HasColumnType("datetime");
            entity.Property(e => e.StartDate).HasColumnType("datetime");
            entity.Property(e => e.StatusMessage).HasMaxLength(1000);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.JobTemplatePropagationJobInstance).WithMany(p => p.JobTemplatePropagationJobSummaries)
                .HasForeignKey(d => d.JobTemplatePropagationJobInstanceId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobTemplatePropagationJobSummary_JobTemplatePropagationJobInstanceID");

            entity.HasOne(d => d.JobTemplatePropagationTarget).WithMany(p => p.JobTemplatePropagationJobSummaries)
                .HasForeignKey(d => d.JobTemplatePropagationTargetId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobTemplatePropagationJobSummary_JobTemplatePropagationTargetID");
        });

        modelBuilder.Entity<JobTemplatePropagationQueue>(entity =>
        {
            entity.ToTable("JobTemplatePropagationQueue");

            entity.HasIndex(e => new { e.Uuid, e.QueueType }, "UC_JobTemplatePropagationQueue").IsUnique();

            entity.Property(e => e.JobTemplatePropagationQueueId).HasColumnName("JobTemplatePropagationQueueID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.Uuid)
                .HasMaxLength(50)
                .HasColumnName("UUID");
        });

        modelBuilder.Entity<JobTemplatePropagationRequisition>(entity =>
        {
            entity.ToTable("JobTemplatePropagationRequisition");

            entity.HasIndex(e => new { e.JobTemplatePropagationJobId, e.RequisitionId, e.Deleted }, "IDX_JobTemplatePropagationRequisition_JobID_RequisitionID_Deleted").HasFillFactor(90);

            entity.Property(e => e.JobTemplatePropagationRequisitionId).HasColumnName("JobTemplatePropagationRequisitionID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Dbenabled).HasColumnName("DBEnabled");
            entity.Property(e => e.Esenabled).HasColumnName("ESEnabled");
            entity.Property(e => e.JobTemplatePropagationJobId).HasColumnName("JobTemplatePropagationJobID");
            entity.Property(e => e.Jtenabled).HasColumnName("JTEnabled");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.RequisitionId).HasColumnName("RequisitionID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.Vipenabled).HasColumnName("VIPEnabled");

            entity.HasOne(d => d.JobTemplatePropagationJob).WithMany(p => p.JobTemplatePropagationRequisitions)
                .HasForeignKey(d => d.JobTemplatePropagationJobId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobTemplatePropagationRequisition_JobTemplatePropagationJob");

            entity.HasOne(d => d.Requisition).WithMany(p => p.JobTemplatePropagationRequisitions)
                .HasForeignKey(d => d.RequisitionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobTemplatePropagationRequisition_RequisitionID");
        });

        modelBuilder.Entity<JobTemplatePropagationRequisitionStatusInstance>(entity =>
        {
            entity.ToTable("JobTemplatePropagationRequisitionStatusInstance");

            entity.Property(e => e.JobTemplatePropagationRequisitionStatusInstanceId).HasColumnName("JobTemplatePropagationRequisitionStatusInstanceID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.JobTemplatePropagationJobId).HasColumnName("JobTemplatePropagationJobID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.RequisitionStatusTypeId).HasColumnName("RequisitionStatusTypeID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.JobTemplatePropagationJob).WithMany(p => p.JobTemplatePropagationRequisitionStatusInstances)
                .HasForeignKey(d => d.JobTemplatePropagationJobId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobTemplatePropagationRequisitionStatusInstance_JobTemplatePropagationJobID");

            entity.HasOne(d => d.RequisitionStatusType).WithMany(p => p.JobTemplatePropagationRequisitionStatusInstances)
                .HasForeignKey(d => d.RequisitionStatusTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobTemplatePropagationRequisitionStatusInstance_RequisitionStatusTypeID");
        });

        modelBuilder.Entity<JobTemplatePropagationRequisitionSyncErrorLog>(entity =>
        {
            entity.ToTable("JobTemplatePropagationRequisitionSyncErrorLog");

            entity.Property(e => e.JobTemplatePropagationRequisitionSyncErrorLogId).HasColumnName("JobTemplatePropagationRequisitionSyncErrorLogID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.JobTemplatePropagationJobInstanceId).HasColumnName("JobTemplatePropagationJobInstanceID");
            entity.Property(e => e.JobTemplatePropagationRequisitionId).HasColumnName("JobTemplatePropagationRequisitionID");
            entity.Property(e => e.JobTemplatePropagationTargetId).HasColumnName("JobTemplatePropagationTargetID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.OperationTime).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.JobTemplatePropagationJobInstance).WithMany(p => p.JobTemplatePropagationRequisitionSyncErrorLogs)
                .HasForeignKey(d => d.JobTemplatePropagationJobInstanceId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobTemplatePropagationRequisitionSyncErrorLog_JobTemplatePropagationJobInstance");

            entity.HasOne(d => d.JobTemplatePropagationRequisition).WithMany(p => p.JobTemplatePropagationRequisitionSyncErrorLogs)
                .HasForeignKey(d => d.JobTemplatePropagationRequisitionId)
                .HasConstraintName("FK_JobTemplatePropagationRequisitionSyncErrorLog_JobTemplatePropagationRequisition");

            entity.HasOne(d => d.JobTemplatePropagationTarget).WithMany(p => p.JobTemplatePropagationRequisitionSyncErrorLogs)
                .HasForeignKey(d => d.JobTemplatePropagationTargetId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobTemplatePropagationRequisitionSyncErrorLog_JobTemplatePropagationTarget");
        });

        modelBuilder.Entity<JobTemplatePropagationRequisitionSyncStatus>(entity =>
        {
            entity.ToTable("JobTemplatePropagationRequisitionSyncStatus");

            entity.HasIndex(e => new { e.JobTemplatePropagationRequisitionId, e.Deleted }, "IDX_JobTemplatePropagationRequisitionSyncStatus_JobTemplatePropagationRequisitionID_Deleted").HasFillFactor(90);

            entity.Property(e => e.JobTemplatePropagationRequisitionSyncStatusId).HasColumnName("JobTemplatePropagationRequisitionSyncStatusID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Dbstatus).HasColumnName("DBStatus");
            entity.Property(e => e.Esstatus).HasColumnName("ESStatus");
            entity.Property(e => e.JobTemplatePropagationRequisitionId).HasColumnName("JobTemplatePropagationRequisitionID");
            entity.Property(e => e.Jtstatus).HasColumnName("JTStatus");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.Vipstatus).HasColumnName("VIPStatus");

            entity.HasOne(d => d.JobTemplatePropagationRequisition).WithMany(p => p.JobTemplatePropagationRequisitionSyncStatuses)
                .HasForeignKey(d => d.JobTemplatePropagationRequisitionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobTemplatePropagationRequisitionSyncStatus_JobTemplatePropagationRequisiton");
        });

        modelBuilder.Entity<JobTemplatePropagationTarget>(entity =>
        {
            entity.ToTable("JobTemplatePropagationTarget", "Admin");

            entity.Property(e => e.JobTemplatePropagationTargetId).HasColumnName("JobTemplatePropagationTargetID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<LeanCapitalJobFamilyType>(entity =>
        {
            entity.HasKey(e => e.LeanCapitalJobFamilyTypeId).HasName("PK_LeanCapitalJobFamilyTypeID");

            entity.ToTable("LeanCapitalJobFamilyType", "Admin");

            entity.Property(e => e.LeanCapitalJobFamilyTypeId).HasColumnName("LeanCapitalJobFamilyTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<LegacyAccount>(entity =>
        {
            entity.HasKey(e => e.LegacyAccountId).HasName("PK__LegacyAc__4CC41C70F45BE042");

            entity.ToTable("LegacyAccount");

            entity.Property(e => e.LegacyAccountId).HasColumnName("LegacyAccountID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Email).HasMaxLength(256);
            entity.Property(e => e.FirstName).HasMaxLength(100);
            entity.Property(e => e.LastName).HasMaxLength(100);
            entity.Property(e => e.MiddleName).HasMaxLength(100);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Password).HasMaxLength(256);
            entity.Property(e => e.Salt).HasMaxLength(50);
            entity.Property(e => e.SecurityAnswer).HasMaxLength(256);
            entity.Property(e => e.SecurityQuestion).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.Username).HasMaxLength(100);
        });

        modelBuilder.Entity<LegacyAccountApplicationTracking>(entity =>
        {
            entity.HasKey(e => e.LegacyAccountApplicationTrackingId).HasName("PK__LegacyAc__1164F222C339636A");

            entity.ToTable("LegacyAccountApplicationTracking");

            entity.Property(e => e.LegacyAccountApplicationTrackingId).HasColumnName("LegacyAccountApplicationTrackingID");
            entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");
            entity.Property(e => e.ApplicationStateTypeId).HasColumnName("ApplicationStateTypeID");
            entity.Property(e => e.BusinessEntityId).HasColumnName("BusinessEntityID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.JobPostingId).HasColumnName("JobPostingID");
            entity.Property(e => e.JobTitle).HasMaxLength(100);
            entity.Property(e => e.LegacyAccountId).HasColumnName("LegacyAccountID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.RequisitionId).HasColumnName("RequisitionID");
            entity.Property(e => e.RequisitionNumber).HasMaxLength(30);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.LegacyAccount).WithMany(p => p.LegacyAccountApplicationTrackings)
                .HasForeignKey(d => d.LegacyAccountId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_LegacyAccount_LegacyAccountApplicationTracking_1");
        });

        modelBuilder.Entity<LocalApplicant>(entity =>
        {
            entity.HasKey(e => e.LocalApplicantId).HasName("PK__LocalApp__0BE07028D94CD7CD");

            entity.ToTable("LocalApplicant", tb =>
                {
                    tb.HasTrigger("LocalApplicantDeleteTrigger");
                    tb.HasTrigger("LocalApplicantInsertUpdateTrigger");
                });

            entity.HasIndex(e => new { e.LocalApplicantId, e.Deleted }, "IDX_LocalApplicant_PK_and_Deleted").IsUnique();

            entity.Property(e => e.LocalApplicantId).HasColumnName("LocalApplicantID");
            entity.Property(e => e.ApplicantFirstName).HasMaxLength(100);
            entity.Property(e => e.ApplicantLastName).HasMaxLength(100);
            entity.Property(e => e.ApplicantMiddleName).HasMaxLength(100);
            entity.Property(e => e.City).HasMaxLength(50);
            entity.Property(e => e.ContactMethodMetaValueId).HasColumnName("ContactMethodMetaValueID");
            entity.Property(e => e.CountryMetaValueId).HasColumnName("CountryMetaValueID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Email).HasMaxLength(256);
            entity.Property(e => e.LastFourSsn)
                .HasMaxLength(4)
                .HasComment("Added for PBI 28987,  Stores the Unencrypted value for the last four digits of the Applicant''s Social Security Number.")
                .HasColumnName("LastFourSSN");
            entity.Property(e => e.LegacyAccountId)
                .HasComment("Will hold the ID of the Legacy Account (PM10 Site Manager Account) the application is tied to.  Migration will be the only process that will populate this column.")
                .HasColumnName("LegacyAccountID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.PhoneNumber).HasMaxLength(20);
            entity.Property(e => e.PhoneTypeMetaValueId).HasColumnName("PhoneTypeMetaValueID");
            entity.Property(e => e.SourceCategoryMetaValueId).HasColumnName("SourceCategoryMetaValueID");
            entity.Property(e => e.SourceNameMetaValueId).HasColumnName("SourceNameMetaValueID");
            entity.Property(e => e.StateMetaValueId).HasColumnName("StateMetaValueID");
            entity.Property(e => e.Street1).HasMaxLength(50);
            entity.Property(e => e.Street2).HasMaxLength(50);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.Zipcode).HasMaxLength(12);

            entity.HasOne(d => d.ContactMethodMetaValue).WithMany(p => p.LocalApplicantContactMethodMetaValues)
                .HasForeignKey(d => d.ContactMethodMetaValueId)
                .HasConstraintName("FK_MetaValue_LocalApplicant_ContactMethod");

            entity.HasOne(d => d.CountryMetaValue).WithMany(p => p.LocalApplicantCountryMetaValues)
                .HasForeignKey(d => d.CountryMetaValueId)
                .HasConstraintName("FK_MetaValue_LocalApplicant_Country");

            entity.HasOne(d => d.PhoneTypeMetaValue).WithMany(p => p.LocalApplicantPhoneTypeMetaValues)
                .HasForeignKey(d => d.PhoneTypeMetaValueId)
                .HasConstraintName("FK_MetaValue_LocalApplicant_PhoneType");

            entity.HasOne(d => d.SourceCategoryMetaValue).WithMany(p => p.LocalApplicantSourceCategoryMetaValues)
                .HasForeignKey(d => d.SourceCategoryMetaValueId)
                .HasConstraintName("FK_MetaValue_LocalApplicant_SourceCategory");

            entity.HasOne(d => d.SourceNameMetaValue).WithMany(p => p.LocalApplicantSourceNameMetaValues)
                .HasForeignKey(d => d.SourceNameMetaValueId)
                .HasConstraintName("FK_MetaValue_LocalApplicant_SourceName");

            entity.HasOne(d => d.StateMetaValue).WithMany(p => p.LocalApplicantStateMetaValues)
                .HasForeignKey(d => d.StateMetaValueId)
                .HasConstraintName("FK_MetaValue_LocalApplicant_State");
        });

        modelBuilder.Entity<LocalApplicantVendorOrder>(entity =>
        {
            entity.HasKey(e => e.LocalApplicantVendorOrderId).HasName("PK_LocalApplicantVendorOrderID");

            entity.ToTable("LocalApplicantVendorOrder");

            entity.Property(e => e.LocalApplicantVendorOrderId).HasColumnName("LocalApplicantVendorOrderID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.LocalApplicantId).HasColumnName("LocalApplicantID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.VendorOrderId).HasColumnName("VendorOrderID");

            entity.HasOne(d => d.LocalApplicant).WithMany(p => p.LocalApplicantVendorOrders)
                .HasForeignKey(d => d.LocalApplicantId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__LocalApplicantVendorOrder_LocalApplicant");

            entity.HasOne(d => d.VendorOrder).WithMany(p => p.LocalApplicantVendorOrders)
                .HasForeignKey(d => d.VendorOrderId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__ALocalApplicantVendorOrder_VendorOrder");
        });

        modelBuilder.Entity<MetaType>(entity =>
        {
            entity.HasKey(e => e.MetaTypeId).HasName("PK_MetaTypeID");

            entity.ToTable("MetaType", "Admin");

            entity.HasIndex(e => new { e.Deleted, e.Name }, "IDX_MetaType_2").IsUnique();

            entity.HasIndex(e => new { e.InternalName, e.Deleted }, "IDX_MetaType_3").IsUnique();

            entity.HasIndex(e => new { e.InternalNameId, e.Deleted }, "IDX_MetaType_4").IsUnique();

            entity.Property(e => e.MetaTypeId).HasColumnName("MetaTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Description).HasMaxLength(255);
            entity.Property(e => e.DisplayName).HasMaxLength(200);
            entity.Property(e => e.InternalName)
                .HasMaxLength(100)
                .HasComment("This column, which will default to match the Name column, will be used to internally identify the field record.  this is being doine so that we can reliably correlate fileds across environments without having to rely on the tables int identity column being consistent.");
            entity.Property(e => e.InternalNameId)
                .HasComputedColumnSql("(checksum([InternalName]))", true)
                .HasComment("This column will be used to uniquely identify a record in this table.  It is a calculated column that is calculated as the CHECKSUM of the InternalName column, given that it will uniquel identify the records in the table in the same manner as the InternalName column - it is being used so that we can work with unique records in this table in the most efficient manner (integer compares rather than string compares).")
                .HasColumnName("InternalNameID");
            entity.Property(e => e.IsEeo).HasColumnName("IsEEO");
            entity.Property(e => e.IsReportable).HasDefaultValue(false);
            entity.Property(e => e.MetaTypeReportingTypeId).HasColumnName("MetaTypeReportingTypeID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.QuestionnaireId).HasColumnName("QuestionnaireID");
            entity.Property(e => e.ScopeLevelId).HasColumnName("ScopeLevelID");
            entity.Property(e => e.SortOrderTypeId).HasColumnName("SortOrderTypeID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsdataTypeId).HasColumnName("TMSDataTypeID");

            entity.HasOne(d => d.MetaTypeReportingType).WithMany(p => p.MetaTypes)
                .HasForeignKey(d => d.MetaTypeReportingTypeId)
                .HasConstraintName("FK_MetaTypeReportingType_MetaType_5");

            entity.HasOne(d => d.Questionnaire).WithMany(p => p.MetaTypes)
                .HasForeignKey(d => d.QuestionnaireId)
                .HasConstraintName("FK_Questionnaire_MetaType_4");

            entity.HasOne(d => d.SortOrderType).WithMany(p => p.MetaTypes)
                .HasForeignKey(d => d.SortOrderTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SortOrderType_MetaType_3");

            entity.HasOne(d => d.TmsdataType).WithMany(p => p.MetaTypes)
                .HasForeignKey(d => d.TmsdataTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TMSDataType_MetaType_2");
        });

        modelBuilder.Entity<MetaTypeReportingType>(entity =>
        {
            entity.ToTable("MetaTypeReportingType", "Admin");

            entity.Property(e => e.MetaTypeReportingTypeId).HasColumnName("MetaTypeReportingTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<MetaValue>(entity =>
        {
            entity.HasKey(e => e.MetaValueId).HasName("PK_MetaValueID");

            entity.ToTable("MetaValue", tb =>
                {
                    tb.HasTrigger("MetaValueDeleteTrigger");
                    tb.HasTrigger("MetaValueInsertUpdateTrigger");
                });

            entity.HasIndex(e => new { e.Deleted, e.Name, e.MetaTypeId }, "IDX_MetaValue_2").IsUnique();

            entity.HasIndex(e => new { e.MetaTypeId, e.InternalName, e.Deleted }, "IDX_MetaValue_3").IsUnique();

            entity.Property(e => e.MetaValueId).HasColumnName("MetaValueID");
            entity.Property(e => e.Color)
                .HasMaxLength(7)
                .IsFixedLength();
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Description).HasMaxLength(1500);
            entity.Property(e => e.ExtMessage).HasMaxLength(100);
            entity.Property(e => e.HrXmlValue)
                .HasMaxLength(100)
                .HasComment("MetaValue values are passed via HrXml documents to 3rd party vendors. HrXml standard schema imposes restrictions on values such as gender (Male/Female) or Boolean values (true/false). These HrXml values may different from HCS values. For example, HCS uses Yes/No for Boolean. This column contains the value for this MetaValue that should be used to use to populate HrXml document if this value is different from the value of Name column.");
            entity.Property(e => e.Hrisidentifier)
                .HasMaxLength(64)
                .HasComment("The identifier of the MetaValue in the external system of record.")
                .HasColumnName("HRISIdentifier");
            entity.Property(e => e.InternalName)
                .HasMaxLength(100)
                .HasDefaultValueSql("(newid())")
                .HasComment("This column, which will default to match the Name column, will be used to internally identify the field record for a given meta type.  this is being doine so that we can reliably correlate fileds across environments without having to rely on the tables int identity column being consistent. The default value is set to a NEWID() and is set to the value of name in a post-deployment script because you cannot default a value to the value of another column.");
            entity.Property(e => e.InternalNameId)
                .HasComputedColumnSql("(checksum([InternalName]))", true)
                .HasComment("This column will be used to uniquely identify a record in this table.  It is a calculated column that is a checksum of the InternalName column.\r\n")
                .HasColumnName("InternalNameID");
            entity.Property(e => e.MetaTypeId).HasColumnName("MetaTypeID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.ShortName).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.MetaType).WithMany(p => p.MetaValues)
                .HasForeignKey(d => d.MetaTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MetaType_MetaValue_1");
        });

        modelBuilder.Entity<MetaValueBusinessEntity>(entity =>
        {
            entity.HasKey(e => e.MetaValueBusinessEntityId).HasName("PK__MetaValu__69D0CC01D3BA0956");

            entity.ToTable("MetaValueBusinessEntity");

            entity.HasIndex(e => new { e.Deleted, e.MetaValueId, e.BusinessEntityId }, "IDX_MetaValueBusinessEntity_2").IsUnique();

            entity.Property(e => e.MetaValueBusinessEntityId).HasColumnName("MetaValueBusinessEntityID");
            entity.Property(e => e.BusinessEntityId).HasColumnName("BusinessEntityID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.MetaValueId).HasColumnName("MetaValueID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.BusinessEntity).WithMany(p => p.MetaValueBusinessEntities)
                .HasForeignKey(d => d.BusinessEntityId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessEntity_MetaValueBusinessEntity_1");

            entity.HasOne(d => d.MetaValue).WithMany(p => p.MetaValueBusinessEntities)
                .HasForeignKey(d => d.MetaValueId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MetaValue_MetaValueBusinessEntity_2");
        });

        modelBuilder.Entity<MiscellaneousField>(entity =>
        {
            entity.HasKey(e => e.MiscellaneousFieldId).HasName("PK__Miscella__BF79A9C27AE5836D");

            entity.ToTable("MiscellaneousField", "Admin");

            entity.Property(e => e.MiscellaneousFieldId)
                .ValueGeneratedNever()
                .HasColumnName("MiscellaneousFieldID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<NewHire>(entity =>
        {
            entity.HasKey(e => e.NewHireId).HasName("PK__NewHire__4D26EC2D4CFEED0C");

            entity.ToTable("NewHire", tb =>
                {
                    tb.HasTrigger("NewHireDeleteTrigger");
                    tb.HasTrigger("NewHireInsertUpdateTrigger");
                });

            entity.HasIndex(e => new { e.Deleted, e.ApplicationId, e.RequisitionId }, "IDX_NewHire_Unique").IsUnique();

            entity.Property(e => e.NewHireId).HasColumnName("NewHireID");
            entity.Property(e => e.ApplicationId)
                .HasDefaultValue(1)
                .HasColumnName("ApplicationID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.NewHireFormId).HasColumnName("NewHireFormID");
            entity.Property(e => e.NewHireStatusTypeId)
                .HasDefaultValue(1)
                .HasColumnName("NewHireStatusTypeID");
            entity.Property(e => e.OnBoardingDate).HasColumnType("datetime");
            entity.Property(e => e.RequisitionId).HasColumnName("RequisitionID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.Application).WithMany(p => p.NewHires)
                .HasForeignKey(d => d.ApplicationId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Application_NewHire_2");

            entity.HasOne(d => d.NewHireForm).WithMany(p => p.NewHires)
                .HasForeignKey(d => d.NewHireFormId)
                .HasConstraintName("FK_Form_NewHire_4");

            entity.HasOne(d => d.NewHireStatusType).WithMany(p => p.NewHires)
                .HasForeignKey(d => d.NewHireStatusTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_NewHireStatusType_NewHire_1");

            entity.HasOne(d => d.Requisition).WithMany(p => p.NewHires)
                .HasForeignKey(d => d.RequisitionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Requisition_NewHire_3");
        });

        modelBuilder.Entity<NewHireDocument>(entity =>
        {
            entity.HasKey(e => e.NewHireDocumentId).HasName("PK__NewHireD__75ABD17A2738CC2C");

            entity.ToTable("NewHireDocument");

            entity.HasIndex(e => new { e.NewHireId, e.DocumentId, e.Deleted }, "IDX_NewHireDocument_NewHireID_DocumentID_Deleted").IsUnique();

            entity.HasIndex(e => new { e.NewHireId, e.Deleted }, "IDX_NewHireID").HasFillFactor(80);

            entity.Property(e => e.NewHireDocumentId).HasColumnName("NewHireDocumentID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DocumentId).HasColumnName("DocumentID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.NewHireId).HasColumnName("NewHireID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.Document).WithMany(p => p.NewHireDocuments)
                .HasForeignKey(d => d.DocumentId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Document_NewHireDocument_2");

            entity.HasOne(d => d.NewHire).WithMany(p => p.NewHireDocuments)
                .HasForeignKey(d => d.NewHireId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_NewHire_NewHireDocument_1");
        });

        modelBuilder.Entity<NewHireFieldValue>(entity =>
        {
            entity.HasKey(e => e.NewHireFieldValueId).HasName("PK__NewHireF__1D39729F4D190785");

            entity.ToTable("NewHireFieldValue", tb =>
                {
                    tb.HasTrigger("NewHireFieldValueDeleteTrigger");
                    tb.HasTrigger("NewHireFieldValueInsertUpdateTrigger");
                });

            entity.HasIndex(e => new { e.GroupId, e.GroupSequenceId, e.ValueInstanceId, e.Deleted, e.MetaTypeId, e.MetaValueId, e.NewHireId }, "IDX_NewHireFieldValue_2").IsUnique();

            entity.HasIndex(e => e.NewHireId, "IDX_NewHireFieldValue_ModDate");

            entity.HasIndex(e => new { e.MetaTypeId, e.Deleted, e.NewHireId, e.GroupSequenceId }, "IDX_NewHireValueDate");

            entity.Property(e => e.NewHireFieldValueId).HasColumnName("NewHireFieldValueID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.GroupId)
                .HasComment("GroupID, GroupSequenceID and ValueInstanceID go hand in hand to define and store Multi Instance Data values with Multiple Values. \r\nGroupID Identifies which group it is.\r\ne.g. 1 is LicenseFields group\r\n2 is EducationGroup\r\n3 is WorkHistory group etc.\r\n\r\nGroupSequenceID identifies the instance of a group.\r\ne.g. if there are 5 licences, first license groupsequenceID is 1, second is 2, third is 3, fourth is 4 and fifth is 5.\r\n\r\nValueInstanceID identifies and stores the multiple values of a metatypeid from the value list. e.g. Skills matrix.. Multiple possible are 1-20, but the selected user values ar 5,11,19 etc.\r\n\r\nThe GroupID and SequenceID are for multiinstance data like the License and its child fields like LicenseState/LicenceName.\r\n\r\nE.g. 3 License details collected will be in GroupIDs 1,2 and 3. Each element values of each Group would have a order collected in Sequence.\r\n\r\n\r\n\r\nMetaTypeID 	GroupId 	SequenceId\r\n1         	                1              	1\r\n1        	                1 		2          \r\n1		1		3\r\n1		2		1\r\n1		2		2\r\n1		2		3\r\n")
                .HasColumnName("GroupID");
            entity.Property(e => e.GroupSequenceId)
                .HasComment("GroupID, GroupSequenceID and ValueInstanceID go hand in hand to define and store Multi Instance Data values with Multiple Values. \r\nGroupID Identifies which group it is.\r\ne.g. 1 is LicenseFields group\r\n2 is EducationGroup\r\n3 is WorkHistory group etc.\r\n\r\nGroupSequenceID identifies the instance of a group.\r\ne.g. if there are 5 licences, first license groupsequenceID is 1, second is 2, third is 3, fourth is 4 and fifth is 5.\r\n\r\nValueInstanceID identifies and stores the multiple values of a metatypeid from the value list. e.g. Skills matrix.. Multiple possible are 1-20, but the selected user values ar 5,11,19 etc.\r\n\r\nThe GroupID and SequenceID are for multiinstance data like the License and its child fields like LicenseState/LicenceName.\r\n\r\nE.g. 3 License details collected will be in GroupIDs 1,2 and 3. Each element values of each Group would have a order collected in Sequence.\r\n\r\n\r\n\r\nMetaTypeID 	GroupId 	SequenceId\r\n1         	                1              	1\r\n1        	                1 		2          \r\n1		1		3\r\n1		2		1\r\n1		2		2\r\n1		2		3\r\n")
                .HasColumnName("GroupSequenceID");
            entity.Property(e => e.MetaTypeId).HasColumnName("MetaTypeID");
            entity.Property(e => e.MetaValueId).HasColumnName("MetaValueID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.NewHireId)
                .HasComment("FK reference to NewHire table.")
                .HasColumnName("NewHireID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsdataTypeId).HasColumnName("TMSDataTypeID");
            entity.Property(e => e.ValueDate).HasColumnType("datetime");
            entity.Property(e => e.ValueInstanceId)
                .HasComment("GroupID, GroupSequenceID and ValueInstanceID go hand in hand to define and store Multi Instance Data values with Multiple Values. \r\nGroupID Identifies which group it is.\r\ne.g. 1 is LicenseFields group\r\n2 is EducationGroup\r\n3 is WorkHistory group etc.\r\n\r\nGroupSequenceID identifies the instance of a group.\r\ne.g. if there are 5 licences, first license groupsequenceID is 1, second is 2, third is 3, fourth is 4 and fifth is 5.\r\n\r\nValueInstanceID identifies and stores the multiple values of a metatypeid from the value list. e.g. Skills matrix.. Multiple possible are 1-20, but the selected user values ar 5,11,19 etc.\r\n\r\nThe GroupID and SequenceID are for multiinstance data like the License and its child fields like LicenseState/LicenceName.\r\n\r\nE.g. 3 License details collected will be in GroupIDs 1,2 and 3. Each element values of each Group would have a order collected in Sequence.\r\n\r\n\r\n\r\nMetaTypeID 	GroupId 	SequenceId\r\n1         	                1              	1\r\n1        	                1 		2          \r\n1		1		3\r\n1		2		1\r\n1		2		2\r\n1		2		3\r\n")
                .HasColumnName("ValueInstanceID");

            entity.HasOne(d => d.MetaType).WithMany(p => p.NewHireFieldValues)
                .HasForeignKey(d => d.MetaTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MetaType_NewHireFieldValue_3");

            entity.HasOne(d => d.MetaValue).WithMany(p => p.NewHireFieldValues)
                .HasForeignKey(d => d.MetaValueId)
                .HasConstraintName("FK_MetaValue_NewHireFieldValue_4");

            entity.HasOne(d => d.NewHire).WithMany(p => p.NewHireFieldValues)
                .HasForeignKey(d => d.NewHireId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_NewHire_NewHireFieldValue_5");

            entity.HasOne(d => d.TmsdataType).WithMany(p => p.NewHireFieldValues)
                .HasForeignKey(d => d.TmsdataTypeId)
                .HasConstraintName("FK_TMSDataType_NewHireFieldValue_2");
        });

        modelBuilder.Entity<NewHireNoteView>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("NewHireNoteView");

            entity.Property(e => e.NewHireId).HasColumnName("NewHireID");
        });

        modelBuilder.Entity<NewHireOrientationDateView>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("NewHireOrientationDateView");

            entity.Property(e => e.NewHireId).HasColumnName("NewHireID");
            entity.Property(e => e.OrientationDate)
                .HasColumnType("datetime")
                .HasColumnName("Orientation_date");
            entity.Property(e => e.OrientationDate2)
                .HasColumnType("datetime")
                .HasColumnName("Orientation_date2");
            entity.Property(e => e.OrientationDate3)
                .HasColumnType("datetime")
                .HasColumnName("Orientation_date3");
            entity.Property(e => e.OrientationDate4)
                .HasColumnType("datetime")
                .HasColumnName("Orientation_date4");
        });

        modelBuilder.Entity<NewHireStartDateView>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("NewHireStartDateView");

            entity.Property(e => e.NewHireId).HasColumnName("NewHireID");
            entity.Property(e => e.StartDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<NewHireStatusType>(entity =>
        {
            entity.HasKey(e => e.NewHireStatusTypeId).HasName("PK__NewHireS__59EFC0CC26D8EB2C");

            entity.ToTable("NewHireStatusType", "Admin");

            entity.HasIndex(e => new { e.Name, e.Deleted }, "IDX_NewHireStatusType_Unique");

            entity.Property(e => e.NewHireStatusTypeId).HasColumnName("NewHireStatusTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DefaultMessage).HasMaxLength(500);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.ShortName).HasMaxLength(15);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<NewHireView>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("NewHireView");

            entity.Property(e => e.ApplicantFirstName).HasMaxLength(100);
            entity.Property(e => e.ApplicantId).HasColumnName("ApplicantID");
            entity.Property(e => e.ApplicantLastName).HasMaxLength(100);
            entity.Property(e => e.ApplicantMiddleName).HasMaxLength(100);
            entity.Property(e => e.ApplicantName).HasMaxLength(202);
            entity.Property(e => e.ApplicationDate).HasColumnType("datetime");
            entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");
            entity.Property(e => e.ApplicationStatusDate).HasColumnType("datetime");
            entity.Property(e => e.ApplicationStatusTypeId).HasColumnName("ApplicationStatusTypeID");
            entity.Property(e => e.ApplicationType).HasMaxLength(100);
            entity.Property(e => e.ApplicationTypeId).HasColumnName("ApplicationTypeID");
            entity.Property(e => e.BusinessEntityId).HasColumnName("BusinessEntityID");
            entity.Property(e => e.City).HasMaxLength(50);
            entity.Property(e => e.Country).HasMaxLength(100);
            entity.Property(e => e.CurrentStatus).HasMaxLength(15);
            entity.Property(e => e.CurrentStatusFullName).HasMaxLength(100);
            entity.Property(e => e.Email).HasMaxLength(256);
            entity.Property(e => e.HiringManagerId).HasColumnName("HiringManagerID");
            entity.Property(e => e.JobCode).HasMaxLength(100);
            entity.Property(e => e.LcoalCountry).HasMaxLength(100);
            entity.Property(e => e.LocalApplicantFirstName).HasMaxLength(100);
            entity.Property(e => e.LocalApplicantId).HasColumnName("LocalApplicantID");
            entity.Property(e => e.LocalApplicantLastName).HasMaxLength(100);
            entity.Property(e => e.LocalApplicantMiddleName).HasMaxLength(100);
            entity.Property(e => e.LocalApplicantName).HasMaxLength(202);
            entity.Property(e => e.LocalCity).HasMaxLength(50);
            entity.Property(e => e.LocalEmail).HasMaxLength(256);
            entity.Property(e => e.LocalPhoneNumber).HasMaxLength(20);
            entity.Property(e => e.LocalPhoneType).HasMaxLength(100);
            entity.Property(e => e.LocalState).HasMaxLength(100);
            entity.Property(e => e.LocalStreet1).HasMaxLength(50);
            entity.Property(e => e.LocalStreet2).HasMaxLength(50);
            entity.Property(e => e.LocalZipcode).HasMaxLength(12);
            entity.Property(e => e.NewHireFormId).HasColumnName("NewHireFormID");
            entity.Property(e => e.NewHireId).HasColumnName("NewHireID");
            entity.Property(e => e.NewHireStatusTypeId).HasColumnName("NewHireStatusTypeID");
            entity.Property(e => e.OnBoardingDate).HasColumnType("datetime");
            entity.Property(e => e.Organization).HasMaxLength(100);
            entity.Property(e => e.OrientationDate)
                .HasColumnType("datetime")
                .HasColumnName("Orientation_date");
            entity.Property(e => e.OrientationDate2)
                .HasColumnType("datetime")
                .HasColumnName("Orientation_date2");
            entity.Property(e => e.OrientationDate3)
                .HasColumnType("datetime")
                .HasColumnName("Orientation_date3");
            entity.Property(e => e.OrientationDate4)
                .HasColumnType("datetime")
                .HasColumnName("Orientation_date4");
            entity.Property(e => e.PhoneNumber).HasMaxLength(20);
            entity.Property(e => e.PhoneType).HasMaxLength(100);
            entity.Property(e => e.RecruiterId).HasColumnName("RecruiterID");
            entity.Property(e => e.RecruiterName).HasMaxLength(206);
            entity.Property(e => e.RequisitionId).HasColumnName("RequisitionID");
            entity.Property(e => e.RequisitionNumber).HasMaxLength(30);
            entity.Property(e => e.RequisitionTitle).HasMaxLength(100);
            entity.Property(e => e.StartDate).HasColumnType("datetime");
            entity.Property(e => e.State).HasMaxLength(100);
            entity.Property(e => e.Street1).HasMaxLength(50);
            entity.Property(e => e.Street2).HasMaxLength(50);
            entity.Property(e => e.Zipcode).HasMaxLength(12);
        });

        modelBuilder.Entity<Note>(entity =>
        {
            entity.HasKey(e => e.NoteId).HasName("PK__Note__EACE357FB478B4A3");

            entity.ToTable("Note", tb => tb.HasTrigger("Note_AuditTriggerAudit"));

            entity.HasIndex(e => new { e.DataSourceTypeId, e.ContextObjectId, e.Deleted }, "IDX_DataSourceTypeID").HasFillFactor(80);

            entity.HasIndex(e => new { e.ContextObjectId, e.DataSourceTypeId }, "IDX_Note_Context_DataSource");

            entity.HasIndex(e => e.Hrisidentifier, "UX_Note_HRISIdentifier")
                .IsUnique()
                .HasFilter("([HRISIdentifier] IS NOT NULL)");

            entity.Property(e => e.NoteId).HasColumnName("NoteID");
            entity.Property(e => e.ContextObjectId).HasColumnName("ContextObjectID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DataSourceTypeId).HasColumnName("DataSourceTypeID");
            entity.Property(e => e.Hrisidentifier)
                .HasMaxLength(64)
                .HasColumnName("HRISIdentifier");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedUserFirstName).HasMaxLength(100);
            entity.Property(e => e.ModifiedUserLastName).HasMaxLength(100);
            entity.Property(e => e.NoteDate).HasColumnType("datetime");
            entity.Property(e => e.RecordId).HasColumnName("RecordID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.Text)
                .HasMaxLength(2000)
                .HasComment("There should always be some text in Text Column");

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.NoteCreatedByNavigations)
                .HasForeignKey(d => d.CreatedBy)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_UserProfile_Note_2");

            entity.HasOne(d => d.DataSourceType).WithMany(p => p.Notes)
                .HasForeignKey(d => d.DataSourceTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DataSourceType_Note_1");

            entity.HasOne(d => d.ModifiedByNavigation).WithMany(p => p.NoteModifiedByNavigations)
                .HasForeignKey(d => d.ModifiedBy)
                .HasConstraintName("FK_UserProfile_Note_3");

            entity.HasOne(d => d.NoteUser).WithMany(p => p.NoteNoteUsers)
                .HasForeignKey(d => d.NoteUserId)
                .HasConstraintName("FK_UserProfile_Note_4");
        });

        modelBuilder.Entity<OnBoardingDocument>(entity =>
        {
            entity.HasKey(e => e.OnBoardingDocumentId).HasName("PK__OnBoardi__13EFFA9A151AC9D9");

            entity.ToTable("OnBoardingDocument", "Admin");

            entity.Property(e => e.OnBoardingDocumentId).HasColumnName("OnBoardingDocumentID");
            entity.Property(e => e.CardFlow).HasMaxLength(100);
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DateActivated).HasColumnType("datetime");
            entity.Property(e => e.DateInActivated).HasColumnType("datetime");
            entity.Property(e => e.DisplayName).HasMaxLength(100);
            entity.Property(e => e.FileLocation).HasMaxLength(1000);
            entity.Property(e => e.FileName).HasMaxLength(100);
            entity.Property(e => e.HreditEnabled).HasColumnName("HREditEnabled");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.OnBoardingDocumentStateTypeId)
                .HasDefaultValue(1)
                .HasColumnName("OnBoardingDocumentStateTypeID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TaskName).HasMaxLength(255);
            entity.Property(e => e.TypeMetaValueId).HasColumnName("TypeMetaValueID");

            entity.HasOne(d => d.OnBoardingDocumentStateType).WithMany(p => p.OnBoardingDocuments)
                .HasForeignKey(d => d.OnBoardingDocumentStateTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_OnBoardingDocumentStateType_OnBoardingDocument");

            entity.HasOne(d => d.TypeMetaValue).WithMany(p => p.OnBoardingDocuments)
                .HasForeignKey(d => d.TypeMetaValueId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MetaValue_OnBoardingDocument_Type");
        });

        modelBuilder.Entity<OnBoardingDocumentBusinessEntity>(entity =>
        {
            entity.HasKey(e => e.OnBoardingDocumentBusinessEntityId).HasName("PK_OnBoardingDocumentBusinessEntityID");

            entity.ToTable("OnBoardingDocumentBusinessEntity", "Admin");

            entity.HasIndex(e => new { e.OnBoardingDocumentId, e.BusinessEntityId, e.Deleted }, "IDX_OnBoardingDocumentBusinessEntity_Unique").IsUnique();

            entity.Property(e => e.OnBoardingDocumentBusinessEntityId).HasColumnName("OnBoardingDocumentBusinessEntityID");
            entity.Property(e => e.BusinessEntityId).HasColumnName("BusinessEntityID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.OnBoardingDocumentId).HasColumnName("OnBoardingDocumentID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.BusinessEntity).WithMany(p => p.OnBoardingDocumentBusinessEntities)
                .HasForeignKey(d => d.BusinessEntityId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessEntity_OnBoardingDocumentBusinessEntity_BusinessEntityID");

            entity.HasOne(d => d.OnBoardingDocument).WithMany(p => p.OnBoardingDocumentBusinessEntities)
                .HasForeignKey(d => d.OnBoardingDocumentId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Template_OnBoardingDocumentBusinessEntity_OnBoardingDocumentID");
        });

        modelBuilder.Entity<OnBoardingDocumentInstance>(entity =>
        {
            entity.HasKey(e => e.OnboardingDocumentInstanceId).HasName("PK__OnBoardi__B61EE48764A67F21");

            entity.ToTable("OnBoardingDocumentInstance");

            entity.HasIndex(e => new { e.OnBoardingDocumentId, e.NewHireId, e.Deleted }, "IDX_OnBoardingDocumentInstance_Unique").IsUnique();

            entity.Property(e => e.OnboardingDocumentInstanceId).HasColumnName("OnboardingDocumentInstanceID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DocumentData).HasComment("This contains the data of the pre-filled or posted Document Instance.  With this data and an Onboarding Document we can generate a new PDF that has the NewHires populated information.");
            entity.Property(e => e.DocumentInstanceSalt)
                .HasMaxLength(50)
                .HasComment("This column contains the cryptography \"Salt\" that is used to symetrically encrypt/decrypt the system data embedded into the Document Instance.  ");
            entity.Property(e => e.FileLocation)
                .HasMaxLength(1000)
                .HasComment("This is the file location (minus filename) for the prefilled or filled out Document Instance form.");
            entity.Property(e => e.FileName)
                .HasMaxLength(100)
                .HasComment("This is the file name (minus path) for the prefilled or filled out Document Instance form.");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.NewHireId).HasColumnName("NewHireID");
            entity.Property(e => e.OnBoardingDocumentId)
                .HasDefaultValue(1)
                .HasColumnName("OnBoardingDocumentID");
            entity.Property(e => e.OnBoardingDocumentStatusTypeId)
                .HasDefaultValue(1)
                .HasColumnName("OnBoardingDocumentStatusTypeID");
            entity.Property(e => e.StatusDate)
                .HasComment("This column stores the last date the document status changed")
                .HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.NewHire).WithMany(p => p.OnBoardingDocumentInstances)
                .HasForeignKey(d => d.NewHireId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_NewHire_OnBoardingDocumentInstance_2");

            entity.HasOne(d => d.OnBoardingDocument).WithMany(p => p.OnBoardingDocumentInstances)
                .HasForeignKey(d => d.OnBoardingDocumentId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_OnBoardingDocument_OnBoardingDocumentInstance_1");

            entity.HasOne(d => d.OnBoardingDocumentStatusType).WithMany(p => p.OnBoardingDocumentInstances)
                .HasForeignKey(d => d.OnBoardingDocumentStatusTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_OnBoardingDocumentStatusType_OnBoardingDocumentInstance_3");
        });

        modelBuilder.Entity<OnBoardingDocumentStateType>(entity =>
        {
            entity.HasKey(e => e.OnBoardingDocumentStateTypeId).HasName("PK__OnBoardi__1B27BCBFCDECE786");

            entity.ToTable("OnBoardingDocumentStateType", "Admin");

            entity.HasIndex(e => new { e.Name, e.Deleted }, "IDX_OnBoardingDocumentStateType_Unique");

            entity.Property(e => e.OnBoardingDocumentStateTypeId).HasColumnName("OnBoardingDocumentStateTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DefaultMessage).HasMaxLength(500);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.ShortName).HasMaxLength(15);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<OnBoardingDocumentStatusType>(entity =>
        {
            entity.HasKey(e => e.OnBoardingDocumentStatusTypeId).HasName("PK__OnBoardi__FB5F47D8C362ADF0");

            entity.ToTable("OnBoardingDocumentStatusType", "Admin");

            entity.HasIndex(e => new { e.Name, e.Deleted }, "IDX_OnBoardingDocumentStatusType_Unique");

            entity.Property(e => e.OnBoardingDocumentStatusTypeId).HasColumnName("OnBoardingDocumentStatusTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DefaultMessage).HasMaxLength(500);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.ShortName).HasMaxLength(15);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<OnBoardingWelcomeMessage>(entity =>
        {
            entity.HasKey(e => e.OnBoardingWelcomeMessageId).HasName("PK__OnBoardi__75976EC4A0F7E9B1");

            entity.ToTable("OnBoardingWelcomeMessage", "Admin");

            entity.HasIndex(e => new { e.Active, e.BusinessEntityId, e.Deleted }, "IDX_OnBoardingWelcomeMessage_2")
                .IsUnique()
                .HasFilter("([Active]=(1))");

            entity.HasIndex(e => new { e.Name, e.Deleted }, "IDX_OnBoardingWelcomeMessage_3").IsUnique();

            entity.Property(e => e.OnBoardingWelcomeMessageId).HasColumnName("OnBoardingWelcomeMessageID");
            entity.Property(e => e.BusinessEntityId).HasColumnName("BusinessEntityID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.BusinessEntity).WithMany(p => p.OnBoardingWelcomeMessages)
                .HasForeignKey(d => d.BusinessEntityId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessEntity_OnBoardingWelcomeMessage_1");
        });

        modelBuilder.Entity<OnboardingDocumentAuditType>(entity =>
        {
            entity.HasKey(e => e.OnboardingDocumentAuditTypeId).HasName("PK__Onboardi__84E0F4F5C7CF2016");

            entity.ToTable("OnboardingDocumentAuditType", "Admin");

            entity.HasIndex(e => e.Name, "IDX_OnboardingDocumentAuditType_Name").IsUnique();

            entity.Property(e => e.OnboardingDocumentAuditTypeId).HasColumnName("OnboardingDocumentAuditTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.ShortName).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<OnboardingEmailSettingsType>(entity =>
        {
            entity.HasKey(e => e.OnboardingEmailSettingsTypeId).HasName("PK__Onboardi__E7C0C901EBBB69E7");

            entity.ToTable("OnboardingEmailSettingsType", "Admin");

            entity.Property(e => e.OnboardingEmailSettingsTypeId).HasColumnName("OnboardingEmailSettingsTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<OnboardingTokenAudit>(entity =>
        {
            entity.HasKey(e => e.OnboardingTokenAuditId).HasName("PK__Onboardi__632DB33031959EAA");

            entity.ToTable("OnboardingTokenAudit", "Admin");

            entity.HasIndex(e => new { e.Token, e.Deleted }, "IDX_OnboardingTokenAudit_Token");

            entity.Property(e => e.OnboardingTokenAuditId).HasColumnName("OnboardingTokenAuditID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.FirstName).HasMaxLength(256);
            entity.Property(e => e.LastFourSsn)
                .HasMaxLength(4)
                .HasColumnName("LastFourSSN");
            entity.Property(e => e.LastName).HasMaxLength(256);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.Token).HasMaxLength(64);
        });

        modelBuilder.Entity<PasswordHistory>(entity =>
        {
            entity.HasKey(e => e.PasswordHistoryId).HasName("PK_PasswordHistoryID");

            entity.ToTable("PasswordHistory", "Auth");

            entity.Property(e => e.PasswordHistoryId).HasColumnName("PasswordHistoryID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Password).HasMaxLength(256);
            entity.Property(e => e.Salt).HasMaxLength(50);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");

            entity.HasOne(d => d.Tmsuser).WithMany(p => p.PasswordHistories)
                .HasForeignKey(d => d.TmsuserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TMSUser_PasswordHistory_1");
        });

        modelBuilder.Entity<Permission>(entity =>
        {
            entity.HasKey(e => e.PermissionId).HasName("PK_PermissionID");

            entity.ToTable("Permission", "Auth");

            entity.HasIndex(e => new { e.Name, e.Deleted, e.PermissionTypeId, e.ParentId }, "UC_Permission_2").IsUnique();

            entity.Property(e => e.PermissionId).HasColumnName("PermissionID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.ParentId).HasColumnName("ParentID");
            entity.Property(e => e.PermissionTypeId).HasColumnName("PermissionTypeID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.Parent).WithMany(p => p.InverseParent)
                .HasForeignKey(d => d.ParentId)
                .HasConstraintName("FK_Permission_Permission_1");

            entity.HasOne(d => d.PermissionType).WithMany(p => p.Permissions)
                .HasForeignKey(d => d.PermissionTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_PermissionType_Permission_2");
        });

        modelBuilder.Entity<PermissionType>(entity =>
        {
            entity.HasKey(e => e.PermissionTypeId).HasName("PK_PermissionTypeID");

            entity.ToTable("PermissionType", "Auth");

            entity.HasIndex(e => new { e.Name, e.Deleted }, "IDX_PermissionType_2").IsUnique();

            entity.Property(e => e.PermissionTypeId).HasColumnName("PermissionTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<Question>(entity =>
        {
            entity.HasKey(e => e.QuestionId).HasName("PK_QuestionID");

            entity.ToTable("Question", "Admin");

            entity.HasIndex(e => e.QuestionnaireId, "IDX_QuestionnaireID").HasFillFactor(80);

            entity.Property(e => e.QuestionId).HasColumnName("QuestionID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.IsRequired).HasDefaultValue(true);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.QuestionDisplayTypeId).HasColumnName("QuestionDisplayTypeID");
            entity.Property(e => e.QuestionnaireId).HasColumnName("QuestionnaireID");
            entity.Property(e => e.Score).HasColumnType("decimal(5, 3)");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.QuestionDisplayType).WithMany(p => p.Questions)
                .HasForeignKey(d => d.QuestionDisplayTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_QuestionDisplayType_Question_1");

            entity.HasOne(d => d.Questionnaire).WithMany(p => p.Questions)
                .HasForeignKey(d => d.QuestionnaireId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Questionnaire_Question_2");
        });

        modelBuilder.Entity<QuestionDisplayType>(entity =>
        {
            entity.HasKey(e => e.QuestionDisplayTypeId).HasName("PK_QuestionDisplayTypeID");

            entity.ToTable("QuestionDisplayType", "Admin");

            entity.HasIndex(e => new { e.Deleted, e.Name }, "IDX_QuestionDisplayType_2").IsUnique();

            entity.Property(e => e.QuestionDisplayTypeId).HasColumnName("QuestionDisplayTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<Questionnaire>(entity =>
        {
            entity.HasKey(e => e.QuestionnaireId).HasName("PK_QuestionnaireID");

            entity.ToTable("Questionnaire", "Admin");

            entity.HasIndex(e => new { e.Name, e.Deleted, e.QuestionnaireTypeId }, "IDX_Questionnaire_2").IsUnique();

            entity.HasIndex(e => new { e.IsMostRecent, e.Deleted }, "IDX_Questionnaire_3");

            entity.Property(e => e.QuestionnaireId).HasColumnName("QuestionnaireID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DisplayName).HasMaxLength(100);
            entity.Property(e => e.Hrisidentifier)
                .HasMaxLength(64)
                .HasComment("The identifier of the Questionnaire in the external system of record.")
                .HasColumnName("HRISIdentifier");
            entity.Property(e => e.InstructionalText).HasMaxLength(500);
            entity.Property(e => e.IsMostRecent)
                .HasDefaultValue(true)
                .HasComment("used to determine if the questionaire is the most recent revision");
            entity.Property(e => e.IsPrivateInstance).HasComment("This flag indicates that the questionnaire is not shared by multipe consumer, which affords more options for editing and saving in place because only a single consumer will be affected. ");
            entity.Property(e => e.IsReadOnly).HasComment("Indicates that the questionnaire is read only. For example a questionnarei, private or templat, that is used by a posted job cannot be changed and is marked read only.");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.OriginalQuestionnaireId).HasColumnName("OriginalQuestionnaireID");
            entity.Property(e => e.QuestionnaireTypeId).HasColumnName("QuestionnaireTypeID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.OriginalQuestionnaire).WithMany(p => p.InverseOriginalQuestionnaire)
                .HasForeignKey(d => d.OriginalQuestionnaireId)
                .HasConstraintName("FK_Questionnaire_Questionnaire_2");

            entity.HasOne(d => d.QuestionnaireType).WithMany(p => p.Questionnaires)
                .HasForeignKey(d => d.QuestionnaireTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_QuestionnaireType_Questionnaire_1");
        });

        modelBuilder.Entity<QuestionnaireResponse>(entity =>
        {
            entity.HasKey(e => e.QuestionnaireResponseId).HasName("PK_QuestionnaireResponseID");

            entity.ToTable("QuestionnaireResponse");

            entity.HasIndex(e => new { e.QuestionnaireId, e.ModifiedDate }, "IDX_QuestionResponse_Modified");

            entity.Property(e => e.QuestionnaireResponseId).HasColumnName("QuestionnaireResponseID");
            entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");
            entity.Property(e => e.Comment).HasMaxLength(500);
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.QuestionnaireId).HasColumnName("QuestionnaireID");
            entity.Property(e => e.RoleTypeId).HasColumnName("RoleTypeID");
            entity.Property(e => e.Score)
                .HasComment("This field stores optional combined scrore of the questionnaire. Note: for a pass/fail type questionnaires it will store 1/0 for pass/fail.")
                .HasColumnType("decimal(6, 3)");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");

            entity.HasOne(d => d.Application).WithMany(p => p.QuestionnaireResponses)
                .HasForeignKey(d => d.ApplicationId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Application_QuestionnaireResponse_4");

            entity.HasOne(d => d.Questionnaire).WithMany(p => p.QuestionnaireResponses)
                .HasForeignKey(d => d.QuestionnaireId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Questionnaire_QuestionnaireResponse_5");

            entity.HasOne(d => d.RoleType).WithMany(p => p.QuestionnaireResponses)
                .HasForeignKey(d => d.RoleTypeId)
                .HasConstraintName("FK_RoleType_QuestionnaireResponse_3");

            entity.HasOne(d => d.Tmsuser).WithMany(p => p.QuestionnaireResponses)
                .HasForeignKey(d => d.TmsuserId)
                .HasConstraintName("FK_UserProfile_QuestionnaireResponse_1");
        });

        modelBuilder.Entity<QuestionnaireResponseAnswer>(entity =>
        {
            entity.HasKey(e => e.QuestionnaireResponseAnswerId)
                .HasName("PK__Question__08F85DCDF3D5F3C1")
                .IsClustered(false);

            entity.ToTable("QuestionnaireResponseAnswer");

            entity.HasIndex(e => new { e.QuestionnaireResponseId, e.ModifiedDate }, "IDX_QuestionAns_ResponseID_Modified");

            entity.HasIndex(e => new { e.QuestionnaireResponseId, e.Deleted }, "IDX_QuestionnaireResponseAnswer_QuestionnaireResponse").IsClustered();

            entity.HasIndex(e => new { e.QuestionnaireResponseId, e.QuestionId, e.AnswerId, e.Deleted }, "UQ__Question__337459B14BB7B476").IsUnique();

            entity.Property(e => e.QuestionnaireResponseAnswerId).HasColumnName("QuestionnaireResponseAnswerID");
            entity.Property(e => e.AnswerId).HasColumnName("AnswerID");
            entity.Property(e => e.AnswerText).HasMaxLength(1000);
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.QuestionId).HasColumnName("QuestionID");
            entity.Property(e => e.QuestionnaireResponseId)
                .HasComment("This field groups sets of answers by an instance of QuestionnaireResponse. QuesionnaireResponse records are created each time a user answers a questionnaire.")
                .HasColumnName("QuestionnaireResponseID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.Answer).WithMany(p => p.QuestionnaireResponseAnswers)
                .HasForeignKey(d => d.AnswerId)
                .HasConstraintName("FK_Answer_QuestionnaireResponseAnswer_3");

            entity.HasOne(d => d.Question).WithMany(p => p.QuestionnaireResponseAnswers)
                .HasForeignKey(d => d.QuestionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Question_QuestionnaireResponseAnswer_2");

            entity.HasOne(d => d.QuestionnaireResponse).WithMany(p => p.QuestionnaireResponseAnswers)
                .HasForeignKey(d => d.QuestionnaireResponseId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_QuestionnaireResponse_QuestionnaireResponseAnswer_10");
        });

        modelBuilder.Entity<QuestionnaireType>(entity =>
        {
            entity.HasKey(e => e.QuestionnaireTypeId).HasName("PK_QuestionnaireTypeID");

            entity.ToTable("QuestionnaireType", "Admin");

            entity.HasIndex(e => new { e.Deleted, e.Name }, "IDX_QuestionnaireType_2").IsUnique();

            entity.Property(e => e.QuestionnaireTypeId).HasColumnName("QuestionnaireTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<RecentActivity>(entity =>
        {
            entity.HasKey(e => e.RecentActivityId).HasName("PK_RecentActivityID");

            entity.ToTable("RecentActivity", "Admin");

            entity.HasIndex(e => new { e.Deleted, e.EntityRecordId, e.TmsuserId, e.DataSourceTypeId }, "IDX_RecentActivity_2").IsUnique();

            entity.Property(e => e.RecentActivityId).HasColumnName("RecentActivityID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DataSourceTypeId).HasColumnName("DataSourceTypeID");
            entity.Property(e => e.EntityRecordId).HasColumnName("EntityRecordID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");

            entity.HasOne(d => d.DataSourceType).WithMany(p => p.RecentActivities)
                .HasForeignKey(d => d.DataSourceTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DataSourceType_RecentActivity_1");
        });

        modelBuilder.Entity<RecentActivity1>(entity =>
        {
            entity.HasKey(e => e.RecentActivityId).HasName("PK_RecentActivityID");

            entity.ToTable("RecentActivity", "Auth");

            entity.HasIndex(e => new { e.DataSourceTypeId, e.Deleted, e.EntityRecordId, e.TmsuserId }, "IDX_RecentActivity_3").IsUnique();

            entity.Property(e => e.RecentActivityId).HasColumnName("RecentActivityID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DataSourceTypeId).HasColumnName("DataSourceTypeID");
            entity.Property(e => e.EntityRecordId).HasColumnName("EntityRecordID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");
        });

        modelBuilder.Entity<RecruitingAuditLog>(entity =>
        {
            entity.HasKey(e => e.RecruitingAuditLogId).HasName("PK_RecruitingAuditLogID");

            entity.ToTable("RecruitingAuditLog");

            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Entity).HasMaxLength(50);
            entity.Property(e => e.EntityId).HasColumnName("EntityID");
            entity.Property(e => e.EntityType).HasMaxLength(100);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Operation).HasMaxLength(500);
            entity.Property(e => e.OperationTime).HasColumnType("datetime");
            entity.Property(e => e.Reason).HasMaxLength(4000);
            entity.Property(e => e.Result).HasMaxLength(4);
            entity.Property(e => e.Suid).HasColumnName("SUID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");

            entity.HasOne(d => d.Tmsuser).WithMany(p => p.RecruitingAuditLogs)
                .HasForeignKey(d => d.TmsuserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_UserProfile_RecruitingAuditLog");
        });

        modelBuilder.Entity<RefactorAssessmentsVendorOrderTableMigration>(entity =>
        {
            entity.HasKey(e => e.VendorOrderDetailId).HasName("PK__Refactor__B00F0287C9CC09B5");

            entity.ToTable("Refactor_AssessmentsVendorOrderTableMigration");

            entity.Property(e => e.VendorOrderDetailId).HasColumnName("VendorOrderDetailID");
            entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");
            entity.Property(e => e.AssessmentVendorOrderDetailId).HasColumnName("AssessmentVendorOrderDetailID");
            entity.Property(e => e.CompletionDate).HasColumnType("datetime");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Description).HasMaxLength(255);
            entity.Property(e => e.ExpirationDate).HasColumnType("datetime");
            entity.Property(e => e.InviteUrl).HasMaxLength(2000);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.OrderProcessingRedirectUrl).HasMaxLength(2000);
            entity.Property(e => e.ResultDescription).HasMaxLength(255);
            entity.Property(e => e.ResultLink).HasMaxLength(2000);
            entity.Property(e => e.ResultLinkName).HasMaxLength(100);
            entity.Property(e => e.Score).HasMaxLength(100);
            entity.Property(e => e.StatusCode).HasMaxLength(50);
            entity.Property(e => e.StatusReason).HasMaxLength(255);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.VendorId).HasColumnName("VendorID");
            entity.Property(e => e.VendorOrderId).HasColumnName("VendorOrderID");
            entity.Property(e => e.VendorOrderIdentifier).HasMaxLength(64);
            entity.Property(e => e.VendorOrderStatusTypeId).HasColumnName("VendorOrderStatusTypeID");
            entity.Property(e => e.VendorOrderSubtypeIdentifier).HasMaxLength(100);
            entity.Property(e => e.VendorOrderTypeId).HasColumnName("VendorOrderTypeID");
            entity.Property(e => e.VendorUserAccountId).HasColumnName("VendorUserAccountID");

            entity.HasOne(d => d.Vendor).WithMany(p => p.RefactorAssessmentsVendorOrderTableMigrations)
                .HasForeignKey(d => d.VendorId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_AssessmentsMigration_Vendor");

            entity.HasOne(d => d.VendorOrderStatusType).WithMany(p => p.RefactorAssessmentsVendorOrderTableMigrations)
                .HasForeignKey(d => d.VendorOrderStatusTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_AssessmentsMigration_VendorOrderStatusType");

            entity.HasOne(d => d.VendorOrderType).WithMany(p => p.RefactorAssessmentsVendorOrderTableMigrations)
                .HasForeignKey(d => d.VendorOrderTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_AssessmentsMigration_VendorOrderType");

            entity.HasOne(d => d.VendorUserAccount).WithMany(p => p.RefactorAssessmentsVendorOrderTableMigrations)
                .HasForeignKey(d => d.VendorUserAccountId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_AssessmentsMigration_VendorUserAccount");
        });

        modelBuilder.Entity<RefactorVendorOrderVendorOrderDetailMapping>(entity =>
        {
            entity.HasKey(e => e.VendorOrderDetailId).HasName("PK__Refactor__B00F02870F962595");

            entity.ToTable("Refactor_VendorOrderVendorOrderDetailMapping");

            entity.Property(e => e.VendorOrderDetailId)
                .ValueGeneratedNever()
                .HasColumnName("VendorOrderDetailID");
            entity.Property(e => e.AssessmentVendorOrderDetailId).HasColumnName("AssessmentVendorOrderDetailID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.VendorOrderId).HasColumnName("VendorOrderID");
            entity.Property(e => e.VendorOrderVendorOrderDetailMappingId)
                .ValueGeneratedOnAdd()
                .HasColumnName("VendorOrderVendorOrderDetailMappingID");

            entity.HasOne(d => d.VendorOrderDetail).WithOne(p => p.RefactorVendorOrderVendorOrderDetailMapping)
                .HasForeignKey<RefactorVendorOrderVendorOrderDetailMapping>(d => d.VendorOrderDetailId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Refactor_VendorOrderVendorOrderDetailMapping_VendorOrderDetail");

            entity.HasOne(d => d.VendorOrder).WithMany(p => p.RefactorVendorOrderVendorOrderDetailMappings)
                .HasForeignKey(d => d.VendorOrderId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Refactor_VendorOrderVendorOrderDetailMapping_VendorOrder");
        });

        modelBuilder.Entity<ReferenceAssessmentReference>(entity =>
        {
            entity.HasKey(e => e.ReferenceAssessmentReferenceId).HasName("PK_ReferenceAssessmentReferenceID");

            entity.ToTable("ReferenceAssessmentReference");

            entity.HasIndex(e => new { e.VendorOrderId, e.ReferenceIdentifier, e.Deleted }, "UX_ReferenceAssessmentReference_Natural").IsUnique();

            entity.HasIndex(e => new { e.ReferenceAssessmentReferenceId, e.Deleted }, "UX_ReferenceAssessmentReference_PK").IsUnique();

            entity.Property(e => e.ReferenceAssessmentReferenceId).HasColumnName("ReferenceAssessmentReferenceID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.FirstName).HasMaxLength(100);
            entity.Property(e => e.LastName).HasMaxLength(100);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Status).HasMaxLength(25);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.VendorOrderId).HasColumnName("VendorOrderID");

            entity.HasOne(d => d.VendorOrder).WithMany(p => p.ReferenceAssessmentReferences)
                .HasForeignKey(d => d.VendorOrderId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_VendorOrder_ReferenceAssessmentReference");
        });

        modelBuilder.Entity<ReferenceBenchmarkType>(entity =>
        {
            entity.HasKey(e => e.ReferenceBenchmarkTypeId).HasName("PK_ReferenceBenchmarkTypeID");

            entity.ToTable("ReferenceBenchmarkType", "Admin");

            entity.Property(e => e.ReferenceBenchmarkTypeId).HasColumnName("ReferenceBenchmarkTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Hrisidentifier)
                .HasMaxLength(64)
                .HasColumnName("HRISIdentifier");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.ParentId).HasColumnName("ParentID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.Parent).WithMany(p => p.InverseParent)
                .HasForeignKey(d => d.ParentId)
                .HasConstraintName("FK__ReferenceBenchmarkType_Category");
        });

        modelBuilder.Entity<ReferenceCheckApplicationLock>(entity =>
        {
            entity.HasKey(e => e.ReferenceCheckApplicationLockId).HasName("PK_ReferenceCheckApplicationLockID");

            entity.ToTable("ReferenceCheckApplicationLock");

            entity.HasIndex(e => new { e.ApplicationId, e.Deleted }, "IDX_ReferenceCheckApplicationLock_UX").IsUnique();

            entity.Property(e => e.ReferenceCheckApplicationLockId).HasColumnName("ReferenceCheckApplicationLockID");
            entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.Application).WithMany(p => p.ReferenceCheckApplicationLocks)
                .HasForeignKey(d => d.ApplicationId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Application_ReferenceCheckApplicationLock_1");
        });

        modelBuilder.Entity<Report>(entity =>
        {
            entity.HasKey(e => e.ReportId).HasName("PK_ReportID");

            entity.ToTable("Report", "Admin");

            entity.HasIndex(e => new { e.Name, e.Deleted, e.ReportCategoryId }, "IDX_Report_2").IsUnique();

            entity.Property(e => e.ReportId).HasColumnName("ReportID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Description).HasMaxLength(4000);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.ReportCategoryId).HasColumnName("ReportCategoryID");
            entity.Property(e => e.ReportUrl)
                .HasMaxLength(512)
                .HasColumnName("ReportURL");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.ReportCategory).WithMany(p => p.Reports)
                .HasForeignKey(d => d.ReportCategoryId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ReportCategory_Report_1");
        });

        modelBuilder.Entity<ReportCategory>(entity =>
        {
            entity.HasKey(e => e.ReportCategoryId).HasName("PK_ReportCategoryID");

            entity.ToTable("ReportCategory", "Admin");

            entity.HasIndex(e => new { e.Name, e.Deleted }, "IDX_ReportCategory_2").IsUnique();

            entity.Property(e => e.ReportCategoryId).HasColumnName("ReportCategoryID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.IsHidden).HasComment("IsHidden can be used to specify a set of reports to make unavailable. (e.g. not show in the UI)");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<Requisition>(entity =>
        {
            entity.HasKey(e => e.RequisitionId).HasName("PK__Requisit__C347820F97B6A6A4");

            entity.ToTable("Requisition", tb =>
                {
                    tb.HasTrigger("RequisitionDeleteTrigger");
                    tb.HasTrigger("RequisitionInsertUpdateTrigger");
                    tb.HasTrigger("Requisition_AuditTriggerAudit");
                });

            entity.HasIndex(e => e.RecruiterId, "IDX_RecruiterID").HasFillFactor(80);

            entity.HasIndex(e => e.RequisitionId, "IDX_Requisition_Cover");

            entity.Property(e => e.RequisitionId).HasColumnName("RequisitionID");
            entity.Property(e => e.ApproverId)
                .HasComment("Represents the TMSUserID of the current approver of the requisition.  If the requisition is not in the approval process, the value should be NULL.  ")
                .HasColumnName("ApproverID");
            entity.Property(e => e.BusinessEntityId).HasColumnName("BusinessEntityID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.CreatorApprovalComment).HasMaxLength(2500);
            entity.Property(e => e.FilledByApplicantId).HasColumnName("FilledByApplicantID");
            entity.Property(e => e.FilledDate)
                .HasComment("This is the date the Requisition was moved to 'Filled' Status, or Null if not in that status.")
                .HasColumnType("datetime");
            entity.Property(e => e.FormId).HasColumnName("FormID");
            entity.Property(e => e.Fte).HasColumnName("FTE");
            entity.Property(e => e.HiringManagerId).HasColumnName("HiringManagerID");
            entity.Property(e => e.IncludeHmcommunication).HasColumnName("IncludeHMCommunication");
            entity.Property(e => e.JobTemplateInstanceId).HasColumnName("JobTemplateInstanceID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.OpenReasonMetaValueId).HasColumnName("OpenReasonMetaValueID");
            entity.Property(e => e.RecruiterId).HasColumnName("RecruiterID");
            entity.Property(e => e.RequisitionNumber).HasMaxLength(30);
            entity.Property(e => e.RequisitionStatusTypeId).HasColumnName("RequisitionStatusTypeID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.Approver).WithMany(p => p.RequisitionApprovers)
                .HasForeignKey(d => d.ApproverId)
                .HasConstraintName("FK_UserProfile_Requisition_8");

            entity.HasOne(d => d.BusinessEntity).WithMany(p => p.Requisitions)
                .HasForeignKey(d => d.BusinessEntityId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessEntity_Requisition_2");

            entity.HasOne(d => d.FilledByApplicant).WithMany(p => p.Requisitions)
                .HasForeignKey(d => d.FilledByApplicantId)
                .HasConstraintName("FK_LocalApplicant_Requisition_9");

            entity.HasOne(d => d.Form).WithMany(p => p.Requisitions)
                .HasForeignKey(d => d.FormId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Form_Requisition_3");

            entity.HasOne(d => d.HiringManager).WithMany(p => p.RequisitionHiringManagers)
                .HasForeignKey(d => d.HiringManagerId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_UserProfile_Requisition_7");

            entity.HasOne(d => d.JobTemplateInstance).WithMany(p => p.Requisitions)
                .HasForeignKey(d => d.JobTemplateInstanceId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobTemplateInstance_Requisition_1");

            entity.HasOne(d => d.OpenReasonMetaValue).WithMany(p => p.Requisitions)
                .HasForeignKey(d => d.OpenReasonMetaValueId)
                .HasConstraintName("FK_MetaValue_Requisition_5");

            entity.HasOne(d => d.Recruiter).WithMany(p => p.RequisitionRecruiters)
                .HasForeignKey(d => d.RecruiterId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_UserProfile_Requisition_6");

            entity.HasOne(d => d.RequisitionStatusType).WithMany(p => p.Requisitions)
                .HasForeignKey(d => d.RequisitionStatusTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_RequisitionStatusType_Requisition_4");
        });

        modelBuilder.Entity<RequisitionAcl>(entity =>
        {
            entity.HasKey(e => e.RequisitionAclid).HasName("PK__Requisit__FDEDF2A0545F590E");

            entity.ToTable("RequisitionACL");

            entity.HasIndex(e => new { e.RequisitionId, e.TmsuserId, e.Deleted }, "IDX_RequisitionID").HasFillFactor(80);

            entity.Property(e => e.RequisitionAclid).HasColumnName("RequisitionACLID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.RequisitionId).HasColumnName("RequisitionID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");

            entity.HasOne(d => d.Requisition).WithMany(p => p.RequisitionAcls)
                .HasForeignKey(d => d.RequisitionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Requisition_RequisitionACL_8");

            entity.HasOne(d => d.Tmsuser).WithMany(p => p.RequisitionAcls)
                .HasForeignKey(d => d.TmsuserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_UserProfile_RequisitionACL_9");
        });

        modelBuilder.Entity<RequisitionAdditionalUser>(entity =>
        {
            entity.HasKey(e => e.RequisitionAdditionalUserId).HasName("PK__Requisit__28D7A4457BAF4A9E");

            entity.ToTable("RequisitionAdditionalUser");

            entity.HasIndex(e => new { e.RequisitionId, e.Deleted }, "IDX_RequisitionID");

            entity.HasIndex(e => new { e.RequisitionId, e.TmsuserId, e.Deleted }, "UX_RequisitionAdditionalUser").IsUnique();

            entity.Property(e => e.RequisitionAdditionalUserId).HasColumnName("RequisitionAdditionalUserID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.RequisitionId).HasColumnName("RequisitionID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");

            entity.HasOne(d => d.Requisition).WithMany(p => p.RequisitionAdditionalUsers)
                .HasForeignKey(d => d.RequisitionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Requisition_RequisitionAdditionalUser_1");

            entity.HasOne(d => d.Tmsuser).WithMany(p => p.RequisitionAdditionalUsers)
                .HasForeignKey(d => d.TmsuserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("RequisitionAdditionalUser_2");
        });

        modelBuilder.Entity<RequisitionApprover>(entity =>
        {
            entity.HasKey(e => e.RequisitionApproverId).HasName("PK__Requisit__0192B269717EA508");

            entity.ToTable("RequisitionApprover");

            entity.Property(e => e.RequisitionApproverId).HasColumnName("RequisitionApproverID");
            entity.Property(e => e.Comment).HasMaxLength(2500);
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.RequisitionId).HasColumnName("RequisitionID");
            entity.Property(e => e.ResponseDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");

            entity.HasOne(d => d.Requisition).WithMany(p => p.RequisitionApprovers)
                .HasForeignKey(d => d.RequisitionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Requisition_RequisitionApprover_1");

            entity.HasOne(d => d.Tmsuser).WithMany(p => p.RequisitionApproversNavigation)
                .HasForeignKey(d => d.TmsuserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_UserProfile_RequisitionApprover_2");
        });

        modelBuilder.Entity<RequisitionAuditType>(entity =>
        {
            entity.HasKey(e => e.RequisitionAuditTypeId).HasName("PK__Requisit__04CE0FB472173062");

            entity.ToTable("RequisitionAuditType", "Admin");

            entity.HasIndex(e => e.Name, "IDX_RequisitionAuditType_Name").IsUnique();

            entity.Property(e => e.RequisitionAuditTypeId).HasColumnName("RequisitionAuditTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<RequisitionDocument>(entity =>
        {
            entity.HasKey(e => e.RequisitionDocumentId).HasName("PK__Requisit__42557DC248A54153");

            entity.ToTable("RequisitionDocument", tb => tb.HasTrigger("RequisitionDocument_AuditTriggerAudit"));

            entity.HasIndex(e => new { e.DocumentId, e.RequisitionId, e.Deleted }, "IDX_RequisitionDocument_RequisitionID_DocumentID_Deleted").IsUnique();

            entity.Property(e => e.RequisitionDocumentId).HasColumnName("RequisitionDocumentID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DocumentId).HasColumnName("DocumentID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.RequisitionId).HasColumnName("RequisitionID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.Document).WithMany(p => p.RequisitionDocuments)
                .HasForeignKey(d => d.DocumentId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Document_RequisitionDocument_3");

            entity.HasOne(d => d.Requisition).WithMany(p => p.RequisitionDocuments)
                .HasForeignKey(d => d.RequisitionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Requisition_RequisitionDocument_2");
        });

        modelBuilder.Entity<RequisitionFieldValue>(entity =>
        {
            entity.HasKey(e => e.RequisitionFieldValueId).HasName("PK__Requisit__69E946157F178E7A");

            entity.ToTable("RequisitionFieldValue", tb => tb.HasTrigger("RequisitionFieldValue_AuditTriggerAudit"));

            entity.HasIndex(e => new { e.RequisitionId, e.GroupId, e.GroupSequenceId, e.ValueInstanceId, e.MetaTypeId, e.MetaValueId, e.Deleted }, "IDX_RequisitionFieldValue_2").IsUnique();

            entity.Property(e => e.RequisitionFieldValueId).HasColumnName("RequisitionFieldValueID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.GroupId)
                .HasComment("GroupID, GroupSequenceID and ValueInstanceID go hand in hand to define and store Multi Instance Data values with Multiple Values. \r\nGroupID Identifies which group it is.\r\ne.g. 1 is LicenseFields group\r\n2 is EducationGroup\r\n3 is WorkHistory group etc.\r\n\r\nGroupSequenceID identifies the instance of a group.\r\ne.g. if there are 5 licences, first license groupsequenceID is 1, second is 2, third is 3, fourth is 4 and fifth is 5.\r\n\r\nValueInstanceID identifies and stores the multiple values of a metatypeid from the value list. e.g. Skills matrix.. Multiple possible are 1-20, but the selected user values ar 5,11,19 etc.\r\n\r\nThe GroupID and SequenceID are for multiinstance data like the License and its child fields like LicenseState/LicenceName.\r\n\r\nE.g. 3 License details collected will be in GroupIDs 1,2 and 3. Each element values of each Group would have a order collected in Sequence.\r\n\r\n\r\n\r\nMetaTypeID 	GroupId 	SequenceId\r\n1         	                1              	1\r\n1        	                1 		2          \r\n1		1		3\r\n1		2		1\r\n1		2		2\r\n1		2		3\r\n")
                .HasColumnName("GroupID");
            entity.Property(e => e.GroupSequenceId)
                .HasComment("GroupID, GroupSequenceID and ValueInstanceID go hand in hand to define and store Multi Instance Data values with Multiple Values. \r\nGroupID Identifies which group it is.\r\ne.g. 1 is LicenseFields group\r\n2 is EducationGroup\r\n3 is WorkHistory group etc.\r\n\r\nGroupSequenceID identifies the instance of a group.\r\ne.g. if there are 5 licences, first license groupsequenceID is 1, second is 2, third is 3, fourth is 4 and fifth is 5.\r\n\r\nValueInstanceID identifies and stores the multiple values of a metatypeid from the value list. e.g. Skills matrix.. Multiple possible are 1-20, but the selected user values ar 5,11,19 etc.\r\n\r\nThe GroupID and SequenceID are for multiinstance data like the License and its child fields like LicenseState/LicenceName.\r\n\r\nE.g. 3 License details collected will be in GroupIDs 1,2 and 3. Each element values of each Group would have a order collected in Sequence.\r\n\r\n\r\n\r\nMetaTypeID 	GroupId 	SequenceId\r\n1         	                1              	1\r\n1        	                1 		2          \r\n1		1		3\r\n1		2		1\r\n1		2		2\r\n1		2		3\r\n")
                .HasColumnName("GroupSequenceID");
            entity.Property(e => e.MetaTypeId).HasColumnName("MetaTypeID");
            entity.Property(e => e.MetaValueId).HasColumnName("MetaValueID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.RequisitionId).HasColumnName("RequisitionID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsdataTypeId).HasColumnName("TMSDataTypeID");
            entity.Property(e => e.ValueDate).HasColumnType("datetime");
            entity.Property(e => e.ValueInstanceId)
                .HasComment("GroupID, GroupSequenceID and ValueInstanceID go hand in hand to define and store Multi Instance Data values with Multiple Values. \r\nGroupID Identifies which group it is.\r\ne.g. 1 is LicenseFields group\r\n2 is EducationGroup\r\n3 is WorkHistory group etc.\r\n\r\nGroupSequenceID identifies the instance of a group.\r\ne.g. if there are 5 licences, first license groupsequenceID is 1, second is 2, third is 3, fourth is 4 and fifth is 5.\r\n\r\nValueInstanceID identifies and stores the multiple values of a metatypeid from the value list. e.g. Skills matrix.. Multiple possible are 1-20, but the selected user values ar 5,11,19 etc.\r\n\r\nThe GroupID and SequenceID are for multiinstance data like the License and its child fields like LicenseState/LicenceName.\r\n\r\nE.g. 3 License details collected will be in GroupIDs 1,2 and 3. Each element values of each Group would have a order collected in Sequence.\r\n\r\n\r\n\r\nMetaTypeID 	GroupId 	SequenceId\r\n1         	                1              	1\r\n1        	                1 		2          \r\n1		1		3\r\n1		2		1\r\n1		2		2\r\n1		2		3\r\n")
                .HasColumnName("ValueInstanceID");

            entity.HasOne(d => d.MetaType).WithMany(p => p.RequisitionFieldValues)
                .HasForeignKey(d => d.MetaTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MetaType_RequisitionFieldValue");

            entity.HasOne(d => d.MetaValue).WithMany(p => p.RequisitionFieldValues)
                .HasForeignKey(d => d.MetaValueId)
                .HasConstraintName("FK_MetaValue_RequisitionFieldValue_5");

            entity.HasOne(d => d.Requisition).WithMany(p => p.RequisitionFieldValues)
                .HasForeignKey(d => d.RequisitionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Requisition_RequisitionFieldValue_1");

            entity.HasOne(d => d.TmsdataType).WithMany(p => p.RequisitionFieldValues)
                .HasForeignKey(d => d.TmsdataTypeId)
                .HasConstraintName("FK_TMSDataType_RequisitionFieldValue_6");
        });

        modelBuilder.Entity<RequisitionSequence>(entity =>
        {
            entity.HasKey(e => e.RequisitionSequenceId).HasName("PK__Requisit__F3CAFF0CDF316F20");

            entity.ToTable("RequisitionSequence");

            entity.Property(e => e.RequisitionSequenceId).HasColumnName("RequisitionSequenceID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<RequisitionStatusType>(entity =>
        {
            entity.HasKey(e => e.RequisitionStatusTypeId).HasName("PK__Requisit__B58E085B926FB669");

            entity.ToTable("RequisitionStatusType");

            entity.Property(e => e.RequisitionStatusTypeId).HasColumnName("RequisitionStatusTypeID");
            entity.Property(e => e.ApplicantFilter).HasComment("Flag used to indicate if type should be included in the Manage Applications Search's Job Posting Status filter.");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<RequisitionVendorOrder>(entity =>
        {
            entity.HasKey(e => e.RequisitionVendorOrderId).HasName("PK_RequisitionVendorOrderID");

            entity.ToTable("RequisitionVendorOrder");

            entity.HasIndex(e => new { e.RequisitionId, e.VendorOrderId, e.Deleted }, "IDX_RequisitionVendorOrder_2").IsUnique();

            entity.Property(e => e.RequisitionVendorOrderId).HasColumnName("RequisitionVendorOrderID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.RequisitionId).HasColumnName("RequisitionID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.VendorOrderId).HasColumnName("VendorOrderID");

            entity.HasOne(d => d.Requisition).WithMany(p => p.RequisitionVendorOrders)
                .HasForeignKey(d => d.RequisitionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Requisition_RequisitionVendorOrder_1");

            entity.HasOne(d => d.VendorOrder).WithMany(p => p.RequisitionVendorOrders)
                .HasForeignKey(d => d.VendorOrderId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_VendorOrder_RequisitionVendorOrder_2");
        });

        modelBuilder.Entity<RequisitionView>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("RequisitionView");

            entity.Property(e => e.ApproverId).HasColumnName("ApproverID");
            entity.Property(e => e.BusinessEntityId).HasColumnName("BusinessEntityID");
            entity.Property(e => e.CategoryId).HasColumnName("CategoryID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.EndDate).HasColumnType("datetime");
            entity.Property(e => e.EndInternalOnlyDate).HasColumnType("datetime");
            entity.Property(e => e.FilledDate).HasColumnType("datetime");
            entity.Property(e => e.Fte).HasColumnName("FTE");
            entity.Property(e => e.HiredApplicant).HasMaxLength(202);
            entity.Property(e => e.HiringManagerFirstName).HasMaxLength(100);
            entity.Property(e => e.HiringManagerId).HasColumnName("HiringManagerID");
            entity.Property(e => e.HiringManagerLastName).HasMaxLength(100);
            entity.Property(e => e.HiringManagerMiddleName).HasMaxLength(100);
            entity.Property(e => e.HiringManagerPhone).HasMaxLength(24);
            entity.Property(e => e.Hours).HasMaxLength(100);
            entity.Property(e => e.Hrisidentifier)
                .HasMaxLength(64)
                .HasColumnName("HRISIdentifier");
            entity.Property(e => e.JobCategory).HasMaxLength(100);
            entity.Property(e => e.JobCode).HasMaxLength(100);
            entity.Property(e => e.JobPostingCreatedDate).HasColumnType("datetime");
            entity.Property(e => e.JobPostingDisplayTitle).HasMaxLength(100);
            entity.Property(e => e.JobPostingId).HasColumnName("JobPostingID");
            entity.Property(e => e.JobPostingTitle).HasMaxLength(100);
            entity.Property(e => e.JobTemplateInstanceModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Organization).HasMaxLength(100);
            entity.Property(e => e.PositionTitle).HasMaxLength(100);
            entity.Property(e => e.RecruiterFirstName).HasMaxLength(100);
            entity.Property(e => e.RecruiterId).HasColumnName("RecruiterID");
            entity.Property(e => e.RecruiterLastName).HasMaxLength(100);
            entity.Property(e => e.RecruiterMiddleName).HasMaxLength(100);
            entity.Property(e => e.RecruiterPhone).HasMaxLength(24);
            entity.Property(e => e.RequisitionId).HasColumnName("RequisitionID");
            entity.Property(e => e.RequisitionNumber).HasMaxLength(30);
            entity.Property(e => e.RequisitionStatusType).HasMaxLength(100);
            entity.Property(e => e.RequisitionStatusTypeId).HasColumnName("RequisitionStatusTypeID");
            entity.Property(e => e.Schedule).HasMaxLength(100);
            entity.Property(e => e.ScheduleId).HasColumnName("ScheduleID");
            entity.Property(e => e.Shift).HasMaxLength(100);
            entity.Property(e => e.ShiftId).HasColumnName("ShiftID");
            entity.Property(e => e.StartDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<RequisitionWorkflowAudit>(entity =>
        {
            entity.HasKey(e => e.RequisitionWorkflowAuditId).HasName("PK__Requisit__C4FDF699CB7E02B9");

            entity.ToTable("RequisitionWorkflowAudit");

            entity.Property(e => e.RequisitionWorkflowAuditId).HasColumnName("RequisitionWorkflowAuditID");
            entity.Property(e => e.Comment).HasMaxLength(2000);
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.RequisitionAuditTypeId).HasColumnName("RequisitionAuditTypeID");
            entity.Property(e => e.RequisitionId)
                .HasComment("No foreign key to dbo.Requisition.RequisitionID due to contention problems with the Requisition Workflow accessing the same Requisition record that in some scenarios is locked by PM.\r\n\r\nWe will add the foreign key back once the contention problem has been address.")
                .HasColumnName("RequisitionID");
            entity.Property(e => e.RequisitionStatusTypeId).HasColumnName("RequisitionStatusTypeID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");
        });

        modelBuilder.Entity<RequisitionWorkflowRestartFailureLog>(entity =>
        {
            entity.HasKey(e => e.RequisitionWorkflowRestartFailureLogId).HasName("PK__Requisit__13E4DAB4448D3D9C");

            entity.ToTable("RequisitionWorkflowRestartFailureLog");

            entity.Property(e => e.RequisitionWorkflowRestartFailureLogId).HasColumnName("RequisitionWorkflowRestartFailureLogID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.RequisitionId).HasColumnName("RequisitionID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.WorkflowProcessId).HasColumnName("WorkflowProcessID");
        });

        modelBuilder.Entity<Role>(entity =>
        {
            entity.HasKey(e => e.RoleId).HasName("PK__Role__8AFACE3A0922E109");

            entity.ToTable("Role", "Auth");

            entity.HasIndex(e => new { e.Name, e.Deleted }, "IDX_Role_2").IsUnique();

            entity.Property(e => e.RoleId).HasColumnName("RoleID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DashboardCountTypeId).HasColumnName("DashboardCountTypeID");
            entity.Property(e => e.Description).HasMaxLength(255);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.MyOwnAcldataSourceTypeId).HasColumnName("MyOwnACLDataSourceTypeID");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.RoleTypeId).HasColumnName("RoleTypeID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.RoleType).WithMany(p => p.Roles)
                .HasForeignKey(d => d.RoleTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_RoleType_Role_2");
        });

        modelBuilder.Entity<RolePermission>(entity =>
        {
            entity.HasKey(e => e.RolePermissionId).HasName("PK__RolePerm__120F469ACF992FDC");

            entity.ToTable("RolePermission", "Auth");

            entity.HasIndex(e => new { e.RoleId, e.PermissionId, e.Deleted }, "IDX_RolePermission_2").IsUnique();

            entity.Property(e => e.RolePermissionId).HasColumnName("RolePermissionID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.PermissionId).HasColumnName("PermissionID");
            entity.Property(e => e.RoleId).HasColumnName("RoleID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.Permission).WithMany(p => p.RolePermissions)
                .HasForeignKey(d => d.PermissionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Permission_RolePermission_2");

            entity.HasOne(d => d.Role).WithMany(p => p.RolePermissions)
                .HasForeignKey(d => d.RoleId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Role_RolePermission_1");
        });

        modelBuilder.Entity<RoleType>(entity =>
        {
            entity.HasKey(e => e.RoleTypeId).HasName("PK_RoleTypeID");

            entity.ToTable("RoleType", "Admin");

            entity.HasIndex(e => new { e.Deleted, e.Name }, "IDX_RoleType_2").IsUnique();

            entity.Property(e => e.RoleTypeId)
                .ValueGeneratedNever()
                .HasColumnName("RoleTypeID");
            entity.Property(e => e.AccessAllCommunications).HasComment("This bit, if set, indicates that the user role has access to view all communications and not just role specific communications.\r\n\r\nE.g: Recuiters can see All communications, hiring managers can only see communications that they have started or need to respond to.");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Description).HasMaxLength(255);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.Rank)
                .HasDefaultValue(1)
                .HasComment("If user has multiple position Types(Roles), the rank is a integer number given to the Role.If a user has multiple roles, the role with the higher rank is considered as default role.");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<RoleType1>(entity =>
        {
            entity.HasKey(e => e.RoleTypeId).HasName("PK__RoleType__3E6973396AC48192");

            entity.ToTable("RoleType", "Auth");

            entity.HasIndex(e => new { e.Name, e.Deleted }, "IDX_RoleType_2").IsUnique();

            entity.Property(e => e.RoleTypeId).HasColumnName("RoleTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.MyOwnAcldataSourceTypeDefaultId).HasColumnName("MyOwnACLDataSourceTypeDefaultID");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.ProductTypeId).HasColumnName("ProductTypeID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<Search>(entity =>
        {
            entity.HasKey(e => e.SearchId).HasName("PK__Search__21C5351471F9DFF7");

            entity.ToTable("Search", "Admin");

            entity.HasIndex(e => new { e.DataSourceTypeId, e.TmsuserId, e.Name, e.Deleted }, "IDX_Name_TMSUserID_DataSourceTypeID_Deleted").IsUnique();

            entity.Property(e => e.SearchId).HasColumnName("SearchID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Criteria).HasColumnType("xml");
            entity.Property(e => e.DataSourceTypeId).HasColumnName("DataSourceTypeID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");

            entity.HasOne(d => d.DataSourceType).WithMany(p => p.Searches)
                .HasForeignKey(d => d.DataSourceTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Search_DataSourceType");
        });

        modelBuilder.Entity<SettingsApplyLimit>(entity =>
        {
            entity.HasKey(e => e.SettingsApplyLimitId).HasName("PK__Settings__6645FB04DDBC3AB7");

            entity.ToTable("SettingsApplyLimit", "Admin");

            entity.HasIndex(e => new { e.LimitType, e.Deleted }, "IDX_SettingsApplyLimit_2").IsUnique();

            entity.Property(e => e.SettingsApplyLimitId).HasColumnName("SettingsApplyLimitID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.LimitType).HasMaxLength(100);
            entity.Property(e => e.Message).HasMaxLength(500);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<SettingsApplyLimitApplicationStatusType>(entity =>
        {
            entity.HasKey(e => e.SettingsApplyLimitApplicationStatusTypeId).HasName("PK__Settings__528505AA881EAADD");

            entity.ToTable("SettingsApplyLimitApplicationStatusType", "Admin");

            entity.HasIndex(e => new { e.SettingsApplyLimitId, e.ApplicationStatusTypeId, e.Deleted }, "IDX_SettingsApplyLimitApplicationStatusType_2").IsUnique();

            entity.Property(e => e.SettingsApplyLimitApplicationStatusTypeId).HasColumnName("SettingsApplyLimitApplicationStatusTypeID");
            entity.Property(e => e.ApplicationStatusTypeId).HasColumnName("ApplicationStatusTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SettingsApplyLimitId).HasColumnName("SettingsApplyLimitID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.ApplicationStatusType).WithMany(p => p.SettingsApplyLimitApplicationStatusTypes)
                .HasForeignKey(d => d.ApplicationStatusTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ApplicationStatusType_ApplicationStatusType_1");

            entity.HasOne(d => d.SettingsApplyLimit).WithMany(p => p.SettingsApplyLimitApplicationStatusTypes)
                .HasForeignKey(d => d.SettingsApplyLimitId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SettingsApplyLimit_SettingsApplyLimitApplicationStatusType_2");
        });

        modelBuilder.Entity<SettingsClient>(entity =>
        {
            entity.HasKey(e => e.SettingsClientId).HasName("PK_SettingsClientID");

            entity.ToTable("SettingsClient", "Admin");

            entity.Property(e => e.SettingsClientId).HasColumnName("SettingsClientID");
            entity.Property(e => e.ApplicantCommentsEnabled).HasComment("ApplicantCommentsEnabled. Column IncludeTextBoxWithComments A. If set to Yes, when sending or replying to comments, there will be a text box available for the User to enter in free text.\r\n            1. Default to Yes\r\nB. If set to No when sending or replying to comments, no text box is available.\r\n");
            entity.Property(e => e.ApplicantTasksEnabled)
                .HasDefaultValue(true)
                .HasComment("Turn on and off task management. \r\nFor example, When turned on, the following should happen:\r\n 1. Task columns appear for both Recrutier and Hiring Enable TasksManager\r\n 2. \"Mark Tasks Complete\" action link appears for both Recruiters and Hiring managers on message rows that are associated with Tasks\r\n 3. Message reply dialogs contain the \"Create new task for recipient\" checkbox\r\n 4. Message reply dialogs contain a \"Mark task complete: <taskname> checkbox for messages associated with a specific task\r\n 5. \"Mark All Tasks Complete\" user role setting is enabled");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.EnforceDaylightSavings)
                .IsRequired()
                .HasDefaultValueSql("('1')");
            entity.Property(e => e.ExternalCareerSiteShowExternalJobsOnly).HasDefaultValue(true);
            entity.Property(e => e.InternalCareerSiteShowInternalJobsOnly).HasDefaultValue(true);
            entity.Property(e => e.MaskFullSsn)
                .HasComment("This column is used to select the option the client wants to use for displaying Social Securtiy #.  When set (1), the entire SSN # will be fully obscured, when off, the last four digits of the SSN # will be visible as follows:\r\n***-***-####")
                .HasColumnName("MaskFullSSN");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.OauthLinkedInEnabled).HasColumnName("OAuthLinkedInEnabled");
            entity.Property(e => e.RecruiterAlertOnApplicationSubmission).HasComment("RecruiterAlertOnApplicationSubmission. Checkbox when turned on sends 'Send Applicant Apply Email Alert'\r\n         Default -> Off\r\n\r\n");
            entity.Property(e => e.RequisitionApproveWithoutLoginEnabled).HasComment("Client Setting for Enabling Approve Requisistion Without Logging in.");
            entity.Property(e => e.RequisitionNumberAutoGen).HasDefaultValue(true);
            entity.Property(e => e.RequisitionNumberSequenceStart).HasDefaultValue(1000);
            entity.Property(e => e.SendExternalApplicationReply).HasDefaultValue(true);
            entity.Property(e => e.SendInternalApplicationReply).HasDefaultValue(true);
            entity.Property(e => e.SendMessageReplyNotifications).HasDefaultValue(true);
            entity.Property(e => e.SettingsInternalId).HasColumnName("SettingsInternalID");
            entity.Property(e => e.SettingsTimeZone).HasDefaultValueSql("('1')");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.DispositionReasonNavigation).WithMany(p => p.SettingsClients)
                .HasForeignKey(d => d.DispositionReason)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DispositionSettingsType_SettingsClient_1");

            entity.HasOne(d => d.SettingsInternal).WithMany(p => p.SettingsClients)
                .HasForeignKey(d => d.SettingsInternalId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SettingsInternal_SettingsClient_2");
        });

        modelBuilder.Entity<SettingsClientDocumentType>(entity =>
        {
            entity.ToTable("SettingsClientDocumentType", "Admin");

            entity.HasIndex(e => new { e.SettingsClientId, e.DocumentTypeId, e.Deleted }, "IDX_SettingsClientDocumentType_2").IsUnique();

            entity.Property(e => e.SettingsClientDocumentTypeId).HasColumnName("SettingsClientDocumentTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DocumentTypeId).HasColumnName("DocumentTypeID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SettingsClientId).HasColumnName("SettingsClientID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.DocumentType).WithMany(p => p.SettingsClientDocumentTypes)
                .HasForeignKey(d => d.DocumentTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DocumentType_SettingsClientDocumentType_2");

            entity.HasOne(d => d.SettingsClient).WithMany(p => p.SettingsClientDocumentTypes)
                .HasForeignKey(d => d.SettingsClientId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SettingsClient_SettingsClientDocumentType_1");
        });

        modelBuilder.Entity<SettingsClientJobTemplatePropagationField>(entity =>
        {
            entity.HasKey(e => e.SettingsClientJobTemplatePropagationFieldId).HasName("PK_SSettingsClientJobTemplatePropagationField");

            entity.ToTable("SettingsClientJobTemplatePropagationField", "Admin");

            entity.HasIndex(e => new { e.SettingsClientId, e.JobTemplatePropagationFieldId, e.Deleted }, "IDX_SettingsClientJobTemplatePropagationField_2").IsUnique();

            entity.Property(e => e.SettingsClientJobTemplatePropagationFieldId).HasColumnName("SettingsClientJobTemplatePropagationFieldID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.JobTemplatePropagationFieldId).HasColumnName("JobTemplatePropagationFieldID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SettingsClientId).HasColumnName("SettingsClientID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.JobTemplatePropagationField).WithMany(p => p.SettingsClientJobTemplatePropagationFields)
                .HasForeignKey(d => d.JobTemplatePropagationFieldId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_JobTemplatePropagationField_SettingsClientJobTemplatePropagationField_2");

            entity.HasOne(d => d.SettingsClient).WithMany(p => p.SettingsClientJobTemplatePropagationFields)
                .HasForeignKey(d => d.SettingsClientId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SettingsClient_SettingsClientJobTemplatePropagationField_1");
        });

        modelBuilder.Entity<SettingsClientJobTemplatePropagationRequisitionStatusType>(entity =>
        {
            entity.ToTable("SettingsClientJobTemplatePropagationRequisitionStatusType", "Admin");

            entity.HasIndex(e => new { e.SettingsClientId, e.RequisitionStatusTypeId, e.Deleted }, "IDX_SettingsClientJobTemplatePropagationRequisitionStatusType_2").IsUnique();

            entity.Property(e => e.SettingsClientJobTemplatePropagationRequisitionStatusTypeId).HasColumnName("SettingsClientJobTemplatePropagationRequisitionStatusTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.RequisitionStatusTypeId).HasColumnName("RequisitionStatusTypeID");
            entity.Property(e => e.SettingsClientId).HasColumnName("SettingsClientID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.RequisitionStatusType).WithMany(p => p.SettingsClientJobTemplatePropagationRequisitionStatusTypes)
                .HasForeignKey(d => d.RequisitionStatusTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_RequisitionStatusType_SettingsClientJobTemplatePropagationRequisitionStatusType_2");

            entity.HasOne(d => d.SettingsClient).WithMany(p => p.SettingsClientJobTemplatePropagationRequisitionStatusTypes)
                .HasForeignKey(d => d.SettingsClientId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SettingsClient_SettingsClientJobTemplatePropagationRequisitionStatusType_1");
        });

        modelBuilder.Entity<SettingsInternal>(entity =>
        {
            entity.HasKey(e => e.SettingsInternalId).HasName("PK__Settings__EBC846EABED68CCF");

            entity.ToTable("SettingsInternal", "Admin");

            entity.Property(e => e.SettingsInternalId).HasColumnName("SettingsInternalID");
            entity.Property(e => e.BackgroundCheckFormsRequired).HasComment("If this is enabled Background Check Forms will be require");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.HrisintegrationsEnabled)
                .HasComment("Turn on or off HRIS Integration features for a given client")
                .HasColumnName("HRISIntegrationsEnabled");
            entity.Property(e => e.MobileOnboardingEnabled).HasComment("Turn on and off \"Onboarding Enabled Mobile\" features for a given client.");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.OnBoardingEnabled).HasComment("Turn on and off \"Onboarding\" features for a given client.");
            entity.Property(e => e.PfmintegrationImportId).HasColumnName("PFMIntegrationImportID");
            entity.Property(e => e.SeekerAttachAdocEnabled).HasColumnName("SeekerAttachADocEnabled");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.PfmintegrationImport).WithMany(p => p.SettingsInternals)
                .HasForeignKey(d => d.PfmintegrationImportId)
                .HasConstraintName("FK_MetaValue_SettingsInternal_1");
        });

        modelBuilder.Entity<SettingsOnboarding>(entity =>
        {
            entity.HasKey(e => e.SettingsOnboardingId).HasName("PK__Settings__405E54F29C5EF064");

            entity.ToTable("SettingsOnboarding", "Admin");

            entity.Property(e => e.SettingsOnboardingId).HasColumnName("SettingsOnboardingID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SendOnboardingEmailSettingsTypeId).HasColumnName("SendOnboardingEmailSettingsTypeID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.UseFieldMappingFile).HasComment("Flag to indicate whether the client XML field file is used or not.  If this bit is set there there is a FieldMapping file uploaded for this client.  Defaults to not set.");

            entity.HasOne(d => d.SendOnboardingEmailSettingsType).WithMany(p => p.SettingsOnboardings)
                .HasForeignKey(d => d.SendOnboardingEmailSettingsTypeId)
                .HasConstraintName("FK_OnboardingEmailSettingsType_SettingsOnboarding_SendOnboardingEmailSettingsTypeID");
        });

        modelBuilder.Entity<SettingsPasswordSecurity>(entity =>
        {
            entity.HasKey(e => e.SettingsPasswordSecurityId).HasName("PK_SettingsPasswordSecurityID");

            entity.ToTable("SettingsPasswordSecurity", "Admin");

            entity.Property(e => e.SettingsPasswordSecurityId).HasColumnName("SettingsPasswordSecurityID");
            entity.Property(e => e.CareerSiteExpireDays).HasDefaultValue(90);
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<SettingsReport>(entity =>
        {
            entity.HasKey(e => e.SettingsReportsId).HasName("PK__Settings__D701E2F1C2A39B12");

            entity.ToTable("SettingsReports", "Admin");

            entity.Property(e => e.SettingsReportsId).HasColumnName("SettingsReportsID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<SettingsTimeZone>(entity =>
        {
            entity.HasKey(e => e.SettingsTimeZoneId).HasName("PK_SettingsTimeZoneID");

            entity.ToTable("SettingsTimeZone", "Admin");

            entity.Property(e => e.SettingsTimeZoneId).HasColumnName("SettingsTimeZoneID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TimeZoneDisplayName).HasMaxLength(100);
            entity.Property(e => e.TimeZoneId).HasMaxLength(100);
            entity.Property(e => e.TimeZoneName).HasMaxLength(100);
        });

        modelBuilder.Entity<SettingsWorkflow>(entity =>
        {
            entity.HasKey(e => e.SettingsWorkflowId).HasName("PK__Settings__4B70A3282F298EBA");

            entity.ToTable("SettingsWorkflow", "Admin");

            entity.HasIndex(e => new { e.SettingsWorkflowDefinitionId, e.WorkflowTypeId, e.Name, e.Deleted }, "IDX_SettingsWorkflow_2").IsUnique();

            entity.Property(e => e.SettingsWorkflowId).HasColumnName("SettingsWorkflowID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Description).HasMaxLength(255);
            entity.Property(e => e.EscalationTemplateId).HasColumnName("EscalationTemplateID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SettingsWorkflowDefinitionId).HasColumnName("SettingsWorkflowDefinitionID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.WorkflowSubTypeId).HasColumnName("WorkflowSubTypeID");
            entity.Property(e => e.WorkflowTypeId).HasColumnName("WorkflowTypeID");

            entity.HasOne(d => d.EscalationTemplate).WithMany(p => p.SettingsWorkflows)
                .HasForeignKey(d => d.EscalationTemplateId)
                .HasConstraintName("FK_Template_SettingsWorkflow_3");

            entity.HasOne(d => d.SettingsWorkflowDefinition).WithMany(p => p.SettingsWorkflows)
                .HasForeignKey(d => d.SettingsWorkflowDefinitionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SettingsWorkflowDefinition_SettingsWorkflow_1");

            entity.HasOne(d => d.WorkflowSubType).WithMany(p => p.SettingsWorkflows)
                .HasForeignKey(d => d.WorkflowSubTypeId)
                .HasConstraintName("FK_WorkflowSubType_SettingsWorkflow");
        });

        modelBuilder.Entity<SettingsWorkflowDefaultSequentialStep>(entity =>
        {
            entity.HasKey(e => e.SettingsWorkflowDefaultSequentialStepId).HasName("PK__Settings__80F7023038B81E4C");

            entity.ToTable("SettingsWorkflowDefaultSequentialStep", "Admin");

            entity.HasIndex(e => new { e.SettingsWorkflowId, e.ControlName, e.AcknowledgementTypeId, e.Deleted }, "IDX_SettingsWorkflowDefaultSequentialStep_2").IsUnique();

            entity.Property(e => e.SettingsWorkflowDefaultSequentialStepId).HasColumnName("SettingsWorkflowDefaultSequentialStepID");
            entity.Property(e => e.AcknowledgementTypeId)
                .HasComment("If step is Acknowledgement then need to select AcknowledgementTypeId which allows to identify this step is for the acknowldgement with specific type")
                .HasColumnName("AcknowledgementTypeID");
            entity.Property(e => e.ApplicationFormId).HasColumnName("ApplicationFormID");
            entity.Property(e => e.ApplicationFormTypeId).HasColumnName("ApplicationFormTypeID");
            entity.Property(e => e.ControlName).HasMaxLength(200);
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DocumentTypeId).HasColumnName("DocumentTypeID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SettingsWorkflowId).HasColumnName("SettingsWorkflowID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.AcknowledgementType).WithMany(p => p.SettingsWorkflowDefaultSequentialSteps)
                .HasForeignKey(d => d.AcknowledgementTypeId)
                .HasConstraintName("FK_AcknowledgementType_SettingsWorkflowDefaultSequentialStep_4");

            entity.HasOne(d => d.ApplicationForm).WithMany(p => p.SettingsWorkflowDefaultSequentialSteps)
                .HasForeignKey(d => d.ApplicationFormId)
                .HasConstraintName("FK_ApplicationForm_SettingsWorkflowDefaultSequentialStep_5");

            entity.HasOne(d => d.ApplicationFormType).WithMany(p => p.SettingsWorkflowDefaultSequentialSteps)
                .HasForeignKey(d => d.ApplicationFormTypeId)
                .HasConstraintName("FK_ApplicationFormType_SettingsWorkflowDefaultSequentialStep_3");

            entity.HasOne(d => d.DocumentType).WithMany(p => p.SettingsWorkflowDefaultSequentialSteps)
                .HasForeignKey(d => d.DocumentTypeId)
                .HasConstraintName("FK_DocumentType_SettingsWorkflowDefaultSequentialStep_2");

            entity.HasOne(d => d.SettingsWorkflow).WithMany(p => p.SettingsWorkflowDefaultSequentialSteps)
                .HasForeignKey(d => d.SettingsWorkflowId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SettingsWorkflow_SettingsWorkflowDefaultSequentialStep_1");
        });

        modelBuilder.Entity<SettingsWorkflowDefinition>(entity =>
        {
            entity.HasKey(e => e.SettingsWorkflowDefinitionId).HasName("PK__Settings__363E1A19877765E6");

            entity.ToTable("SettingsWorkflowDefinition", "Admin");

            entity.HasIndex(e => new { e.WorkflowIdentifier, e.WorkflowTypeId, e.Deleted }, "IDX_SettingsWorkflowDefinition_Identifier").IsUnique();

            entity.Property(e => e.SettingsWorkflowDefinitionId).HasColumnName("SettingsWorkflowDefinitionID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.WorkflowIdentifier).HasMaxLength(100);
            entity.Property(e => e.WorkflowTypeId).HasColumnName("WorkflowTypeID");
        });

        modelBuilder.Entity<SettingsWorkflowSequentialStep>(entity =>
        {
            entity.HasKey(e => e.SettingsWorkflowSequentialStepId).HasName("PK__Settings__1166DBDA3A26D521");

            entity.ToTable("SettingsWorkflowSequentialStep", "Admin");

            entity.HasIndex(e => new { e.SettingsWorkflowId, e.ControlName, e.AcknowledgementTypeId, e.Deleted }, "IDX_SettingsWorkflowSequentialStep_2").IsUnique();

            entity.Property(e => e.SettingsWorkflowSequentialStepId).HasColumnName("SettingsWorkflowSequentialStepID");
            entity.Property(e => e.AcknowledgementTypeId)
                .HasComment("If step is Acknowledgement then need to select AcknowledgementTypeId which allows to identify this step is for the acknowldgement with specific type")
                .HasColumnName("AcknowledgementTypeID");
            entity.Property(e => e.ApplicationFormId).HasColumnName("ApplicationFormID");
            entity.Property(e => e.ApplicationFormTypeId).HasColumnName("ApplicationFormTypeID");
            entity.Property(e => e.ControlName).HasMaxLength(200);
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DocumentTypeId).HasColumnName("DocumentTypeID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SettingsWorkflowId).HasColumnName("SettingsWorkflowID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.AcknowledgementType).WithMany(p => p.SettingsWorkflowSequentialSteps)
                .HasForeignKey(d => d.AcknowledgementTypeId)
                .HasConstraintName("FK_AcknowledgementType_SettingsWorkflowSequentialStep_6");

            entity.HasOne(d => d.ApplicationForm).WithMany(p => p.SettingsWorkflowSequentialSteps)
                .HasForeignKey(d => d.ApplicationFormId)
                .HasConstraintName("FK_ApplicationForm_SettingsWorkflowSequentialStep_7");

            entity.HasOne(d => d.ApplicationFormType).WithMany(p => p.SettingsWorkflowSequentialSteps)
                .HasForeignKey(d => d.ApplicationFormTypeId)
                .HasConstraintName("FK_ApplicationFormType_SettingsWorkflowSequentialStep_5");

            entity.HasOne(d => d.DocumentType).WithMany(p => p.SettingsWorkflowSequentialSteps)
                .HasForeignKey(d => d.DocumentTypeId)
                .HasConstraintName("FK_DocumentType_SettingsWorkflowSequentialStep_3");

            entity.HasOne(d => d.SettingsWorkflow).WithMany(p => p.SettingsWorkflowSequentialSteps)
                .HasForeignKey(d => d.SettingsWorkflowId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SettingsWorkflow_SettingsWorkflowSequentialStep_4");
        });

        modelBuilder.Entity<SettingsWorkflowStep>(entity =>
        {
            entity.HasKey(e => e.SettingsWorkflowStepId).HasName("PK__Settings__3C833EE2B0329F3C");

            entity.ToTable("SettingsWorkflowStep", "Admin");

            entity.HasIndex(e => new { e.SettingsWorkflowId, e.WorkflowStepIdentifier, e.Deleted }, "IDX_SettingsWorkflowStep_2").IsUnique();

            entity.Property(e => e.SettingsWorkflowStepId).HasColumnName("SettingsWorkflowStepID");
            entity.Property(e => e.ApplicationStatusTypeId)
                .HasComment("ApplicationStatusTypeID that maps to this workflow step. NULL for non application workflows.")
                .HasColumnName("ApplicationStatusTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.EscalationTemplateId).HasColumnName("EscalationTemplateID");
            entity.Property(e => e.IsSystem)
                .HasComment("Indicates that this step is a system step expected by the system and that means that it is both require and immutable. ")
                .HasColumnName("isSystem");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.NewHireStatusTypeId)
                .HasComment("NewHireStatusTypeID that maps to this workflow step. NULL for non NewHire workflows.")
                .HasColumnName("NewHireStatusTypeID");
            entity.Property(e => e.NotificationTemplateId).HasColumnName("NotificationTemplateID");
            entity.Property(e => e.OnBoardingDocumentStatusTypeId)
                .HasComment("OnboardingDocumentStatusTypeID that maps to this workflow step. NULL for non Onboarding Document workflows.")
                .HasColumnName("OnBoardingDocumentStatusTypeID");
            entity.Property(e => e.RequisitionStatusTypeId)
                .HasComment("RequisitionStatusTypeID that maps to this workflow step. NULL for non Requisition workflows.")
                .HasColumnName("RequisitionStatusTypeID");
            entity.Property(e => e.SettingsWorkflowId).HasColumnName("SettingsWorkflowID");
            entity.Property(e => e.StepName)
                .HasMaxLength(500)
                .HasComment("The name of the corresponding workflow step. ActivityName in K2 Workflow.");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.ApplicationStatusType).WithMany(p => p.SettingsWorkflowSteps)
                .HasForeignKey(d => d.ApplicationStatusTypeId)
                .HasConstraintName("FK_ApplicationStatusType_SettingsWorkflowStep_5");

            entity.HasOne(d => d.EscalationTemplate).WithMany(p => p.SettingsWorkflowStepEscalationTemplates)
                .HasForeignKey(d => d.EscalationTemplateId)
                .HasConstraintName("FK_Template_SettingsWorkflowStep_3");

            entity.HasOne(d => d.NewHireStatusType).WithMany(p => p.SettingsWorkflowSteps)
                .HasForeignKey(d => d.NewHireStatusTypeId)
                .HasConstraintName("FK_NewHireStatusType_SettingsWorkflowStep_7");

            entity.HasOne(d => d.NotificationTemplate).WithMany(p => p.SettingsWorkflowStepNotificationTemplates)
                .HasForeignKey(d => d.NotificationTemplateId)
                .HasConstraintName("FK_Template_SettingsWorkflowStep_2");

            entity.HasOne(d => d.OnBoardingDocumentStatusType).WithMany(p => p.SettingsWorkflowSteps)
                .HasForeignKey(d => d.OnBoardingDocumentStatusTypeId)
                .HasConstraintName("FK_OnBoardingDocumentStatusType_SettingsWorkflowStep_4");

            entity.HasOne(d => d.RequisitionStatusType).WithMany(p => p.SettingsWorkflowSteps)
                .HasForeignKey(d => d.RequisitionStatusTypeId)
                .HasConstraintName("FK_RequisitionStatusType_SettingsWorkflowStep_6");

            entity.HasOne(d => d.SettingsWorkflow).WithMany(p => p.SettingsWorkflowSteps)
                .HasForeignKey(d => d.SettingsWorkflowId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SettingsWorkflow_SettingsWorkflowStep_1");
        });

        modelBuilder.Entity<SettingsWorkflowStepAction>(entity =>
        {
            entity.HasKey(e => e.SettingsWorkflowStepActionId).HasName("PK__Settings__F5E672C22B4B605A");

            entity.ToTable("SettingsWorkflowStepAction", "Admin");

            entity.HasIndex(e => new { e.SettingsWorkflowStepActionId, e.SettingsWorkflowStepId, e.Deleted }, "IDX_SettingsWorkflowStepAction_2").IsUnique();

            entity.Property(e => e.SettingsWorkflowStepActionId).HasColumnName("SettingsWorkflowStepActionID");
            entity.Property(e => e.AuditEntryResourceKey).HasMaxLength(100);
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DisplayNameResourceKey).HasMaxLength(100);
            entity.Property(e => e.IsUserAction).HasColumnName("isUserAction");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.RequisitionAuditTypeId)
                .HasComment("This is a temporary column until Requsition Audit is completed, at which point it should be removed.")
                .HasColumnName("RequisitionAuditTypeID");
            entity.Property(e => e.SettingsWorkflowStepId).HasColumnName("SettingsWorkflowStepID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.RequisitionAuditType).WithMany(p => p.SettingsWorkflowStepActions)
                .HasForeignKey(d => d.RequisitionAuditTypeId)
                .HasConstraintName("FK_RequisitionAuditType_SettingsWorkflowStepAction_2");

            entity.HasOne(d => d.SettingsWorkflowStep).WithMany(p => p.SettingsWorkflowStepActions)
                .HasForeignKey(d => d.SettingsWorkflowStepId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SettingsWorkflowStep_SettingsWorkflowStepAction_1");
        });

        modelBuilder.Entity<SortOrderType>(entity =>
        {
            entity.HasKey(e => e.SortOrderTypeId).HasName("PK__SortOrde__164BEF922F4A9B64");

            entity.ToTable("SortOrderType", "Admin");

            entity.HasIndex(e => new { e.Name, e.Deleted }, "IDX_SortOrderType_2").IsUnique();

            entity.Property(e => e.SortOrderTypeId).HasColumnName("SortOrderTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<SystemSearch>(entity =>
        {
            entity.HasKey(e => e.SystemSearchId).HasName("PK_SystemSearchID");

            entity.ToTable("SystemSearch", "Admin");

            entity.Property(e => e.SystemSearchId).HasColumnName("SystemSearchID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Criteria).HasColumnType("xml");
            entity.Property(e => e.DataSourceTypeId)
                .HasComment("DataSourceTypeID refers to the type of the parent object for which the system search is defined.\r\n\r\nE.g: Requisition or Application")
                .HasColumnName("DataSourceTypeID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.DataSourceType).WithMany(p => p.SystemSearches)
                .HasForeignKey(d => d.DataSourceTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DataSourceType_SystemSearch_1");
        });

        modelBuilder.Entity<SystemSearchOnboardingStatusType>(entity =>
        {
            entity.HasKey(e => new { e.SystemSearchOnboardingStatusTypeId, e.SystemSearchId, e.NewHireStatusTypeId }).HasName("PK__SystemSe__AAD151C49EAAB636");

            entity.ToTable("SystemSearchOnboardingStatusType", "Admin");

            entity.HasIndex(e => new { e.SystemSearchOnboardingStatusTypeId, e.SystemSearchId, e.NewHireStatusTypeId, e.RoleTypeId, e.Deleted }, "IDX_SystemSearchOnboardingStatusType_Unique").IsUnique();

            entity.Property(e => e.SystemSearchOnboardingStatusTypeId)
                .ValueGeneratedOnAdd()
                .HasColumnName("SystemSearchOnboardingStatusTypeID");
            entity.Property(e => e.SystemSearchId)
                .HasComment("SystemSearch foreign key")
                .HasColumnName("SystemSearchID");
            entity.Property(e => e.NewHireStatusTypeId)
                .HasComment("NewHireStatusTypeId foreign key")
                .HasColumnName("NewHireStatusTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.OnBoardingDocumentStatusTypeId)
                .HasComment("Onboardingdocumentstatustypeid foreign key")
                .HasColumnName("OnBoardingDocumentStatusTypeID");
            entity.Property(e => e.RoleTypeId).HasColumnName("RoleTypeID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.NewHireStatusType).WithMany(p => p.SystemSearchOnboardingStatusTypes)
                .HasForeignKey(d => d.NewHireStatusTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__SystemSearchOnboardingStatusType_NewhireStatusType");

            entity.HasOne(d => d.OnBoardingDocumentStatusType).WithMany(p => p.SystemSearchOnboardingStatusTypes)
                .HasForeignKey(d => d.OnBoardingDocumentStatusTypeId)
                .HasConstraintName("FK__SystemSearchOnboardingStatusType_OnboardingDocumentStatusType");

            entity.HasOne(d => d.SystemSearch).WithMany(p => p.SystemSearchOnboardingStatusTypes)
                .HasForeignKey(d => d.SystemSearchId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__SystemSearchOnboardingStatusType_SystemSearch");
        });

        modelBuilder.Entity<SystemSearchStatusType>(entity =>
        {
            entity.HasKey(e => e.SystemSearchStatusTypeId).HasName("PK__SystemSe__A6732D50C14B229B");

            entity.ToTable("SystemSearchStatusType", "Admin");

            entity.HasIndex(e => new { e.SystemSearchId, e.RoleTypeId, e.RequisitionStatusTypeId, e.ApplicationStatusTypeId, e.Deleted }, "IDX_SystemSearchStatusType_2").IsUnique();

            entity.Property(e => e.SystemSearchStatusTypeId).HasColumnName("SystemSearchStatusTypeID");
            entity.Property(e => e.ApplicationStatusTypeId)
                .HasComment("Application status type")
                .HasColumnName("ApplicationStatusTypeID");
            entity.Property(e => e.Calculated).HasComment("If systemsearch has calculated count. We are handling these records differently in stored procedure.Viewed, Not Viewed, Internal, External are calculated fields.");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.RequisitionStatusTypeId)
                .HasComment("Requisition status type")
                .HasColumnName("RequisitionStatusTypeID");
            entity.Property(e => e.RoleTypeId).HasColumnName("RoleTypeID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.SystemSearchId).HasColumnName("SystemSearchID");

            entity.HasOne(d => d.ApplicationStatusType).WithMany(p => p.SystemSearchStatusTypes)
                .HasForeignKey(d => d.ApplicationStatusTypeId)
                .HasConstraintName("FK_ApplicationStatusType_SystemSearchStatusType_3");

            entity.HasOne(d => d.RequisitionStatusType).WithMany(p => p.SystemSearchStatusTypes)
                .HasForeignKey(d => d.RequisitionStatusTypeId)
                .HasConstraintName("FK_RequisitionStatusType_SystemSearchStatusType_2");

            entity.HasOne(d => d.RoleType).WithMany(p => p.SystemSearchStatusTypes)
                .HasForeignKey(d => d.RoleTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_RoleType_SystemSearchStatusType_4");

            entity.HasOne(d => d.SystemSearch).WithMany(p => p.SystemSearchStatusTypes)
                .HasForeignKey(d => d.SystemSearchId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__SystemSearchID_1");
        });

        modelBuilder.Entity<SystemSearchVendorOrderType>(entity =>
        {
            entity.HasKey(e => new { e.SystemSearchVendorOrderTypeId, e.SystemSearchId, e.VendorOrderTypeId, e.VendorOrderStatusTypeId }).HasName("PK__SystemSe__CC169C8856D44CC2");

            entity.ToTable("SystemSearchVendorOrderType", "Admin");

            entity.HasIndex(e => new { e.SystemSearchId, e.VendorOrderTypeId, e.VendorOrderStatusTypeId, e.RoleTypeId, e.Deleted }, "IDX_SystemSearchVendorOrderType_2").IsUnique();

            entity.Property(e => e.SystemSearchVendorOrderTypeId)
                .ValueGeneratedOnAdd()
                .HasColumnName("SystemSearchVendorOrderTypeID");
            entity.Property(e => e.SystemSearchId).HasColumnName("SystemSearchID");
            entity.Property(e => e.VendorOrderTypeId).HasColumnName("VendorOrderTypeID");
            entity.Property(e => e.VendorOrderStatusTypeId).HasColumnName("VendorOrderStatusTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.RoleTypeId).HasColumnName("RoleTypeID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.SystemSearch).WithMany(p => p.SystemSearchVendorOrderTypes)
                .HasForeignKey(d => d.SystemSearchId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SystemSearch_SystemSearchVendorOrderType_1");

            entity.HasOne(d => d.VendorOrderStatusType).WithMany(p => p.SystemSearchVendorOrderTypes)
                .HasForeignKey(d => d.VendorOrderStatusTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_VendorOrderStatusType_SystemSearchVendorOrderType_3");

            entity.HasOne(d => d.VendorOrderType).WithMany(p => p.SystemSearchVendorOrderTypes)
                .HasForeignKey(d => d.VendorOrderTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_VendorOrderType_SystemSearchVendorOrderType_2");
        });

        modelBuilder.Entity<TalentAnalyticsConsent>(entity =>
        {
            entity.HasKey(e => e.TalentAnalyticsConsentId).HasName("PK__TalentAn__B250668E24DA5615");

            entity.ToTable("TalentAnalyticsConsent");

            entity.Property(e => e.TalentAnalyticsConsentId).HasColumnName("TalentAnalyticsConsentID");
            entity.Property(e => e.ConsentFullName).HasMaxLength(500);
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DateConsented).HasColumnType("datetime");
            entity.Property(e => e.Ipaddress)
                .HasMaxLength(100)
                .HasColumnName("IPAddress");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TalentAnalyticsConsentTermsConditionsId).HasColumnName("TalentAnalyticsConsentTermsConditionsID");
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");

            entity.HasOne(d => d.TalentAnalyticsConsentTermsConditions).WithMany(p => p.TalentAnalyticsConsents)
                .HasForeignKey(d => d.TalentAnalyticsConsentTermsConditionsId)
                .HasConstraintName("FK_TalentAnalyticsConsentTermsConditions_TalentAnalyticsConsent_2");

            entity.HasOne(d => d.Tmsuser).WithMany(p => p.TalentAnalyticsConsents)
                .HasForeignKey(d => d.TmsuserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_UserProfile_TalentAnalyticsConsent_1");
        });

        modelBuilder.Entity<TalentAnalyticsConsentTermsCondition>(entity =>
        {
            entity.HasKey(e => e.TalentAnalyticsConsentTermsConditionsId).HasName("PK__TalentAn__A27DB1F77BEE4BA2");

            entity.Property(e => e.TalentAnalyticsConsentTermsConditionsId).HasColumnName("TalentAnalyticsConsentTermsConditionsID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TermsConditionsName).HasMaxLength(100);
        });

        modelBuilder.Entity<TalentPoolContact>(entity =>
        {
            entity.HasKey(e => e.TalentPoolContactId).HasName("PK_TalentPoolContactID");

            entity.ToTable("TalentPoolContact");

            entity.HasIndex(e => new { e.TalentPoolContactId, e.Deleted }, "IDX_TalentPoolContact_PK_and_Deleted").IsUnique();

            entity.HasIndex(e => e.Hrisidentifier, "UX_TalentPoolContact_HRISIdentifier")
                .IsUnique()
                .HasFilter("([HRISIdentifier] IS NOT NULL)");

            entity.Property(e => e.TalentPoolContactId).HasColumnName("TalentPoolContactID");
            entity.Property(e => e.Address).HasMaxLength(50);
            entity.Property(e => e.Address2).HasMaxLength(50);
            entity.Property(e => e.CellPhone).HasMaxLength(24);
            entity.Property(e => e.City).HasMaxLength(50);
            entity.Property(e => e.Code).HasMaxLength(100);
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DispositionId).HasColumnName("DispositionID");
            entity.Property(e => e.Email).HasMaxLength(256);
            entity.Property(e => e.FirstName).HasMaxLength(100);
            entity.Property(e => e.HomePhone).HasMaxLength(24);
            entity.Property(e => e.Hrisidentifier)
                .HasMaxLength(64)
                .HasColumnName("HRISIdentifier");
            entity.Property(e => e.LastName).HasMaxLength(100);
            entity.Property(e => e.MiddleName).HasMaxLength(100);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.StateId).HasColumnName("StateID");
            entity.Property(e => e.StatusId).HasColumnName("StatusID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TalentPoolContactStatusTypeId)
                .HasDefaultValue(1)
                .HasColumnName("TalentPoolContactStatusTypeID");
            entity.Property(e => e.Title).HasMaxLength(25);
            entity.Property(e => e.ZipCode).HasMaxLength(10);

            entity.HasOne(d => d.Disposition).WithMany(p => p.TalentPoolContactDispositions)
                .HasForeignKey(d => d.DispositionId)
                .HasConstraintName("MetaValue_TalentPoolContact_Disposition");

            entity.HasOne(d => d.State).WithMany(p => p.TalentPoolContactStates)
                .HasForeignKey(d => d.StateId)
                .HasConstraintName("FK_MetaValue_TalentPoolContact_State");

            entity.HasOne(d => d.Status).WithMany(p => p.TalentPoolContactStatuses)
                .HasForeignKey(d => d.StatusId)
                .HasConstraintName("MetaValue_TalentPoolContact_Status");
        });

        modelBuilder.Entity<TalentPoolContactCommunication>(entity =>
        {
            entity.HasKey(e => e.TalentPoolContactCommunicationId).HasName("PK_TalentPoolContactCommunicationID");

            entity.ToTable("TalentPoolContactCommunication");

            entity.HasIndex(e => new { e.TalentPoolContactCommunicationId, e.Deleted }, "IDX_TalentPoolContactCommunication_PK_and_Deleted").IsUnique();

            entity.Property(e => e.TalentPoolContactCommunicationId).HasColumnName("TalentPoolContactCommunicationID");
            entity.Property(e => e.CommunicationId).HasColumnName("CommunicationID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TalentPoolContactId).HasColumnName("TalentPoolContactID");

            entity.HasOne(d => d.Communication).WithMany(p => p.TalentPoolContactCommunications)
                .HasForeignKey(d => d.CommunicationId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Communication_TalentPoolContactCommunication");

            entity.HasOne(d => d.TalentPoolContact).WithMany(p => p.TalentPoolContactCommunications)
                .HasForeignKey(d => d.TalentPoolContactId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TalentPoolContact_TalentPoolContactCommunication");
        });

        modelBuilder.Entity<TalentPoolContactDocument>(entity =>
        {
            entity.HasKey(e => e.TalentPoolContactDocumentId).HasName("PK_TalentPoolDocumentID");

            entity.ToTable("TalentPoolContactDocument");

            entity.HasIndex(e => new { e.Deleted, e.DocumentId, e.TalentPoolContactId }, "IDX_TalentPoolDocument_DocumentID_TalentPoolContactID_Deleted").IsUnique();

            entity.Property(e => e.TalentPoolContactDocumentId).HasColumnName("TalentPoolContactDocumentID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DocumentId).HasColumnName("DocumentID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TalentPoolContactId).HasColumnName("TalentPoolContactID");

            entity.HasOne(d => d.Document).WithMany(p => p.TalentPoolContactDocuments)
                .HasForeignKey(d => d.DocumentId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__TalentPoolDocument_Document");

            entity.HasOne(d => d.TalentPoolContact).WithMany(p => p.TalentPoolContactDocuments)
                .HasForeignKey(d => d.TalentPoolContactId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__TalentPoolDocument_TalentPoolContact");
        });

        modelBuilder.Entity<TalentPoolContactStatusType>(entity =>
        {
            entity.HasKey(e => e.TalentPoolContactStatusTypeId).HasName("PK_TalentPoolContactStatusTypeID");

            entity.ToTable("TalentPoolContactStatusType", "Admin");

            entity.HasIndex(e => new { e.Name, e.Deleted }, "IDX_TalentPoolContactStatusType_Name_Deleted").IsUnique();

            entity.Property(e => e.TalentPoolContactStatusTypeId).HasColumnName("TalentPoolContactStatusTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<TalentPoolContactView>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("TalentPoolContactView");

            entity.Property(e => e.Address).HasMaxLength(50);
            entity.Property(e => e.Address2).HasMaxLength(50);
            entity.Property(e => e.CellPhone).HasMaxLength(24);
            entity.Property(e => e.ChangedDate).HasColumnType("datetime");
            entity.Property(e => e.City).HasMaxLength(50);
            entity.Property(e => e.DateReceived).HasColumnType("datetime");
            entity.Property(e => e.Disposition).HasMaxLength(100);
            entity.Property(e => e.DispositionId).HasColumnName("DispositionID");
            entity.Property(e => e.Email).HasMaxLength(256);
            entity.Property(e => e.FirstName).HasMaxLength(100);
            entity.Property(e => e.FullName).HasMaxLength(202);
            entity.Property(e => e.HomePhone).HasMaxLength(24);
            entity.Property(e => e.LastName).HasMaxLength(100);
            entity.Property(e => e.State).HasMaxLength(100);
            entity.Property(e => e.StateId).HasColumnName("StateID");
            entity.Property(e => e.Status).HasMaxLength(100);
            entity.Property(e => e.StatusId).HasColumnName("StatusID");
            entity.Property(e => e.TalentPoolContactId).HasColumnName("TalentPoolContactID");
            entity.Property(e => e.TalentPoolContactStatusTypeId).HasColumnName("TalentPoolContactStatusTypeID");
            entity.Property(e => e.Title).HasMaxLength(25);
            entity.Property(e => e.Zipcode).HasMaxLength(10);
        });

        modelBuilder.Entity<Task>(entity =>
        {
            entity.HasKey(e => e.TaskId).HasName("PK__Task__7C6949D1C8020410");

            entity.ToTable("Task");

            entity.Property(e => e.TaskId).HasColumnName("TaskID");
            entity.Property(e => e.AssignedToRoleTypeId).HasColumnName("AssignedToRoleTypeID");
            entity.Property(e => e.AssignedToUserId).HasColumnName("AssignedToUserID");
            entity.Property(e => e.ContextDataSourceTypeId).HasColumnName("ContextDataSourceTypeID");
            entity.Property(e => e.ContextObjectId).HasColumnName("ContextObjectID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.IsVisible)
                .HasDefaultValue(true)
                .HasComment("IsVisible - control visibility of the task in UI.\r\nTasks are always created in the scenarios where they are needed whether a user explicitly requests them, explicitly asks not to create them in UI, or when task creation is disabled by a setting.\r\nThis user election will define only the visibility of a task in the UI and the ability of the user to manage the task. If the task is not visible, it will be automatically managed by the system.\r\n");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.OriginatorUserId).HasColumnName("OriginatorUserID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TargetDataSourceTypeId).HasColumnName("TargetDataSourceTypeID");
            entity.Property(e => e.TargetObjectId)
                .HasComment("Object that is the target of the task")
                .HasColumnName("TargetObjectID");
            entity.Property(e => e.TaskStatusDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.TaskStatusTypeId)
                .HasDefaultValue(1)
                .HasColumnName("TaskStatusTypeID");
            entity.Property(e => e.TaskTypeId).HasColumnName("TaskTypeID");

            entity.HasOne(d => d.AssignedToRoleType).WithMany(p => p.Tasks)
                .HasForeignKey(d => d.AssignedToRoleTypeId)
                .HasConstraintName("FK_RoleType_Task_5");

            entity.HasOne(d => d.AssignedToUser).WithMany(p => p.TaskAssignedToUsers)
                .HasForeignKey(d => d.AssignedToUserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_UserProfile_Task_1");

            entity.HasOne(d => d.ContextDataSourceType).WithMany(p => p.TaskContextDataSourceTypes)
                .HasForeignKey(d => d.ContextDataSourceTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DataSourceType_Task_6");

            entity.HasOne(d => d.OriginatorUser).WithMany(p => p.TaskOriginatorUsers)
                .HasForeignKey(d => d.OriginatorUserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_UserProfile_Task_4");

            entity.HasOne(d => d.TargetDataSourceType).WithMany(p => p.TaskTargetDataSourceTypes)
                .HasForeignKey(d => d.TargetDataSourceTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DataSourceType_Task_7");

            entity.HasOne(d => d.TaskStatusType).WithMany(p => p.Tasks)
                .HasForeignKey(d => d.TaskStatusTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TaskStatusType_Task_3");

            entity.HasOne(d => d.TaskType).WithMany(p => p.Tasks)
                .HasForeignKey(d => d.TaskTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TaskType_Task_2");
        });

        modelBuilder.Entity<TaskStatusType>(entity =>
        {
            entity.HasKey(e => e.TaskStatusTypeId).HasName("PK__TaskStat__5C91B522B2446B20");

            entity.ToTable("TaskStatusType", "Admin");

            entity.HasIndex(e => new { e.Name, e.Deleted }, "IDX_TaskStatusType_2").IsUnique();

            entity.Property(e => e.TaskStatusTypeId).HasColumnName("TaskStatusTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<TaskType>(entity =>
        {
            entity.HasKey(e => e.TaskTypeId).HasName("PK__TaskType__66B23E53BABDC203");

            entity.ToTable("TaskType", "Admin");

            entity.HasIndex(e => new { e.Name, e.Deleted }, "IDX_TaskType_2").IsUnique();

            entity.Property(e => e.TaskTypeId).HasColumnName("TaskTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<Template>(entity =>
        {
            entity.HasKey(e => e.TemplateId).HasName("PK_TemplateID");

            entity.ToTable("Template", "Admin");

            entity.Property(e => e.TemplateId).HasColumnName("TemplateID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Description).HasMaxLength(255);
            entity.Property(e => e.IsDefault).HasComment("IsDefault indicates the default internal and external application notification templates for Application Reply template type.");
            entity.Property(e => e.JobCategoryId).HasColumnName("JobCategoryID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.RecipientEmailAddress).HasMaxLength(100);
            entity.Property(e => e.RoleTypeId)
                .HasComment("This column defines the Role to which a Template is available,\r\n\r\nSome of the templates are only available to a specific Role.\r\n\r\nE.g. hiring manager response to Recruiter should only be available to Hiring Managers, vs,\r\nRecruiter comments to Hiring Manager should only be available to Recruiter roles.")
                .HasColumnName("RoleTypeID");
            entity.Property(e => e.SenderEmailAddress).HasMaxLength(100);
            entity.Property(e => e.SubjectText).HasMaxLength(255);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TemplateSubtypeId).HasColumnName("TemplateSubtypeID");
            entity.Property(e => e.TemplateTypeId).HasColumnName("TemplateTypeID");

            entity.HasOne(d => d.JobCategory).WithMany(p => p.Templates)
                .HasForeignKey(d => d.JobCategoryId)
                .HasConstraintName("FK_MetaValue_Template_1");

            entity.HasOne(d => d.RoleType).WithMany(p => p.Templates)
                .HasForeignKey(d => d.RoleTypeId)
                .HasConstraintName("FK_RoleType_Template_3");

            entity.HasOne(d => d.TemplateType).WithMany(p => p.Templates)
                .HasForeignKey(d => d.TemplateTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TemplateType_Template_2");
        });

        modelBuilder.Entity<TemplateAttributeValue>(entity =>
        {
            entity.HasKey(e => e.TemplateAttributeValueId).HasName("PK_TemplateAttributeValueID");

            entity.ToTable("TemplateAttributeValue", "Admin");

            entity.HasIndex(e => new { e.TemplateId, e.AttributeValueId, e.Deleted }, "IDX_TemplateAttributeValue_2").IsUnique();

            entity.Property(e => e.TemplateAttributeValueId).HasColumnName("TemplateAttributeValueID");
            entity.Property(e => e.AttributeValueId).HasColumnName("AttributeValueID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TemplateId).HasColumnName("TemplateID");

            entity.HasOne(d => d.AttributeValue).WithMany(p => p.TemplateAttributeValues)
                .HasForeignKey(d => d.AttributeValueId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_AttributeValue_TemplateAttributeValue_1");

            entity.HasOne(d => d.Template).WithMany(p => p.TemplateAttributeValues)
                .HasForeignKey(d => d.TemplateId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Template_TemplateAttributeValue_2");
        });

        modelBuilder.Entity<TemplateBusinessEntity>(entity =>
        {
            entity.HasKey(e => e.TemplateBusinessEntityId).HasName("PK_TemplateBusinessEntityID");

            entity.ToTable("TemplateBusinessEntity", "Admin");

            entity.HasIndex(e => new { e.BusinessEntityId, e.TemplateId, e.Deleted }, "IDX_TemplateBusinessEntity_2").IsUnique();

            entity.Property(e => e.TemplateBusinessEntityId).HasColumnName("TemplateBusinessEntityID");
            entity.Property(e => e.BusinessEntityId).HasColumnName("BusinessEntityID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TemplateId).HasColumnName("TemplateID");

            entity.HasOne(d => d.BusinessEntity).WithMany(p => p.TemplateBusinessEntities)
                .HasForeignKey(d => d.BusinessEntityId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessEntity_TemplateBusinessEntity_1");

            entity.HasOne(d => d.Template).WithMany(p => p.TemplateBusinessEntities)
                .HasForeignKey(d => d.TemplateId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Template_TemplateBusinessEntity_2");
        });

        modelBuilder.Entity<TemplateDocument>(entity =>
        {
            entity.HasKey(e => e.TemplateDocumentId).HasName("PK__Template__D1F54BAA49A78E04");

            entity.ToTable("TemplateDocument");

            entity.HasIndex(e => new { e.TemplateId, e.DocumentId, e.Deleted }, "IDX_TemplateDocument_DocumentID_TemplateID_Deleted").IsUnique();

            entity.Property(e => e.TemplateDocumentId).HasColumnName("TemplateDocumentID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DocumentId).HasColumnName("DocumentID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TemplateId).HasColumnName("TemplateID");

            entity.HasOne(d => d.Document).WithMany(p => p.TemplateDocuments)
                .HasForeignKey(d => d.DocumentId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TemplateDocument_Document");

            entity.HasOne(d => d.Template).WithMany(p => p.TemplateDocuments)
                .HasForeignKey(d => d.TemplateId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TemplateDocument_Template");
        });

        modelBuilder.Entity<TemplateRoleType>(entity =>
        {
            entity.HasKey(e => e.TemplateRoleTypeId).HasName("PK_TemplateRoleTypeID");

            entity.ToTable("TemplateRoleType", "Admin");

            entity.HasIndex(e => new { e.TemplateId, e.RoleTypeId, e.Deleted, e.SenderRecipient }, "IDX_TemplateRoleType_2").IsUnique();

            entity.Property(e => e.TemplateRoleTypeId).HasColumnName("TemplateRoleTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.RoleTypeId).HasColumnName("RoleTypeID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TemplateId).HasColumnName("TemplateID");

            entity.HasOne(d => d.RoleType).WithMany(p => p.TemplateRoleTypes)
                .HasForeignKey(d => d.RoleTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_RoleType_TemplateRoleType_1");

            entity.HasOne(d => d.Template).WithMany(p => p.TemplateRoleTypes)
                .HasForeignKey(d => d.TemplateId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Template_TemplateRoleType_2");
        });

        modelBuilder.Entity<TemplateType>(entity =>
        {
            entity.HasKey(e => e.TemplateTypeId).HasName("PK_TemplateTypeID");

            entity.ToTable("TemplateType", "Admin");

            entity.HasIndex(e => new { e.Deleted, e.Name }, "IDX_TemplateType_2").IsUnique();

            entity.Property(e => e.TemplateTypeId).HasColumnName("TemplateTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Description).HasMaxLength(255);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<TemplateTypeAttributeType>(entity =>
        {
            entity.HasKey(e => e.TemplateTypeAttributeTypeId).HasName("PK_TemplateTypeAttributeTypeID");

            entity.ToTable("TemplateTypeAttributeType", "Admin");

            entity.HasIndex(e => new { e.TemplateTypeId, e.Deleted, e.AttributeTypeId }, "IDX_TemplateTypeAttributeType_2").IsUnique();

            entity.Property(e => e.TemplateTypeAttributeTypeId).HasColumnName("TemplateTypeAttributeTypeID");
            entity.Property(e => e.AttributeTypeId).HasColumnName("AttributeTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TemplateTypeId).HasColumnName("TemplateTypeID");

            entity.HasOne(d => d.AttributeType).WithMany(p => p.TemplateTypeAttributeTypes)
                .HasForeignKey(d => d.AttributeTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_AttributeType_TemplateTypeAttributeType_1");

            entity.HasOne(d => d.TemplateType).WithMany(p => p.TemplateTypeAttributeTypes)
                .HasForeignKey(d => d.TemplateTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TemplateType_TemplateTypeAttributeType_2");
        });

        modelBuilder.Entity<TemplateTypeFieldCategory>(entity =>
        {
            entity.HasKey(e => e.TemplateTypeFieldCategoryId).HasName("PK__Template__57B184E1CAB620E5");

            entity.ToTable("TemplateTypeFieldCategory", "Admin");

            entity.HasIndex(e => new { e.FieldCategoryId, e.TemplateTypeId, e.Deleted }, "IDX_TemplateTypeFieldCategory_2").IsUnique();

            entity.Property(e => e.TemplateTypeFieldCategoryId).HasColumnName("TemplateTypeFieldCategoryID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.FieldCategoryId).HasColumnName("FieldCategoryID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TemplateTypeId).HasColumnName("TemplateTypeID");

            entity.HasOne(d => d.FieldCategory).WithMany(p => p.TemplateTypeFieldCategories)
                .HasForeignKey(d => d.FieldCategoryId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_FieldCategory_TemplateTypeFieldCategory_1");

            entity.HasOne(d => d.TemplateType).WithMany(p => p.TemplateTypeFieldCategories)
                .HasForeignKey(d => d.TemplateTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TemplateType_TemplateTypeFieldCategory_2");
        });

        modelBuilder.Entity<TemplateTypeMiscellaneousField>(entity =>
        {
            entity.HasKey(e => e.TemplateTypeMiscellaneousFieldId).HasName("PK__Template__CFEA8EA940708C0B");

            entity.ToTable("TemplateTypeMiscellaneousField", "Admin");

            entity.HasIndex(e => new { e.MiscellaneousFieldId, e.TemplateTypeId, e.TemplateSubTypeId, e.Deleted }, "IDX_TemplateTypeMiscellaneousField_2").IsUnique();

            entity.Property(e => e.TemplateTypeMiscellaneousFieldId).HasColumnName("TemplateTypeMiscellaneousFieldID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.MiscellaneousFieldId).HasColumnName("MiscellaneousFieldID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TemplateSubTypeId).HasColumnName("TemplateSubTypeID");
            entity.Property(e => e.TemplateTypeId).HasColumnName("TemplateTypeID");

            entity.HasOne(d => d.MiscellaneousField).WithMany(p => p.TemplateTypeMiscellaneousFields)
                .HasForeignKey(d => d.MiscellaneousFieldId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MiscellaneousField_TemplateTypeMiscellaneousField_1");

            entity.HasOne(d => d.TemplateType).WithMany(p => p.TemplateTypeMiscellaneousFields)
                .HasForeignKey(d => d.TemplateTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TemplateType_TemplateTypeMiscellaneousField_2");
        });

        modelBuilder.Entity<TemplateTypeRoleType>(entity =>
        {
            entity.HasKey(e => e.TemplateTypeRoleTypeId).HasName("PK_TemplateTypeRoleTypeID");

            entity.ToTable("TemplateTypeRoleType", "Admin");

            entity.HasIndex(e => new { e.Deleted, e.RoleTypeId, e.TemplateTypeId }, "IDX_TemplateTypeRoleType_2").IsUnique();

            entity.Property(e => e.TemplateTypeRoleTypeId).HasColumnName("TemplateTypeRoleTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.RoleTypeId).HasColumnName("RoleTypeID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TemplateTypeId).HasColumnName("TemplateTypeID");

            entity.HasOne(d => d.RoleType).WithMany(p => p.TemplateTypeRoleTypes)
                .HasForeignKey(d => d.RoleTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_RoleType_TemplateTypeRoleType_1");

            entity.HasOne(d => d.TemplateType).WithMany(p => p.TemplateTypeRoleTypes)
                .HasForeignKey(d => d.TemplateTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TemplateType_TemplateTypeRoleType_2");
        });

        modelBuilder.Entity<TemplateUser>(entity =>
        {
            entity.HasKey(e => e.TemplateUserId).HasName("PK_TemplateUserID");

            entity.ToTable("TemplateUser", "Admin");

            entity.HasIndex(e => new { e.TemplateId, e.TmsuserId, e.Deleted, e.SenderRecipient }, "IDX_TemplateUser_2").IsUnique();

            entity.Property(e => e.TemplateUserId).HasColumnName("TemplateUserID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TemplateId).HasColumnName("TemplateID");
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");

            entity.HasOne(d => d.Template).WithMany(p => p.TemplateUsers)
                .HasForeignKey(d => d.TemplateId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Template_TemplateUser_1");
        });

        modelBuilder.Entity<TextMessage>(entity =>
        {
            entity.HasKey(e => e.TextMessageId).HasName("PK_TextMessageID");

            entity.ToTable("TextMessage");

            entity.HasIndex(e => e.ApplicationId, "IDX_TextMessage_App");

            entity.Property(e => e.TextMessageId).HasColumnName("TextMessageID");
            entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.EventTime).HasColumnType("datetime");
            entity.Property(e => e.ExternalNumber).HasMaxLength(20);
            entity.Property(e => e.Id).HasMaxLength(50);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SenderUserId).HasColumnName("SenderUserID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.Text).HasMaxLength(1000);
            entity.Property(e => e.TextMessageEventTypeId).HasColumnName("TextMessageEventTypeID");

            entity.HasOne(d => d.Application).WithMany(p => p.TextMessages)
                .HasForeignKey(d => d.ApplicationId)
                .HasConstraintName("FK_Application_TextMessage_3");

            entity.HasOne(d => d.SenderUser).WithMany(p => p.TextMessages)
                .HasForeignKey(d => d.SenderUserId)
                .HasConstraintName("FK_UserProfile_TextMessage_2");

            entity.HasOne(d => d.TextMessageEventType).WithMany(p => p.TextMessages)
                .HasForeignKey(d => d.TextMessageEventTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TextMessageEventType_TextMessage_1");
        });

        modelBuilder.Entity<TextMessageEventType>(entity =>
        {
            entity.HasKey(e => e.TextMessageEventTypeId).HasName("PK_TextMessageEventTypeID");

            entity.ToTable("TextMessageEventType");

            entity.Property(e => e.TextMessageEventTypeId).HasColumnName("TextMessageEventTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Description).HasMaxLength(100);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(50);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<TextMessageSnippet>(entity =>
        {
            entity.HasKey(e => e.TextMessageSnippetId).HasName("PK_TextMessageSnippetID");

            entity.ToTable("TextMessageSnippet");

            entity.Property(e => e.TextMessageSnippetId).HasColumnName("TextMessageSnippetID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SnippetMessage).HasMaxLength(320);
            entity.Property(e => e.SnippetTitle).HasMaxLength(50);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");

            entity.HasOne(d => d.Tmsuser).WithMany(p => p.TextMessageSnippets)
                .HasForeignKey(d => d.TmsuserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TMSUser_TextMessageSnippet_1");
        });

        modelBuilder.Entity<TmsdataType>(entity =>
        {
            entity.HasKey(e => e.TmsdataTypeId).HasName("PK_TMSDataTypeID");

            entity.ToTable("TMSDataType", "Admin");

            entity.HasIndex(e => new { e.Deleted, e.Name }, "IDX_TMSDataType_2").IsUnique();

            entity.Property(e => e.TmsdataTypeId).HasColumnName("TMSDataTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Description).HasMaxLength(255);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<Tmsuser>(entity =>
        {
            entity.HasKey(e => e.TmsuserId).HasName("PK_TMSUserID");

            entity.ToTable("TMSUser", "Auth");

            entity.HasIndex(e => new { e.UserName, e.Deleted }, "IDX_TMSUser_3").IsUnique();

            entity.HasIndex(e => e.UserName, "IDX_TMSUser_4");

            entity.HasIndex(e => new { e.Email, e.Deleted }, "IDX_TMSUser_5").IsUnique();

            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");
            entity.Property(e => e.AccountStateTypeId).HasColumnName("AccountStateTypeID");
            entity.Property(e => e.ContactInformationId).HasColumnName("ContactInformationID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Email).HasMaxLength(256);
            entity.Property(e => e.EmployeeId)
                .HasMaxLength(255)
                .HasColumnName("EmployeeID");
            entity.Property(e => e.FirstName).HasMaxLength(100);
            entity.Property(e => e.Hrisidentifier)
                .HasMaxLength(64)
                .HasColumnName("HRISIdentifier");
            entity.Property(e => e.JobTitle).HasMaxLength(300);
            entity.Property(e => e.LastName).HasMaxLength(100);
            entity.Property(e => e.ManagerId).HasColumnName("ManagerID");
            entity.Property(e => e.MiddleName).HasMaxLength(100);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Password).HasMaxLength(256);
            entity.Property(e => e.PasswordDate).HasColumnType("datetime");
            entity.Property(e => e.PositionInHierarchyId).HasColumnName("PositionInHierarchyID");
            entity.Property(e => e.Salt).HasMaxLength(50);
            entity.Property(e => e.Ssoidentifier)
                .HasMaxLength(64)
                .HasColumnName("SSOIdentifier");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TitleCategoryMetaValueId).HasColumnName("TitleCategoryMetaValueID");
            entity.Property(e => e.UserName).HasMaxLength(100);

            entity.HasOne(d => d.AccountStateType).WithMany(p => p.Tmsusers)
                .HasForeignKey(d => d.AccountStateTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_AccountStateType_TMSUser_1");

            entity.HasOne(d => d.ContactInformation).WithMany(p => p.Tmsusers)
                .HasForeignKey(d => d.ContactInformationId)
                .HasConstraintName("FK__TMSUser_ContactInformation");

            entity.HasOne(d => d.Manager).WithMany(p => p.InverseManager)
                .HasForeignKey(d => d.ManagerId)
                .HasConstraintName("FK_TMSUser_TMSUser_3");
        });

        modelBuilder.Entity<TmsuserAreaOfResponsibility>(entity =>
        {
            entity.HasKey(e => e.TmsuserAreaOfResponsibilityId).HasName("PK_TMSUserAreaOfResponsibilityID");

            entity.ToTable("TMSUserAreaOfResponsibility", "Auth");

            entity.HasIndex(e => new { e.BusinessEntityId, e.Deleted, e.TmsuserId }, "IDX_TMSUserAreaOfResponsibility_2").IsUnique();

            entity.Property(e => e.TmsuserAreaOfResponsibilityId).HasColumnName("TMSUserAreaOfResponsibilityID");
            entity.Property(e => e.BusinessEntityId).HasColumnName("BusinessEntityID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");

            entity.HasOne(d => d.Tmsuser).WithMany(p => p.TmsuserAreaOfResponsibilities)
                .HasForeignKey(d => d.TmsuserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TMSUser_TMSUserAreaOfResponsibility_1");
        });

        modelBuilder.Entity<TmsuserRole>(entity =>
        {
            entity.HasKey(e => e.TmsuserRoleId).HasName("PK__TMSUserR__8D9C9A244B070DB9");

            entity.ToTable("TMSUserRole", "Auth");

            entity.HasIndex(e => new { e.TmsuserId, e.RoleId, e.Deleted }, "IDX_TMSUserRole_2").IsUnique();

            entity.Property(e => e.TmsuserRoleId).HasColumnName("TMSUserRoleID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.RoleId).HasColumnName("RoleID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");

            entity.HasOne(d => d.Role).WithMany(p => p.TmsuserRoles)
                .HasForeignKey(d => d.RoleId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Role_TMSUserRole_2");

            entity.HasOne(d => d.Tmsuser).WithMany(p => p.TmsuserRoles)
                .HasForeignKey(d => d.TmsuserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TMSUser_TMSUserRole_1");
        });

        modelBuilder.Entity<UserAccountStateTypeHistory>(entity =>
        {
            entity.HasKey(e => e.UserAccountStateTypeHistoryId).HasName("PK_UserAccountStateTypeHistoryID");

            entity.ToTable("UserAccountStateTypeHistory", "Auth");

            entity.Property(e => e.UserAccountStateTypeHistoryId).HasColumnName("UserAccountStateTypeHistoryID");
            entity.Property(e => e.AccountStateTypeId).HasColumnName("AccountStateTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");

            entity.HasOne(d => d.AccountStateType).WithMany(p => p.UserAccountStateTypeHistories)
                .HasForeignKey(d => d.AccountStateTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_AccountStateType_UserAccountStateTypeHistory_1");

            entity.HasOne(d => d.Tmsuser).WithMany(p => p.UserAccountStateTypeHistories)
                .HasForeignKey(d => d.TmsuserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TMSUser_UserAccountStateTypeHistory_2");
        });

        modelBuilder.Entity<UserDetailSectionPreference>(entity =>
        {
            entity.HasKey(e => e.UserDetailSectionPreferencesId).HasName("PK_UserDetailSectionPreferencesID");

            entity.HasIndex(e => new { e.TmsuserId, e.Deleted }, "IDX_UserDetailSectionPreferencesUnique").IsUnique();

            entity.Property(e => e.UserDetailSectionPreferencesId).HasColumnName("UserDetailSectionPreferencesID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DetailSectionTypeId).HasColumnName("DetailSectionTypeID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");

            entity.HasOne(d => d.DetailSectionType).WithMany(p => p.UserDetailSectionPreferences)
                .HasForeignKey(d => d.DetailSectionTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DetailSectionType_UserDetailSectionPreferences");
        });

        modelBuilder.Entity<UserGridColumnPreference>(entity =>
        {
            entity.HasKey(e => e.UserGridColumnPreferencesId).HasName("PK_UserGridColumnPreferencesID");

            entity.HasIndex(e => new { e.TmsuserId, e.Deleted }, "IDX_UserGridColumnUnique").IsUnique();

            entity.Property(e => e.UserGridColumnPreferencesId).HasColumnName("UserGridColumnPreferencesID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.DefaultSortModel).HasMaxLength(4000);
            entity.Property(e => e.GridTypeId).HasColumnName("GridTypeID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");

            entity.HasOne(d => d.GridType).WithMany(p => p.UserGridColumnPreferences)
                .HasForeignKey(d => d.GridTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_GridType_UserGridColumnPreferences");
        });

        modelBuilder.Entity<UserHistory>(entity =>
        {
            entity.HasKey(e => e.UserHistoryId).HasName("PK_UserHistoryID");

            entity.ToTable("UserHistory");

            entity.Property(e => e.UserHistoryId).HasColumnName("UserHistoryID");
            entity.Property(e => e.AlternateIdentifier).HasMaxLength(300);
            entity.Property(e => e.ContextIdentifier).HasMaxLength(100);
            entity.Property(e => e.ContextObjectId)
                .HasMaxLength(300)
                .HasColumnName("ContextObjectID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");
        });

        modelBuilder.Entity<UserPreference>(entity =>
        {
            entity.HasKey(e => e.UserPreferenceId).HasName("PK_UserPreferenceID");

            entity.ToTable("UserPreference", "Auth");

            entity.HasIndex(e => new { e.ClientSettingId, e.TmsuserId, e.Value, e.Deleted }, "UC_UserPreference_Unique").IsUnique();

            entity.Property(e => e.UserPreferenceId).HasColumnName("UserPreferenceID");
            entity.Property(e => e.ClientSettingId).HasColumnName("ClientSettingID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");
            entity.Property(e => e.Value).HasMaxLength(255);

            entity.HasOne(d => d.ClientSetting).WithMany(p => p.UserPreferences)
                .HasForeignKey(d => d.ClientSettingId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ClientSetting_UserPreference_1");

            entity.HasOne(d => d.Tmsuser).WithMany(p => p.UserPreferences)
                .HasForeignKey(d => d.TmsuserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TMSUser_UserPrefrence_1");
        });

        modelBuilder.Entity<UserProfile>(entity =>
        {
            entity.HasKey(e => e.TmsuserId).HasName("PK__UserProf__8328F68E75E17848");

            entity.ToTable("UserProfile");

            entity.HasIndex(e => new { e.TmsuserId, e.Deleted }, "IDX_UserProfile_2").IsUnique();

            entity.HasIndex(e => e.TmsuserId, "IDX_UserProfile_TMSUserID");

            entity.Property(e => e.TmsuserId)
                .ValueGeneratedNever()
                .HasColumnName("TMSUserID");
            entity.Property(e => e.ContactInformationId).HasColumnName("ContactInformationID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Email).HasMaxLength(256);
            entity.Property(e => e.FirstName).HasMaxLength(100);
            entity.Property(e => e.JobTitle).HasMaxLength(300);
            entity.Property(e => e.LastName).HasMaxLength(100);
            entity.Property(e => e.MiddleName).HasMaxLength(100);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.PositionInHierarchyId).HasColumnName("PositionInHierarchyID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TitleCategoryMetaValueId)
                .HasComment("Mapped to the TitleCategory MetaTypeID. Will be used to group requisition approvers by Title category E.g: VP, CEO, etc.")
                .HasColumnName("TitleCategoryMetaValueID");
            entity.Property(e => e.UserName).HasMaxLength(100);

            entity.HasOne(d => d.ContactInformation).WithMany(p => p.UserProfiles)
                .HasForeignKey(d => d.ContactInformationId)
                .HasConstraintName("FK_ContactInformation_UserProfile_2");

            entity.HasOne(d => d.TitleCategoryMetaValue).WithMany(p => p.UserProfiles)
                .HasForeignKey(d => d.TitleCategoryMetaValueId)
                .HasConstraintName("FK_MetaValue_UserProfile_1");
        });

        modelBuilder.Entity<UserProfileRoleType>(entity =>
        {
            entity.HasKey(e => e.UserProfileRoleTypeId).HasName("PK__UserProf__88DF6E9A71293C70");

            entity.ToTable("UserProfileRoleType");

            entity.HasIndex(e => new { e.TmsuserId, e.RoleTypeId, e.Deleted }, "IDX_UserProfileRoleType_2").IsUnique();

            entity.Property(e => e.UserProfileRoleTypeId).HasColumnName("UserProfileRoleTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.RoleTypeId).HasColumnName("RoleTypeID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");

            entity.HasOne(d => d.RoleType).WithMany(p => p.UserProfileRoleTypes)
                .HasForeignKey(d => d.RoleTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_RoleType_UserProfileRoleType_2");

            entity.HasOne(d => d.Tmsuser).WithMany(p => p.UserProfileRoleTypes)
                .HasForeignKey(d => d.TmsuserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_UserProfile_UserProfileRoleType_1");
        });

        modelBuilder.Entity<UserProfileVendorUserAccount>(entity =>
        {
            entity.HasKey(e => e.UserProfileVendorUserAccountId).HasName("PK_UserProfileVendorUserAccountID");

            entity.ToTable("UserProfileVendorUserAccount", "Admin");

            entity.HasIndex(e => new { e.Deleted, e.TmsuserId, e.VendorUserAccountId }, "IDX_UserProfileVendorUserAccount_2").IsUnique();

            entity.Property(e => e.UserProfileVendorUserAccountId).HasColumnName("UserProfileVendorUserAccountID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");
            entity.Property(e => e.VendorUserAccountId).HasColumnName("VendorUserAccountID");

            entity.HasOne(d => d.Tmsuser).WithMany(p => p.UserProfileVendorUserAccounts)
                .HasForeignKey(d => d.TmsuserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_UserProfile_UserProfileVendorUserAccount_1");

            entity.HasOne(d => d.VendorUserAccount).WithMany(p => p.UserProfileVendorUserAccounts)
                .HasForeignKey(d => d.VendorUserAccountId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_VendorUserAccount_UserProfileVendorUserAccount_2");
        });

        modelBuilder.Entity<UserWizardDatum>(entity =>
        {
            entity.HasKey(e => e.UserWizardDataId).HasName("PK_UserWizardDataID");

            entity.Property(e => e.UserWizardDataId).HasColumnName("UserWizardDataID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");
            entity.Property(e => e.WizardTypeId).HasColumnName("WizardTypeID");
        });

        modelBuilder.Entity<Vendor>(entity =>
        {
            entity.HasKey(e => e.VendorId).HasName("PK__Vendor__FC8618D3DAF6FA14");

            entity.ToTable("Vendor", "Admin");

            entity.HasIndex(e => new { e.Name, e.VendorTypeId, e.Deleted }, "IDX_Vendor_2").IsUnique();

            entity.HasIndex(e => new { e.InternalIdentifier, e.Deleted }, "IDX_Vendor_3").IsUnique();

            entity.Property(e => e.VendorId)
                .ValueGeneratedNever()
                .HasComment("VendorID is not an Identity primary key as it will be brought over from the Global Vendor table.")
                .HasColumnName("VendorID");
            entity.Property(e => e.Active).HasDefaultValue(true);
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Description).HasMaxLength(255);
            entity.Property(e => e.InitiationWindowSource)
                .HasMaxLength(25)
                .HasDefaultValue("InitiationRequestResponse");
            entity.Property(e => e.InternalIdentifier).HasMaxLength(50);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.PostingMediaType).HasDefaultValue(1);
            entity.Property(e => e.ProviderKey).HasComment("The ProviderKey identifies which Provider factory implementation is being used for the integration.");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.VendorTypeId)
                .HasComment("The VendorType table is not brought down from the global database, so VendorTypeID is not expressed explicitly as a foreign key.")
                .HasColumnName("VendorTypeID");
        });

        modelBuilder.Entity<VendorAttribute>(entity =>
        {
            entity.HasKey(e => e.VendorAttributeId).HasName("PK__VendorAt__66E056CCFE679A2F");

            entity.ToTable("VendorAttribute", "Admin");

            entity.HasIndex(e => new { e.Name, e.VendorId, e.Deleted, e.VendorAttributeTypeId }, "IDX_VendorAttribute_2").IsUnique();

            entity.Property(e => e.VendorAttributeId)
                .ValueGeneratedNever()
                .HasComment("VendorAttributeID is not an Identity primary key as it will be brought over from the global VendorAttribute table.")
                .HasColumnName("VendorAttributeID");
            entity.Property(e => e.ControlTypeId)
                .HasDefaultValue(1)
                .HasColumnName("ControlTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Description).HasMaxLength(255);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.Value).HasMaxLength(256);
            entity.Property(e => e.VendorAttributeTypeId).HasColumnName("VendorAttributeTypeID");
            entity.Property(e => e.VendorId).HasColumnName("VendorID");

            entity.HasOne(d => d.ControlType).WithMany(p => p.VendorAttributes)
                .HasForeignKey(d => d.ControlTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ControlType_VendorAttribute_3");

            entity.HasOne(d => d.VendorAttributeType).WithMany(p => p.VendorAttributes)
                .HasForeignKey(d => d.VendorAttributeTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_VendorAttributeType_VendorAttribute_2");

            entity.HasOne(d => d.Vendor).WithMany(p => p.VendorAttributes)
                .HasForeignKey(d => d.VendorId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Vendor_VendorAttribute_1");
        });

        modelBuilder.Entity<VendorAttributeType>(entity =>
        {
            entity.HasKey(e => e.VendorAttributeTypeId).HasName("PK__VendorAt__0F2BA2F212892331");

            entity.ToTable("VendorAttributeType", "Admin");

            entity.HasIndex(e => new { e.Name, e.Deleted }, "IDX_VendorAttributeType_2").IsUnique();

            entity.Property(e => e.VendorAttributeTypeId).HasColumnName("VendorAttributeTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<VendorAuditLog>(entity =>
        {
            entity.HasKey(e => e.VendorAuditLogId).HasName("PK_VendorAuditLogID");

            entity.ToTable("VendorAuditLog");

            entity.Property(e => e.VendorAuditLogId).HasColumnName("VendorAuditLogID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Entity).HasMaxLength(50);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Operation).HasMaxLength(500);
            entity.Property(e => e.OperationTime).HasColumnType("datetime");
            entity.Property(e => e.Reason).HasMaxLength(4000);
            entity.Property(e => e.Result).HasMaxLength(4);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");
            entity.Property(e => e.VendorId).HasColumnName("VendorID");

            entity.HasOne(d => d.Tmsuser).WithMany(p => p.VendorAuditLogs)
                .HasForeignKey(d => d.TmsuserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_UserProfile_VendorAuditLog");

            entity.HasOne(d => d.Vendor).WithMany(p => p.VendorAuditLogs)
                .HasForeignKey(d => d.VendorId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Vendor_VendorAuditLog");
        });

        modelBuilder.Entity<VendorCorporateAccount>(entity =>
        {
            entity.HasKey(e => e.VendorCorporateAccountId).HasName("PK__VendorCo__93AA21626A7952AB");

            entity.ToTable("VendorCorporateAccount", "Admin");

            entity.HasIndex(e => new { e.AccountIdentifier, e.VendorId, e.Deleted, e.BusinessEntityId }, "IDX_VendorCorporateAccount_2").IsUnique();

            entity.Property(e => e.VendorCorporateAccountId).HasColumnName("VendorCorporateAccountID");
            entity.Property(e => e.AccountIdentifier).HasMaxLength(100);
            entity.Property(e => e.BusinessEntityId).HasColumnName("BusinessEntityID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Password).HasMaxLength(256);
            entity.Property(e => e.Salt).HasMaxLength(50);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.VendorId).HasColumnName("VendorID");

            entity.HasOne(d => d.BusinessEntity).WithMany(p => p.VendorCorporateAccounts)
                .HasForeignKey(d => d.BusinessEntityId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessEntity_VendorCorporateAccount_2");

            entity.HasOne(d => d.Vendor).WithMany(p => p.VendorCorporateAccounts)
                .HasForeignKey(d => d.VendorId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Vendor_VendorCorporateAccount_1");
        });

        modelBuilder.Entity<VendorCorporateAccountVendorUserAccount>(entity =>
        {
            entity.HasKey(e => e.VendorCorporateAccountVendorUserAccountId).HasName("PK__VendorCo__36008DA1980D7F1C");

            entity.ToTable("VendorCorporateAccountVendorUserAccount", "Admin");

            entity.HasIndex(e => new { e.VendorCorporateAccountId, e.VendorUserAccountId, e.Deleted }, "IDX_VendorCorporateAccountVendorUserAccount_2").IsUnique();

            entity.Property(e => e.VendorCorporateAccountVendorUserAccountId).HasColumnName("VendorCorporateAccountVendorUserAccountID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.VendorCorporateAccountId).HasColumnName("VendorCorporateAccountID");
            entity.Property(e => e.VendorUserAccountId).HasColumnName("VendorUserAccountID");

            entity.HasOne(d => d.VendorCorporateAccount).WithMany(p => p.VendorCorporateAccountVendorUserAccounts)
                .HasForeignKey(d => d.VendorCorporateAccountId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_VendorCorporateAccount_VendorCorporateAccountVendorUserAccount_1");

            entity.HasOne(d => d.VendorUserAccount).WithMany(p => p.VendorCorporateAccountVendorUserAccounts)
                .HasForeignKey(d => d.VendorUserAccountId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_VendorUserAccount_VendorCorporateAccountVendorUserAccount_2");
        });

        modelBuilder.Entity<VendorOrder>(entity =>
        {
            entity.HasKey(e => e.VendorOrderId).HasName("PK__VendorOr__477DCB5B3F749549");

            entity.ToTable("VendorOrder");

            entity.HasIndex(e => e.VendorOrderStatusTypeId, "IDX_VendorOrderStatusTypeID").HasFillFactor(80);

            entity.Property(e => e.VendorOrderId).HasColumnName("VendorOrderID");
            entity.Property(e => e.CompletionDate).HasColumnType("datetime");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Description).HasMaxLength(255);
            entity.Property(e => e.ExpirationDate).HasColumnType("datetime");
            entity.Property(e => e.InviteUrl).HasMaxLength(2000);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.OrderProcessingRedirectUrl).HasMaxLength(2000);
            entity.Property(e => e.ResultDescription).HasMaxLength(255);
            entity.Property(e => e.ResultLink).HasMaxLength(2000);
            entity.Property(e => e.ResultLinkName).HasMaxLength(100);
            entity.Property(e => e.Score).HasMaxLength(100);
            entity.Property(e => e.StatusCode).HasMaxLength(50);
            entity.Property(e => e.StatusReason).HasMaxLength(255);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.VendorId).HasColumnName("VendorID");
            entity.Property(e => e.VendorOrderIdentifier).HasMaxLength(64);
            entity.Property(e => e.VendorOrderStatusTypeId).HasColumnName("VendorOrderStatusTypeID");
            entity.Property(e => e.VendorOrderSubtypeIdentifier).HasMaxLength(100);
            entity.Property(e => e.VendorOrderTypeId).HasColumnName("VendorOrderTypeID");
            entity.Property(e => e.VendorUserAccountId).HasColumnName("VendorUserAccountID");

            entity.HasOne(d => d.Vendor).WithMany(p => p.VendorOrders)
                .HasForeignKey(d => d.VendorId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Vendor_VendorOrder_1");

            entity.HasOne(d => d.VendorOrderStatusType).WithMany(p => p.VendorOrders)
                .HasForeignKey(d => d.VendorOrderStatusTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_VendorOrderStatusType_VendorOrder_4");

            entity.HasOne(d => d.VendorOrderType).WithMany(p => p.VendorOrders)
                .HasForeignKey(d => d.VendorOrderTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_VendorOrderType_VendorOrder_2");

            entity.HasOne(d => d.VendorUserAccount).WithMany(p => p.VendorOrders)
                .HasForeignKey(d => d.VendorUserAccountId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_VendorUserAccount_VendorOrder_5");
        });

        modelBuilder.Entity<VendorOrderDetail>(entity =>
        {
            entity.HasKey(e => e.VendorOrderResultId).HasName("PK_VendorOrderDetailID");

            entity.ToTable("VendorOrderDetail");

            entity.Property(e => e.VendorOrderResultId).HasColumnName("VendorOrderResultID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Description).HasMaxLength(255);
            entity.Property(e => e.JobFamilyId).HasColumnName("JobFamilyID");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.ResultDescription).HasMaxLength(255);
            entity.Property(e => e.ResultLink).HasMaxLength(512);
            entity.Property(e => e.ResultLinkName).HasMaxLength(100);
            entity.Property(e => e.Score).HasMaxLength(100);
            entity.Property(e => e.StatusCode).HasMaxLength(50);
            entity.Property(e => e.StatusReason).HasMaxLength(255);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.VendorOrderId).HasColumnName("VendorOrderID");

            entity.HasOne(d => d.JobFamily).WithMany(p => p.VendorOrderDetails)
                .HasForeignKey(d => d.JobFamilyId)
                .HasConstraintName("FK__VendorOrderDetail_JobFamily");

            entity.HasOne(d => d.VendorOrder).WithMany(p => p.VendorOrderDetails)
                .HasForeignKey(d => d.VendorOrderId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_VendorOrder_VendorOrderDetail_1");
        });

        modelBuilder.Entity<VendorOrderResult>(entity =>
        {
            entity.HasKey(e => e.VendorOrderResultId).HasName("PK_VendorOrderResultID");

            entity.ToTable("VendorOrderResult");

            entity.Property(e => e.VendorOrderResultId).HasColumnName("VendorOrderResultID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.Identifier).HasMaxLength(100);
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.Value).HasMaxLength(100);
            entity.Property(e => e.VendorOrderId).HasColumnName("VendorOrderID");

            entity.HasOne(d => d.VendorOrder).WithMany(p => p.VendorOrderResults)
                .HasForeignKey(d => d.VendorOrderId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_VendorOrderResult_VendorOrder");
        });

        modelBuilder.Entity<VendorOrderStatusType>(entity =>
        {
            entity.HasKey(e => e.VendorOrderStatusTypeId).HasName("PK__VendorOr__0F73EC907C72DC6B");

            entity.ToTable("VendorOrderStatusType", "Admin");

            entity.HasIndex(e => new { e.Name, e.Deleted }, "IDX_VendorOrderStatusType_2").IsUnique();

            entity.Property(e => e.VendorOrderStatusTypeId).HasColumnName("VendorOrderStatusTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<VendorOrderStatusTypeHistory>(entity =>
        {
            entity.HasKey(e => e.VendorOrderStatusTypeHistoryId).HasName("PK__VendorOr__99F7789690F18D96");

            entity.ToTable("VendorOrderStatusTypeHistory");

            entity.Property(e => e.VendorOrderStatusTypeHistoryId).HasColumnName("VendorOrderStatusTypeHistoryID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.VendorOrderId).HasColumnName("VendorOrderID");
            entity.Property(e => e.VendorOrderStatusTypeId).HasColumnName("VendorOrderStatusTypeID");

            entity.HasOne(d => d.VendorOrder).WithMany(p => p.VendorOrderStatusTypeHistories)
                .HasForeignKey(d => d.VendorOrderId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_VendorOrder_VendorOrderStatusTypeHistory_1");

            entity.HasOne(d => d.VendorOrderStatusType).WithMany(p => p.VendorOrderStatusTypeHistories)
                .HasForeignKey(d => d.VendorOrderStatusTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_VendorOrderStatusType_VendorOrderStatusTypeHistory_2");
        });

        modelBuilder.Entity<VendorOrderType>(entity =>
        {
            entity.HasKey(e => e.VendorOrderTypeId).HasName("PK__VendorOr__008A90813AC024FD");

            entity.ToTable("VendorOrderType", "Admin");

            entity.HasIndex(e => new { e.Name, e.Deleted }, "IDX_VendorOrderType_2").IsUnique();

            entity.Property(e => e.VendorOrderTypeId).HasColumnName("VendorOrderTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        modelBuilder.Entity<VendorSsoAccessAudit>(entity =>
        {
            entity.HasKey(e => e.VendorSsoAccessAuditId).HasName("PK_VendorSsoAccessAuditID");

            entity.ToTable("VendorSsoAccessAudit");

            entity.Property(e => e.VendorSsoAccessAuditId).HasColumnName("VendorSsoAccessAuditID");
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");
            entity.Property(e => e.VendorId).HasColumnName("VendorID");
            entity.Property(e => e.VendorSsoAccessAuditDate)
                .HasColumnType("datetime")
                .HasColumnName("VendorSSoAccessAuditDate");
            entity.Property(e => e.VendorSsoAccessOperationId).HasColumnName("VendorSsoAccessOperationID");

            entity.HasOne(d => d.Tmsuser).WithMany(p => p.VendorSsoAccessAudits)
                .HasForeignKey(d => d.TmsuserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_UserProfile_VendorSsoAccessAudit");
        });

        modelBuilder.Entity<VendorUserAccount>(entity =>
        {
            entity.HasKey(e => e.VendorUserAccountId).HasName("PK__VendorUs__EDCB6013963A9732");

            entity.ToTable("VendorUserAccount", "Admin");

            entity.HasIndex(e => new { e.Username, e.Deleted, e.VendorId }, "IDX_VendorUserAccount_2").IsUnique();

            entity.HasIndex(e => new { e.TmsuserId, e.Deleted, e.VendorId }, "IDX_VendorUserAccount_3");

            entity.Property(e => e.VendorUserAccountId).HasColumnName("VendorUserAccountID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.OneClickUserId).HasColumnName("OneClickUserID");
            entity.Property(e => e.Password).HasMaxLength(256);
            entity.Property(e => e.Salt).HasMaxLength(50);
            entity.Property(e => e.SecurityToken).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");
            entity.Property(e => e.Username).HasMaxLength(100);
            entity.Property(e => e.VendorId).HasColumnName("VendorID");

            entity.HasOne(d => d.Tmsuser).WithMany(p => p.VendorUserAccounts)
                .HasForeignKey(d => d.TmsuserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_UserProfile_VendorUserAccount_2");

            entity.HasOne(d => d.Vendor).WithMany(p => p.VendorUserAccounts)
                .HasForeignKey(d => d.VendorId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Vendor_VendorUserAccount_1");
        });

        modelBuilder.Entity<WebMessage>(entity =>
        {
            entity.HasKey(e => e.WebMessageId)
                .HasName("PK__WebMessa__595778E9169E1D69")
                .IsClustered(false);

            entity.ToTable("WebMessage", "Admin");

            entity.HasIndex(e => new { e.CareerSiteId, e.Name, e.Deleted }, "IDX_WebMessage_2").IsUnique();

            entity.HasIndex(e => new { e.StartDate, e.EndDate }, "IDX_WebMessage_3").IsClustered();

            entity.Property(e => e.WebMessageId).HasColumnName("WebMessageID");
            entity.Property(e => e.BackgroundColor)
                .HasMaxLength(7)
                .IsFixedLength();
            entity.Property(e => e.CareerSiteId).HasColumnName("CareerSiteID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.EndDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.StartDate).HasColumnType("datetime");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.WidthPercent).HasColumnType("decimal(3, 2)");

            entity.HasOne(d => d.CareerSite).WithMany(p => p.WebMessages)
                .HasForeignKey(d => d.CareerSiteId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_CareerSite_WebMessage_1");
        });

        modelBuilder.Entity<WorkflowAssociation>(entity =>
        {
            entity.HasKey(e => e.WorkflowAssociationId).HasName("PK_WorkflowAssociationID");

            entity.ToTable("WorkflowAssociation", "Admin");

            entity.Property(e => e.WorkflowAssociationId).HasColumnName("WorkflowAssociationID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.ParentSettingsWorkflowId).HasColumnName("ParentSettingsWorkflowID");
            entity.Property(e => e.SettingsWorkflowId).HasColumnName("SettingsWorkflowID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);

            entity.HasOne(d => d.ParentSettingsWorkflow).WithMany(p => p.WorkflowAssociationParentSettingsWorkflows)
                .HasForeignKey(d => d.ParentSettingsWorkflowId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_WorkflowAssociation_Parent");

            entity.HasOne(d => d.SettingsWorkflow).WithMany(p => p.WorkflowAssociationSettingsWorkflows)
                .HasForeignKey(d => d.SettingsWorkflowId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_WorkflowAssociation_SettingsWorkflow");
        });

        modelBuilder.Entity<WorkflowAuditHistory>(entity =>
        {
            entity.HasKey(e => e.WorkflowAuditHistoryId).HasName("PK__WorkflowAuditHistory__C4FDF6992116E6DF");

            entity.ToTable("WorkflowAuditHistory");

            entity.HasIndex(e => new { e.ContextObjectId, e.WorkflowTypeId, e.Deleted }, "IDX_WorkflowAuditHistory_2");

            entity.Property(e => e.WorkflowAuditHistoryId).HasColumnName("WorkflowAuditHistoryID");
            entity.Property(e => e.AuditTypeId)
                .HasComment("Audit type ID describes the change if it does not result in status change. This field can be null if the status change happened and the value of StatusTypeID is not null. \r\n\r\nNOTE: The set of values for this column depends on the WorkflowTypeID.")
                .HasColumnName("AuditTypeID");
            entity.Property(e => e.Comment).HasMaxLength(2500);
            entity.Property(e => e.ContextObjectId)
                .HasComment("ID of the business object being audited, e.g. ApplicationID or RequisitionID")
                .HasColumnName("ContextObjectID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.CreatedBy).HasComment("The user id of the user originating the action. ");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.RecipientTmsuserId)
                .HasComment("User ID of the user who is the recipient of the action being audited. E.g. recruiter ID to whom a requisition is reassigned or an approver id who is assigned as the next approver.\r\nNOTE: The originator of the action is tracked in CreatedBy field.")
                .HasColumnName("RecipientTMSUserID");
            entity.Property(e => e.StatusOverrideDate).HasColumnType("datetime");
            entity.Property(e => e.StatusTypeId)
                .HasComment("The new status type id assigned to the context object. If the audited change does not involve status change this value must be null.\r\n\r\nNOTE: The set of values for this column depends on the WorkflowTypeID.")
                .HasColumnName("StatusTypeID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.WorkflowTypeId)
                .HasComment("Workflow type ID of the process being audited, e.g. 1 - \"Internal Applicant\" or 3 - \"Requisition\"")
                .HasColumnName("WorkflowTypeID");
        });

        modelBuilder.Entity<WorkflowStepUser>(entity =>
        {
            entity.HasKey(e => e.WorkflowStepUserId).HasName("PK__Workflow__ADC336EB2E3ECE23");

            entity.ToTable("WorkflowStepUser", "Admin");

            entity.Property(e => e.WorkflowStepUserId).HasColumnName("WorkflowStepUserID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SettingsWorkflowStepId).HasColumnName("SettingsWorkflowStepID");
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
            entity.Property(e => e.TmsuserId).HasColumnName("TMSUserID");

            entity.HasOne(d => d.SettingsWorkflowStep).WithMany(p => p.WorkflowStepUsers)
                .HasForeignKey(d => d.SettingsWorkflowStepId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SettingsWorkflowStep_WorkflowStepUser_1");
        });

        modelBuilder.Entity<WorkflowSubType>(entity =>
        {
            entity.HasKey(e => e.WorkflowSubTypeId).HasName("PK_WorkflowSubTypeID");

            entity.ToTable("WorkflowSubType", "Admin");

            entity.HasIndex(e => new { e.Name, e.Deleted }, "IDX_WorkflowSubType_2").IsUnique();

            entity.Property(e => e.WorkflowSubTypeId).HasColumnName("WorkflowSubTypeID");
            entity.Property(e => e.CreateDate).HasColumnType("datetime");
            entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.SystemIdentity).HasMaxLength(100);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}

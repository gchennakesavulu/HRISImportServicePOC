﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class JobTemplateInstance
{
    public int JobTemplateInstanceId { get; set; }

    public int JobTemplateId { get; set; }

    public string Name { get; set; } = null!;

    public string? Code { get; set; }

    /// <summary>
    /// Default title for job postings created for requisition referencint this job template instance.
    /// </summary>
    public string? JobPostingTitle { get; set; }

    public string? JobDescription { get; set; }

    public string? JobSummary { get; set; }

    public string? KnowledgeSkillsAbilities { get; set; }

    public string? Hours { get; set; }

    /// <summary>
    /// Implied foreign key to TMSSecurity.dbo.NationalJobCategory.NationalJobCategoryID.
    /// 
    /// A populated value on a JobTemplateInstance record indicates what Nation Job Category a given JobTemplateInstance should appear under.
    /// </summary>
    public int? NationalJobCategoryId { get; set; }

    public int CategoryId { get; set; }

    public int? EducationId { get; set; }

    public int? EeojobGroupId { get; set; }

    public int? ScheduleId { get; set; }

    public int? ShiftId { get; set; }

    public int? SalaryRangeId { get; set; }

    public int? PayGradeId { get; set; }

    public int? JobStatusId { get; set; }

    public int? RankingQuestionnaireId { get; set; }

    public int? PreQualificationQuestionnaireId { get; set; }

    public int? PreQualMessageTemplateId { get; set; }

    public int? AssessmentPackageId { get; set; }

    public bool Active { get; set; }

    public bool IsAvailableInJobAgent { get; set; }

    public int? BehavioralAssessmentVendorId { get; set; }

    public int? JobFamilyId { get; set; }

    public int? ReferenceBenchmarkTypeId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public int? LeanCapitalJobFamilyTypeId { get; set; }

    public int? BehavioralAssessmentVendorOfferingId { get; set; }

    public int PostingBrandingHierarchyLevelId { get; set; }

    public int? ReferenceAssessmentVendorOfferingId { get; set; }

    public int? ReferenceAssessmentDivisionId { get; set; }

    public int? ReferenceAssessmentWorkforceSegmentId { get; set; }

    public bool? ShortFormAssessmentOnly { get; set; }

    public virtual AssessmentPackage? AssessmentPackage { get; set; }

    public virtual Vendor? BehavioralAssessmentVendor { get; set; }

    public virtual MetaValue Category { get; set; } = null!;

    public virtual MetaValue? Education { get; set; }

    public virtual MetaValue? EeojobGroup { get; set; }

    public virtual JobFamily? JobFamily { get; set; }

    public virtual MetaValue? JobStatus { get; set; }

    public virtual JobTemplate JobTemplate { get; set; } = null!;

    public virtual ICollection<JobTemplateInstanceLeanCapitalJobFamilyType> JobTemplateInstanceLeanCapitalJobFamilyTypes { get; set; } = new List<JobTemplateInstanceLeanCapitalJobFamilyType>();

    public virtual ICollection<JobTemplateInstanceMetaValue> JobTemplateInstanceMetaValues { get; set; } = new List<JobTemplateInstanceMetaValue>();

    public virtual LeanCapitalJobFamilyType? LeanCapitalJobFamilyType { get; set; }

    public virtual MetaValue? PayGrade { get; set; }

    public virtual BusinessEntityType PostingBrandingHierarchyLevel { get; set; } = null!;

    public virtual Template? PreQualMessageTemplate { get; set; }

    public virtual Questionnaire? PreQualificationQuestionnaire { get; set; }

    public virtual Questionnaire? RankingQuestionnaire { get; set; }

    public virtual ReferenceBenchmarkType? ReferenceBenchmarkType { get; set; }

    public virtual ICollection<Requisition> Requisitions { get; set; } = new List<Requisition>();

    public virtual MetaValue? SalaryRange { get; set; }

    public virtual MetaValue? Schedule { get; set; }

    public virtual MetaValue? Shift { get; set; }
}

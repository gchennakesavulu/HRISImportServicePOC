﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class ImpersonationAudit
{
    public int ImpersonationAuditId { get; set; }

    public int ImpersonatedAsUserId { get; set; }

    public int ImpersonationUserId { get; set; }

    public DateTime ImpersonationStart { get; set; }

    public DateTime? ImpersonationEnd { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual Tmsuser ImpersonatedAsUser { get; set; } = null!;

    public virtual Tmsuser ImpersonationUser { get; set; } = null!;
}

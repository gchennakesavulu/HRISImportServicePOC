﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class FormType
{
    public int FormTypeId { get; set; }

    public string Name { get; set; } = null!;

    /// <summary>
    /// Column FormTypeViewModelName stores the actual ViewModel name of the form to be used in the View.
    /// </summary>
    public string? FormTypeViewModelName { get; set; }

    public int DataSourceTypeId { get; set; }

    public int DataSourceFieldTypeId { get; set; }

    public int FieldCategoryId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual DataSourceFieldType DataSourceFieldType { get; set; } = null!;

    public virtual DataSourceType DataSourceType { get; set; } = null!;

    public virtual FieldCategory FieldCategory { get; set; } = null!;

    public virtual ICollection<FormPublished> FormPublisheds { get; set; } = new List<FormPublished>();

    public virtual ICollection<FormTypeFieldCategory> FormTypeFieldCategories { get; set; } = new List<FormTypeFieldCategory>();

    public virtual ICollection<FormTypeMetaTypeFieldTag> FormTypeMetaTypeFieldTags { get; set; } = new List<FormTypeMetaTypeFieldTag>();

    public virtual ICollection<Form> Forms { get; set; } = new List<Form>();
}

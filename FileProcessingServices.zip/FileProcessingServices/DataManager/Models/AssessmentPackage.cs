﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class AssessmentPackage
{
    public int AssessmentPackageId { get; set; }

    public string PackageIdentifier { get; set; } = null!;

    public string PackageName { get; set; } = null!;

    public string? PackageDescription { get; set; }

    public string? JobFamilyIdentifier { get; set; }

    public string? JobFamilyName { get; set; }

    public string? AssessmentTypeIdentifier { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<JobTemplateInstance> JobTemplateInstances { get; set; } = new List<JobTemplateInstance>();

    public virtual ICollection<JobTemplate> JobTemplates { get; set; } = new List<JobTemplate>();
}

﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class TemplateType
{
    public int TemplateTypeId { get; set; }

    public string Name { get; set; } = null!;

    public string? Description { get; set; }

    public bool IsSystemTemplate { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<Communication> Communications { get; set; } = new List<Communication>();

    public virtual ICollection<TemplateTypeAttributeType> TemplateTypeAttributeTypes { get; set; } = new List<TemplateTypeAttributeType>();

    public virtual ICollection<TemplateTypeFieldCategory> TemplateTypeFieldCategories { get; set; } = new List<TemplateTypeFieldCategory>();

    public virtual ICollection<TemplateTypeMiscellaneousField> TemplateTypeMiscellaneousFields { get; set; } = new List<TemplateTypeMiscellaneousField>();

    public virtual ICollection<TemplateTypeRoleType> TemplateTypeRoleTypes { get; set; } = new List<TemplateTypeRoleType>();

    public virtual ICollection<Template> Templates { get; set; } = new List<Template>();
}

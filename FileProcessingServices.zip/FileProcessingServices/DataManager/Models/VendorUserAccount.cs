﻿using System;
using System.Collections.Generic;

namespace DataManager.Models;

public partial class VendorUserAccount
{
    public int VendorUserAccountId { get; set; }

    public string Username { get; set; } = null!;

    public string? SecurityToken { get; set; }

    public string? Password { get; set; }

    public string? Salt { get; set; }

    public int TmsuserId { get; set; }

    public int VendorId { get; set; }

    public int? OneClickUserId { get; set; }

    public int Deleted { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public int CreatedBy { get; set; }

    public int? ModifiedBy { get; set; }

    public string? SystemIdentity { get; set; }

    public virtual ICollection<RefactorAssessmentsVendorOrderTableMigration> RefactorAssessmentsVendorOrderTableMigrations { get; set; } = new List<RefactorAssessmentsVendorOrderTableMigration>();

    public virtual UserProfile Tmsuser { get; set; } = null!;

    public virtual ICollection<UserProfileVendorUserAccount> UserProfileVendorUserAccounts { get; set; } = new List<UserProfileVendorUserAccount>();

    public virtual Vendor Vendor { get; set; } = null!;

    public virtual ICollection<VendorCorporateAccountVendorUserAccount> VendorCorporateAccountVendorUserAccounts { get; set; } = new List<VendorCorporateAccountVendorUserAccount>();

    public virtual ICollection<VendorOrder> VendorOrders { get; set; } = new List<VendorOrder>();
}

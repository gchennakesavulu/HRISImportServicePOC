﻿using DataManager.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataManager
{
    public interface IMetaValueRepository
    {
        Task<List<MetaValue>> GetMetaValues();
        Task<int> GetMetaValueIdByName(string name);
        Task<Dictionary<string, int>> GetMetvalueNamesWithIds(List<int> metaTypeIds);


    }
}
